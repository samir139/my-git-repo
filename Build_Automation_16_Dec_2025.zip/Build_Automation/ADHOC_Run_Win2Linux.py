import paramiko
from scp import SCPClient
import os
import glob
import sys
from configparser import ConfigParser


class FileTransfer:
    def __init__(self, windows_hosts, linux_hosts):
        self.windows_hosts = windows_hosts
        self.windows_path = '\\\\' + windows_hosts + '\\unixworking\\newset\\linux_data\\advreports\\*'
        self.linux_hosts = linux_hosts.split(",")
        self.remote_path = "/apps/eagle/data/pace/advreports"

        build_ini_file = windows_hosts[0:windows_hosts.find('-', windows_hosts.find('-') + 1)] + '.ini'
        config_path = os.path.join(
            os.path.abspath(os.path.dirname(__file__)),
            'configurations',
            build_ini_file
        )
        print(config_path)

        self.parser = ConfigParser()
        self.parser.read(config_path)

        self.username = self.parser['REGION_DETAILS']['username']

    def create_ssh_client(self, host, private_key_path, port=22):
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        private_key = paramiko.RSAKey.from_private_key_file(private_key_path)
        ssh.connect(hostname=host, port=port, username=self.username, pkey=private_key)
        return ssh

    def upload(self, local_path, host, private_key_path):
        ssh = self.create_ssh_client(host, private_key_path)
        with SCPClient(ssh.get_transport()) as scp:
            if os.path.isdir(local_path):
                print(f"[{host}] Uploading directory {local_path} → {self.remote_path}")
                scp.put(local_path, recursive=True, remote_path=self.remote_path)
            else:
                print(f"[{host}] Uploading file from {local_path} to {self.remote_path}")
                scp.put(local_path, remote_path=self.remote_path)
        ssh.close()

    def run(self):
        files = glob.glob(self.windows_path)

        if not files:
            print(f"No files found in {self.windows_path}")
            sys.exit(1)

        for host in self.linux_hosts:
            host = host.strip()
            private_key_path = os.path.join(
                self.parser['REGION_DETAILS']['privatekey'],
                host.split('.')[0]
            )
            for f in files:
                self.upload(f, host, private_key_path)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python script.py <windows_host> <linux_hosts_comma_sep>")
        sys.exit(1)

    windows_hosts = sys.argv[1]
    linux_hosts = sys.argv[2]

    transfer = FileTransfer(windows_hosts, linux_hosts)
    transfer.run()
