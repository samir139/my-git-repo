import paramiko, sys, os, platform, time
from configparser import ConfigParser
from datetime import datetime

def execute_command(host, port, username, private_key_path,password, command):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        private_key=paramiko.RSAKey.from_private_key_file(private_key_path)
        ssh.connect(hostname=host,port=port,username=username, pkey=private_key)
        stdin, stdout, stderr = ssh.exec_command(command)

        for line in stdout:
            print(line.strip(), flush=True)
        print(stdout.read().decode(), flush=True)
    except:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(hostname=host, port=port, username=username, password=password)
        stdin, stdout, stderr = ssh.exec_command(command)

        for line in stdout:
            print(line.strip(), flush=True)
        print(stdout.read().decode(), flush=True)

def main(argv):
    now = datetime.now()
    try:
        host = sys.argv[1]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)

    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', 'applyBuild.ini'))
    hostname=host.split('.')[0]
    port = parser['REGION_DETAILS']['port']
    username = parser['REGION_DETAILS']['username']
    password = parser['REGION_DETAILS']['password']
    private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'],hostname)
    apply_patch = parser['APPLY_BUILD']['Apply_Patch']

    upgrade_path = parser['BUILD_DIR']['stagingAppPath']

    if apply_patch == '1':
        print('Applying EAGLEPATCH to Hostname:', host)
        eaglepatch_path = os.path.join(str(parser['BUILD_DIR']['stagingAppPath']) +
                                       str(parser['VERSION']['build_version']) +
                                       '/EAGLE_PATCH')
        print(eaglepatch_path)
        copy_edm_files_cmd = 'cd ' + parser['BUILD_DIR']['stagingAppPath'] + ' && cp -r eaglepatch.ini ' + eaglepatch_path
        exec_eaglepatch = 'cd '+ eaglepatch_path +' && ./setup.sh'
        print("Apply EAGLEPATCH START TIME:", now.strftime("%d/%m/%Y %H:%M:%S"))
        execute_command(host, port, username, private_key_path,password, exec_eaglepatch)
        print("Apply EAGLEPATCH END TIME:", now.strftime("%d/%m/%Y %H:%M:%S"))
    else:
        print('No EAGLEPATCH build to be applied on', host)

if __name__ == "__main__":
    main(sys.argv)
