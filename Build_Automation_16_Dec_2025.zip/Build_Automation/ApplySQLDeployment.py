import os, sys, wmi, time, subprocess, winrm, concurrent.futures
from datetime import datetime
from configparser import ConfigParser
from multiprocessing.pool import ThreadPool
from multiprocessing import Process
from subprocess import Popen

import configdetails
import jiradetails
import shareDriveMap
import fileHandling

from dotenv import load_dotenv
load_dotenv('.env')


def readKeyStorage(winPrivateKey):
    with open(winPrivateKey, 'r') as file:
        password = file.read()
    return password

def start_remote_service(services, remote_host, username, password):
    try:
        connection = winrm.Session(remote_host, auth=(username, password), transport='ntlm')
        print('connection established to the ', remote_host)
        for service_name in services.split(','):
            result = connection.run_cmd(f"sc start {service_name}")
            output = result.std_out.decode()
            print(output)
            if result.status_code == 0:
                print(f'the {service_name} service are started in {remote_host}')
            else:
                print(f"{service_name} is already started in {remote_host}")
    except Exception as e:
        print(str(e))

def stop_remote_service(services, remote_host, username, password):
    try:
        connection = winrm.Session(remote_host, auth=(username, password), transport='ntlm')
        print('connection established to the ', remote_host)
        for service_name in services.split(','):
            result = connection.run_cmd(f"sc stop {service_name}")
            output = result.std_out.decode()
            print(output)
            if result.status_code == 0:
                print(f'the {service_name} service has been stopped in {remote_host}')
            else:
                print(f"{service_name} is already stopped in {remote_host}")
    except Exception as e:
        print(str(e))

def run_python_script(script_path, *args):
    # Use subprocess to run the Python script with any additional arguments
    command = ['python', script_path] + list(args)
    result = subprocess.run(command, capture_output=True, text=True)
    return result.stdout

def run_parallel_scripts(scripts):
    # Using ProcessPoolExecutor to run the scripts in parallel
    with concurrent.futures.ProcessPoolExecutor() as executor:
        # Submit tasks to run the scripts with their arguments
        futures = [executor.submit(run_python_script, script[0], *script[1:]) for script in scripts]

        # Collect the results as they complete
        for future in concurrent.futures.as_completed(futures):
            print(future.result())

def apply_DB(parser, app_edm_loc, edm_path, pkg_path, build_version, username, password):
    print('Map Application Tier Share Path.')
    shareDriveMap.mapDrive(parser['ShareDrive_Details']['win_app_share_drive'],
                           parser['APP_TIER_DETAIL']['stage_loc'],
                           username, password)

    try:
        os.chdir(os.path.join(app_edm_loc + '\\common'))
        app_edm_execute_sql_file = os.path.join(app_edm_loc + '\\common\\execute_sql.cmd')
        if os.path.isfile(app_edm_execute_sql_file):
            fileHandling.replace_string(app_edm_execute_sql_file, parser['APP_TIER_DETAIL']['executesqlLine'],
                                        parser['APP_TIER_DETAIL']['NexecutesqlLine'])
        else:
            print('Please manually copy or edit the execute_sql.cmd file in App Tier & re-apply EDM.')

        os.chdir(
            os.path.join(parser['ShareDrive_Details']['win_app_share_drive'] + '\\' + build_version + '\\' + edm_path))
        edm_setup_file = os.path.join(parser['ShareDrive_Details'][
                                          'win_app_share_drive'] + '\\' + build_version + '\\' + edm_path + '\\edm_setup.cmd')
        fileHandling.delete_lines(edm_setup_file, 3)
        time.sleep(300)
        print('Applying EDM & Package Scripts')
        start_time = datetime.now().time().strftime('%H:%M:%S')
        print('Applying EDM Started at', start_time)
        os.system(parser['APP_TIER_DETAIL']['edmsetupexec'])
        end_time = datetime.now().time().strftime('%H:%M:%S')
        total_time = (datetime.strptime(end_time, '%H:%M:%S') - datetime.strptime(start_time, '%H:%M:%S'))
        print('Applying EDM Completed at', end_time)
        print('Total time taken for Applying EDM', str(total_time))
        time.sleep(300)
        start_time = datetime.now().time().strftime('%H:%M:%S')
        print('Applying Package Started at', start_time)
        os.chdir(
            os.path.join(parser['ShareDrive_Details']['win_app_share_drive'] + '\\' + build_version + '\\' + pkg_path))
        os.system(parser['APP_TIER_DETAIL']['packageexec'])
        end_time = datetime.now().time().strftime('%H:%M:%S')
        total_time = (datetime.strptime(end_time, '%H:%M:%S') - datetime.strptime(start_time, '%H:%M:%S'))
        print('Applying Package Completed at', end_time)
        print('Total time taken for Applying Package', str(total_time))

    except OSError as error:
        print('Failed to execute erd and package')

    print('Un-Map Application Tier Share Path.')
    shareDriveMap.unmapDrive(parser['ShareDrive_Details']['win_app_share_drive'])

def main(argv):
    now = datetime.now()
    try:
        host = sys.argv[1]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)
    build_version = os.environ.get('build_version')
    build_ini_file = host[0:host.find('-', host.find('-')+1)] + '.ini'
    if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
        print(build_ini_file, 'file present.')
    else:
        print(build_ini_file, 'file missing.')
        sys.exit(2)
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))

    build_details, build_version, build_number, build_status = jiradetails.get_jira_details()

    print('Changing Staging Folders in Application/Reporting/Web Tiers START TIME :',
          datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    if os.path.exists(os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version)):
        fileHandling.rename_directory(os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version))
    if os.path.exists(os.path.join(parser['REPORT_TIER_DETAIL']['stage_loc'], build_version)):
        fileHandling.rename_directory(os.path.join(parser['REPORT_TIER_DETAIL']['stage_loc'], build_version))
    if os.path.exists(os.path.join(parser['WEB_TIER_DETAIL']['stage_loc'], build_version)):
        fileHandling.rename_directory(os.path.join(parser['WEB_TIER_DETAIL']['stage_loc'], build_version))
    print('Changing Staging Folders in Application/Reporting/Web Tiers END TIME :',
          datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))

    print('Defining Staging Directories in all servers')
    build_version = build_version
    build_trim_ver = build_version.replace(build_version[:7], '')
    root_stage = os.path.join(os.environ.get('dailyBuild_path'), build_version)
    edm_path = os.path.join('DATABASE\\eagle_erd_' + build_trim_ver + '\\mssql')
    pkg_path = os.path.join('DATABASE\\packages_' + build_trim_ver + '\\mssql')
    root_stage_edm = os.path.join(root_stage, edm_path)
    root_stage_pkg = os.path.join((root_stage), pkg_path)
    root_stage_patch = os.path.join(root_stage, 'EAGLE_PATCH')
    app_edm_loc = os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version, edm_path)
    app_pkg_loc = os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version, pkg_path)
    app_patch_loc = os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version, 'EAGLE_PATCH')
    rpt_patch_loc = os.path.join(parser['REPORT_TIER_DETAIL']['stage_loc'], build_version, 'EAGLE_PATCH')
    web_patch_loc = os.path.join(parser['WEB_TIER_DETAIL']['stage_loc'], build_version, 'EAGLE_PATCH')

    print('Daily Build Startx Location            : ', root_stage)
    print('Daily Build Startx EDM Location        : ', root_stage_edm)
    print('Daily Build Startx Package Location    : ', root_stage_pkg)
    print('Daily Build Startx EAGLEPATCH Location : ', root_stage_patch)
    print('Application Tier EDM Location          : ', app_edm_loc)
    print('Application Tier Package Location      : ', app_pkg_loc)
    print('Application Tier EAGLEPATCH Location   : ', app_patch_loc)
    print('REPORT Tier EAGLEPATCH Location        : ', rpt_patch_loc)
    print('WEB Tier EAGLEPATCH Location           : ', web_patch_loc)

    print('Copying Staging files from DailyBuilds location to Staging Location START TIME :',
          datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    fileHandling.StageFileCopy(root_stage_edm, app_edm_loc)
    fileHandling.StageFileCopy(root_stage_pkg, app_pkg_loc)
    fileHandling.StageFileCopy(root_stage_patch, app_patch_loc)
    fileHandling.StageFileCopy(root_stage_patch, rpt_patch_loc)
    fileHandling.StageFileCopy(root_stage_patch, web_patch_loc)
    print('Copying Staging files from DailyBuilds location to Staging Location END TIME :',
          datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))

    username = parser['REGION_DETAILS']['username']
    winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
    password = readKeyStorage(winPrivateKey)

    stop_remote_service(str(parser['WEB_TIER_DETAIL']['services']), parser['WEB_TIER_DETAIL']['hostname'], username, password)
    stop_remote_service(str(parser['REPORT_TIER_DETAIL']['services']), parser['REPORT_TIER_DETAIL']['hostname'], username, password)
    stop_remote_service(str(parser['APP_TIER_DETAIL']['services']), parser['APP_TIER_DETAIL']['hostname'], username, password)

    time.sleep(900)
    
    print('Deleting Log Files. START TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    fileHandling.delete_log_files(parser['APP_TIER_DETAIL']['hostname'])
    fileHandling.delete_log_files(parser['REPORT_TIER_DETAIL']['hostname'])
    fileHandling.delete_log_files(parser['WEB_TIER_DETAIL']['hostname'])
    print('Deleting Log Files. END TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    
    print('Deleting bkp Files. START TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    fileHandling.delete_bkp_files(parser['APP_TIER_DETAIL']['hostname'])
    fileHandling.delete_bkp_files(parser['REPORT_TIER_DETAIL']['hostname'])
    fileHandling.delete_bkp_files(parser['WEB_TIER_DETAIL']['hostname'])
    print('Deleting bkp Files. END TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))

    apply_DB(parser, app_edm_loc, edm_path, pkg_path, build_version, username, password)
    
    print('Applying EAGLEPATCH in WEB/REPORT & APPLICATION Tiers. START TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    
    os.chdir('E:\\Build_Automation')
    py_command_app = ' python ' + 'EA_ApplyWinEaglePatch.py ' + ' APP ' + parser['APP_TIER_DETAIL']['hostname']
    print('Command to execute is:', py_command_app)
    #subprocess.call(py_command_app, shell=True)
    
    py_command_rpt = ' python ' + 'EA_ApplyWinEaglePatch.py ' + ' RPT ' + parser['REPORT_TIER_DETAIL']['hostname']
    print('Command to execute is:', py_command_rpt)
    #subprocess.call(py_command_rpt, shell=True)
    
    py_command_web = ' python ' + 'EA_ApplyWinEaglePatch.py ' + ' WEB ' + parser['WEB_TIER_DETAIL']['hostname']
    print('Command to execute is:', py_command_web)
    #subprocess.call(py_command_web, shell=True)
    
    apply_eaglepatch = [
        ("EA_ApplyWinEaglePatch.py", "APP", parser['APP_TIER_DETAIL']['hostname']),
        ("EA_ApplyWinEaglePatch.py", "RPT", parser['REPORT_TIER_DETAIL']['hostname']),
        ("EA_ApplyWinEaglePatch.py", "WEB", parser['WEB_TIER_DETAIL']['hostname']),
    ]
    
    run_parallel_scripts(apply_eaglepatch)

    print('Applying EAGLEPATCH in WEB/REPORT & APPLICATION Tiers. END TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    
    print('Apply Post-upgrade Steps. START TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    folder_name = host[0:host.find('-', host.find('-')+1)]
    
    if parser['ENV_Details']['region'] == 'EARTH':
        db_cleanup_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','EARTH_SQL_'+ folder_name,'Utils','PostUpgradeSteps')
        db_cleanup_script = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','EARTH_SQL_'+ folder_name,'Utils','PostUpgradeSteps','EARTH_SQL_Post_Upgrade_DB_Cleanup.bat')
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, db_cleanup_script)
        fileHandling.delete_msgcenterfiles(parser['APP_TIER_DETAIL']['msgcenterLoc_1'])
        fileHandling.delete_msgcenterfiles(parser['APP_TIER_DETAIL']['msgcenterLoc_2'])
        fileHandling.delete_msgcenterfiles(parser['APP_TIER_DETAIL']['msgcenterLoc_3'])
        fileHandling.delete_msgcenterfiles(parser['APP_TIER_DETAIL']['msgcenterLoc_4'])
    
    if parser['ENV_Details']['region'] == 'DMFARM':
        db_cleanup_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','DMFARM_SQL_'+ folder_name,'Utils','PostUpgradeSteps')
        db_cleanup_script = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','DMFARM_SQL_'+ folder_name,'Utils','PostUpgradeSteps','DM_FARM_SQL_Post_Upgrade_DB_Cleanup.bat')
        reset_farm_cycle_copy = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','DMFARM_SQL_'+ folder_name,'Utils','PostUpgradeSteps','DM_FARM_SQL_Reset_Farm_Cycle_Copy.bat')
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, db_cleanup_script)
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, reset_farm_cycle_copy)
    
    if parser['ENV_Details']['region'] == 'PERFFARM':
        db_cleanup_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','PERF_SQL_'+ folder_name,'Utils','PostUpgradeSteps')
        db_cleanup_script = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','PERF_SQL_'+ folder_name,'Utils','PostUpgradeSteps','PERF_SQL_Post_Upgrade_DB_Cleanup.bat')
        adv_dll_register = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','PERF_SQL_'+ folder_name,'Utils','PostUpgradeSteps','PERF_SQL_Post_Upgrade_RegisterDLL.bat')
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, db_cleanup_script)
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, adv_dll_register)
        fileHandling.deleteDepositDir(parser['APP_TIER_DETAIL']['depositFolder'])
    print('Apply Post-upgrade Steps. END TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))


    print('Starting Eagle services in WEB/REPORT & APPLICATION Tiers. START TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    start_remote_service(str(parser['WEB_TIER_DETAIL']['services']), parser['WEB_TIER_DETAIL']['hostname'], username, password)
    start_remote_service(str(parser['REPORT_TIER_DETAIL']['services']), parser['REPORT_TIER_DETAIL']['hostname'], username, password)
    start_remote_service(str(parser['APP_TIER_DETAIL']['services']), parser['APP_TIER_DETAIL']['hostname'], username, password)
    print('Starting Eagle services completed in WEB/REPORT & APPLICATION Tiers. END TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))


if __name__ == "__main__":
    main(sys.argv)
