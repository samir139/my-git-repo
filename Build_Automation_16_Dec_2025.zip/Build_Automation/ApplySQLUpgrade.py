import os, sys, wmi, time, subprocess
from datetime import datetime
from configparser import ConfigParser
from multiprocessing.pool import ThreadPool
from multiprocessing import Process
from subprocess import Popen

import configdetails
import jiradetails
import shareDriveMap
#import emailsender
import fileHandling
import ApplyWinEaglePatch
import eagleServices
#import InvsysApplyWinEaglePatch

from dotenv import load_dotenv
load_dotenv('.env')


def main(argv):
    now = datetime.now()
    try:
        build_type = sys.argv[1]
        host = sys.argv[2]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)
    build_version = os.environ.get('build_version')
    build_ini_file = host[0:host.find('-', host.find('-')+1)] + '.ini'
    if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
        print(build_ini_file, 'file present.')
    else:
        print(build_ini_file, 'file missing.')
        sys.exit(2)
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))

    build_details, build_version, build_number, build_status = jiradetails.get_jira_details()

#    if build_status != 'Deployed To QA':
#        print('Build not yet ready to apply in regression regions.')
#        sys.exit(2)

    #print('Build Number to be applied is :', build_number)
#    status = fileHandling.readBuildAppliedNumber(build_number)
#    if status == True:
#        print('Build Already Applied in the regression regions.')
#        sys.exit(2)

    down_email = 'The ' + build_version + \
                 ' ' + parser['ENV_Details']['region'] + \
                 ' ' + parser['ENV_Details']['server'] + \
                 ' environment is going down now for upgrade with the latest build'

    up_email = 'The ' + build_version + \
               ' ' + parser['ENV_Details']['region'] + \
               ' ' + parser['ENV_Details']['server'] + \
               ' environment is back online after upgrading to the latest build'

    if build_type == 'APP' or build_type == 'ALL':
        try:
            app_conn = wmi.WMI(parser['APP_TIER_DETAIL']['hostname'], user=parser['APP_TIER_DETAIL']['username'],
                               password=parser['APP_TIER_DETAIL']['password'])
            print(parser['APP_TIER_DETAIL']['hostname'], 'Connection Established')
        except Exception as error:
            print('Failed to Establish Connection to Application Tier')
    if build_type == 'RPT' or build_type == 'ALL':
        try:
            rpt_conn = wmi.WMI(parser['REPORT_TIER_DETAIL']['hostname'], user=parser['REPORT_TIER_DETAIL']['username'],
                               password=parser['REPORT_TIER_DETAIL']['password'])
            print(parser['REPORT_TIER_DETAIL']['hostname'], 'Connection Established')
        except Exception as error:
            print('Failed to Establish Connection to Report Tier')
    if build_type == 'WEB' or build_type == 'ALL':
        try:
            web_conn = wmi.WMI(parser['WEB_TIER_DETAIL']['hostname'], user=parser['WEB_TIER_DETAIL']['username'],
                               password=parser['WEB_TIER_DETAIL']['password'])
            print(parser['WEB_TIER_DETAIL']['hostname'], 'Connection Established')
        except Exception as error:
            print('Failed to Establish Connection to Web Tier')

    print('Changing Staging Folders in Application/Reporting/Web Tiers START TIME :',
          datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    if os.path.exists(os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version)):
        fileHandling.rename_directory(os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version))
    if os.path.exists(os.path.join(parser['REPORT_TIER_DETAIL']['stage_loc'], build_version)):
        fileHandling.rename_directory(os.path.join(parser['REPORT_TIER_DETAIL']['stage_loc'], build_version))
    if os.path.exists(os.path.join(parser['WEB_TIER_DETAIL']['stage_loc'], build_version)):
        fileHandling.rename_directory(os.path.join(parser['WEB_TIER_DETAIL']['stage_loc'], build_version))
    print('Changing Staging Folders in Application/Reporting/Web Tiers END TIME :',
          datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))

    print('Defining Staging Directories in all servers')
    build_version = build_version
    build_trim_ver = build_version.replace(build_version[:7], '')
    root_stage = os.path.join(os.environ.get('dailyBuild_path'), build_version)
    #root_stage = os.path.join(os.environ.get('dailyBuild_path'))
    edm_path = os.path.join('DATABASE\\eagle_erd_' + build_trim_ver + '\\mssql')
    pkg_path = os.path.join('DATABASE\\packages_' + build_trim_ver + '\\mssql')
    root_stage_edm = os.path.join(root_stage, edm_path)
    root_stage_pkg = os.path.join((root_stage), pkg_path)
    root_stage_patch = os.path.join(root_stage, 'EAGLE_PATCH')
    app_edm_loc = os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version, edm_path)
    app_pkg_loc = os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version, pkg_path)
    app_patch_loc = os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version, 'EAGLE_PATCH')
    rpt_patch_loc = os.path.join(parser['REPORT_TIER_DETAIL']['stage_loc'], build_version, 'EAGLE_PATCH')
    web_patch_loc = os.path.join(parser['WEB_TIER_DETAIL']['stage_loc'], build_version, 'EAGLE_PATCH')

    print('Daily Build Startx Location            : ', root_stage)
    print('Daily Build Startx EDM Location        : ', root_stage_edm)
    print('Daily Build Startx Package Location    : ', root_stage_pkg)
    print('Daily Build Startx EAGLEPATCH Location : ', root_stage_patch)
    print('Application Tier EDM Location          : ', app_edm_loc)
    print('Application Tier Package Location      : ', app_pkg_loc)
    print('Application Tier EAGLEPATCH Location   : ', app_patch_loc)
    print('REPORT Tier EAGLEPATCH Location        : ', rpt_patch_loc)
    print('WEB Tier EAGLEPATCH Location           : ', web_patch_loc)

    print('Copying Staging files from DailyBuilds location to Staging Location START TIME :',
          datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    if build_type == 'APP' or build_type == 'ALL':
        fileHandling.StageFileCopy(root_stage_edm, app_edm_loc)
        fileHandling.StageFileCopy(root_stage_pkg, app_pkg_loc)
        fileHandling.StageFileCopy(root_stage_patch, app_patch_loc)
    if build_type == 'RPT' or build_type == 'ALL':
        fileHandling.StageFileCopy(root_stage_patch, rpt_patch_loc)
    if build_type == 'WEB' or build_type == 'ALL':
        fileHandling.StageFileCopy(root_stage_patch, web_patch_loc)
    print('Copying Staging files from DailyBuilds location to Staging Location END TIME :',
          datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))

    #emailsender.send_email(down_email, build_details)

    app_svc = parser['APP_TIER_DETAIL']['services'].split (",")
    rpt_svc = parser['REPORT_TIER_DETAIL']['services'].split (",")
    web_svc = parser['WEB_TIER_DETAIL']['services'].split (",")
    
    stop_app_services = Process(target=eagleServices.win_stop_services(app_conn, parser['APP_TIER_DETAIL']['hostname'], app_svc))
    stop_app_services.start()
    stop_rpt_services = Process(target=eagleServices.win_stop_services(rpt_conn, parser['REPORT_TIER_DETAIL']['hostname'], rpt_svc))
    stop_rpt_services.start()
    stop_web_services = Process(target=eagleServices.win_stop_services(web_conn, parser['WEB_TIER_DETAIL']['hostname'], web_svc))
    stop_web_services.start()
    stop_app_services.join()
    stop_rpt_services.join()
    stop_web_services.join()

    time.sleep(300)

    print('Deleting Log Files. START TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    fileHandling.delete_log_files(parser['APP_TIER_DETAIL']['hostname'])
    fileHandling.delete_log_files(parser['REPORT_TIER_DETAIL']['hostname'])
    fileHandling.delete_log_files(parser['WEB_TIER_DETAIL']['hostname'])
    print('Deleting Log Files. END TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))

    print('Deleting bkp Files. START TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    fileHandling.delete_bkp_files(parser['APP_TIER_DETAIL']['hostname'])
    fileHandling.delete_bkp_files(parser['REPORT_TIER_DETAIL']['hostname'])
    fileHandling.delete_bkp_files(parser['WEB_TIER_DETAIL']['hostname'])
    print('Deleting bkp Files. END TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    
    print('Map Application Tier Share Path.')
    shareDriveMap.mapDrive(parser['ShareDrive_Details']['win_app_share_drive'],
                           parser['APP_TIER_DETAIL']['stage_loc'],
                           parser['APP_TIER_DETAIL']['username'],
                           parser['APP_TIER_DETAIL']['password'])
    
    try:
        os.chdir(os.path.join(app_edm_loc + '\\common'))
        app_edm_execute_sql_file = os.path.join(app_edm_loc + '\\common\\execute_sql.cmd')
        if os.path.isfile(app_edm_execute_sql_file):
            fileHandling.replace_string(app_edm_execute_sql_file, parser['APP_TIER_DETAIL']['executesqlLine'], parser['APP_TIER_DETAIL']['NexecutesqlLine'])
        else:
            print('Please manually copy or edit the execute_sql.cmd file in App Tier & re-apply EDM.')
            
        os.chdir(os.path.join(parser['ShareDrive_Details']['win_app_share_drive'] + '\\' + build_version + '\\' + edm_path))
        edm_setup_file = os.path.join(parser['ShareDrive_Details']['win_app_share_drive'] + '\\' + build_version + '\\' + edm_path + '\\edm_setup.cmd')
        fileHandling.delete_lines(edm_setup_file,3)
        time.sleep(300)
        print('Applying EDM & Package Scripts')
        start_time = datetime.now().time().strftime('%H:%M:%S')
        print('Applying EDM Started at', start_time)
        os.system(parser['APP_TIER_DETAIL']['edmsetupexec'])
        end_time = datetime.now().time().strftime('%H:%M:%S')
        total_time=(datetime.strptime(end_time,'%H:%M:%S') - datetime.strptime(start_time,'%H:%M:%S'))
        print('Applying EDM Completed at', end_time)
        print('Total time taken for Applying EDM', str(total_time))
        time.sleep(300)
        start_time = datetime.now().time().strftime('%H:%M:%S')
        print('Applying Package Started at', start_time)
        os.chdir(os.path.join(parser['ShareDrive_Details']['win_app_share_drive'] + '\\' + build_version + '\\' + pkg_path))
        os.system(parser['APP_TIER_DETAIL']['packageexec'])  
        end_time = datetime.now().time().strftime('%H:%M:%S')
        total_time=(datetime.strptime(end_time,'%H:%M:%S') - datetime.strptime(start_time,'%H:%M:%S'))
        print('Applying Package Completed at', end_time)
        print('Total time taken for Applying Package', str(total_time))
    
    except OSError as error:
        print('Failed to execute erd and package')
    
    print('Applying EAGLEPATCH in WEB/REPORT & APPLICATION Tiers. START TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    #apply_app_eaglePatch = Process(target=ApplyWinEaglePatch.Apply_EaglePatch(app_conn, app_patch_loc,
    #                                                                          parser['APP_TIER_DETAIL']['hostname'],
    #                                                                          parser['APP_TIER_DETAIL']['StaticConfig'],
    #                                                                          parser['APP_TIER_DETAIL']['INSTDIR_EMShell']))
    #apply_app_eaglePatch.start()
    #apply_rpt_eaglePatch = Process(target=ApplyWinEaglePatch.Apply_EaglePatch(rpt_conn, rpt_patch_loc,
    #                                                                          parser['REPORT_TIER_DETAIL']['hostname'],
    #                                                                          parser['REPORT_TIER_DETAIL']['StaticConfig'],
    #                                                                          parser['REPORT_TIER_DETAIL']['INSTDIR_EMShell']))
    #apply_rpt_eaglePatch.start()
    #apply_web_eaglePatch = Process(target=ApplyWinEaglePatch.Apply_EaglePatch(web_conn, web_patch_loc,
    #                                                                          parser['WEB_TIER_DETAIL']['hostname'],
    #                                                                          parser['WEB_TIER_DETAIL']['StaticConfig'],
    #                                                                          parser['WEB_TIER_DETAIL']['INSTDIR_EMShell']))
    #apply_web_eaglePatch.start()
    #apply_app_eaglePatch.join()
    #apply_rpt_eaglePatch.join()
    #apply_web_eaglePatch.join()

    os.chdir('E:\\Build_Automation')
    py_command = ' python ' + 'InvsysApplyWinEaglePatch.py ' + parser['APP_TIER_DETAIL']['hostname'] + ' APP'
    print('Command to execute is:', py_command)
    subprocess.call(py_command, shell=True)

    py_command = ' python ' + 'InvsysApplyWinEaglePatch.py ' + parser['REPORT_TIER_DETAIL']['hostname'] + ' RPT'
    print('Command to execute is:', py_command)
    subprocess.call(py_command, shell=True)

    py_command = ' python ' + 'InvsysApplyWinEaglePatch.py ' + parser['WEB_TIER_DETAIL']['hostname'] + ' WEB'
    print('Command to execute is:', py_command)
    subprocess.call(py_command, shell=True)

    print('Applying EAGLEPATCH in WEB/REPORT & APPLICATION Tiers. END TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    
    print('Apply Post-upgrade Steps. START TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    folder_name = host[0:host.find('-', host.find('-')+1)]

    if parser['ENV_Details']['region'] == 'EARTH':
        db_cleanup_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','EARTH_SQL_'+ folder_name,'Utils','PostUpgradeSteps')
        db_cleanup_script = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','EARTH_SQL_'+ folder_name,'Utils','PostUpgradeSteps','EARTH_SQL_Post_Upgrade_DB_Cleanup.bat')
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, db_cleanup_script)
        fileHandling.delete_msgcenterfiles(parser['APP_TIER_DETAIL']['msgcenterLoc_1'])
        fileHandling.delete_msgcenterfiles(parser['APP_TIER_DETAIL']['msgcenterLoc_2'])
        fileHandling.delete_msgcenterfiles(parser['APP_TIER_DETAIL']['msgcenterLoc_3'])
        fileHandling.delete_msgcenterfiles(parser['APP_TIER_DETAIL']['msgcenterLoc_4'])
    
    if parser['ENV_Details']['region'] == 'DMFARM':
        db_cleanup_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','DMFARM_SQL_'+ folder_name,'Utils','PostUpgradeSteps')
        db_cleanup_script = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','DMFARM_SQL_'+ folder_name,'Utils','PostUpgradeSteps','DM_FARM_SQL_Post_Upgrade_DB_Cleanup.bat')
        reset_farm_cycle_copy = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','DMFARM_SQL_'+ folder_name,'Utils','PostUpgradeSteps','DM_FARM_SQL_Reset_Farm_Cycle_Copy.bat')
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, db_cleanup_script)
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, reset_farm_cycle_copy)
    
    if parser['ENV_Details']['region'] == 'PERFFARM':
        db_cleanup_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','PERF_SQL_'+ folder_name,'Utils','PostUpgradeSteps')
        db_cleanup_script = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','PERF_SQL_'+ folder_name,'Utils','PostUpgradeSteps','PERF_SQL_Post_Upgrade_DB_Cleanup.bat')
        adv_dll_register = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','PERF_SQL_'+ folder_name,'Utils','PostUpgradeSteps','PERF_SQL_Post_Upgrade_RegisterDLL.bat')
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, db_cleanup_script)
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, adv_dll_register)
        #fileHandling.deleteDir(parser['APP_TIER_DETAIL']['depositFolder'])
        fileHandling.deleteDepositDir(parser['APP_TIER_DETAIL']['depositFolder'])
    print('Apply Post-upgrade Steps. END TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    
    print('Starting Eagle services in WEB/REPORT & APPLICATION Tiers. START TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    start_app_services = Process(target=eagleServices.win_start_services(app_conn, parser['APP_TIER_DETAIL']['hostname'], app_svc))
    start_app_services.start()
    start_rpt_services = Process(target=eagleServices.win_start_services(rpt_conn, parser['REPORT_TIER_DETAIL']['hostname'], rpt_svc))
    start_rpt_services.start()
    start_web_services = Process(target=eagleServices.win_start_services(web_conn, parser['WEB_TIER_DETAIL']['hostname'], web_svc))
    start_web_services.start()
    start_app_services.join()
    start_rpt_services.join()
    start_web_services.join()
    print('Starting Eagle services completed in WEB/REPORT & APPLICATION Tiers. END TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    
    #emailsender.send_email(up_email, build_details)
    #fileHandling.writeBuildAppliedNumber(build_number)
    
    print('Un-Map Application Tier Share Path.')
    shareDriveMap.unmapDrive(parser['ShareDrive_Details']['win_app_share_drive'])


if __name__ == "__main__":
    main(sys.argv)
