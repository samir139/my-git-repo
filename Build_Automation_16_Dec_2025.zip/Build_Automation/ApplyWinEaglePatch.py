import os
from datetime import datetime

import fileHandling

def Apply_EaglePatch(conn, patch_loc, hostname, StaticConfig, INSTDIR_EMShell):
    print('Apply Eagle Patch')
    if os.path.exists(patch_loc):
        path_ini = os.path.join(patch_loc + '\eaglepatch.ini')
        path_exe = os.path.join(patch_loc + '\eaglepatch.exe')
        if os.path.isfile(path_ini):
            try:
                start_time = datetime.now().time().strftime('%H:%M:%S')
                fileHandling.replace_string(path_ini,"SilentMode=0","SilentMode=1")
                fileHandling.replace_string(path_ini,"Delta=1","Delta=0")
                fileHandling.replace_string(path_ini,"~/eagle/eaglemgr/config/eaglepatch.ini",StaticConfig)
                fileHandling.replace_string(path_ini,"~/eagle/",INSTDIR_EMShell)
                startup = conn.Win32_ProcessStartup.new(ShowWindow=1)
                #conn.Win32_Process.Create(CommandLine=path_exe, ProcessStartupInformation=startup)
                process_id, result = conn.Win32_Process.Create(CommandLine=path_exe, ProcessStartupInformation=startup)
                watcher = conn.watch_for(
                        notification_type="Deletion",
                        wmi_class="Win32_Process",
                        delay_secs=1,
                        ProcessId=process_id
                    )
                watcher()
                end_time = datetime.now().time().strftime('%H:%M:%S')
                total_time=(datetime.strptime(end_time,'%H:%M:%S') - datetime.strptime(start_time,'%H:%M:%S'))
                print('Started applying Eagle Patch', hostname, start_time)
                print('Completed applying Eagle Patch', hostname, end_time)
                print('Total time taken to apply Eagle Patch', hostname, str(total_time))
            except OSError as error:
                print('Failed to apply Eagle Patch', hostname)
        else:
            print('Failed to apply Eagle Patch', hostname)
        fileHandling.check_patching_status(patch_loc, hostname)
    else:
        print(hostname, ' : EAGLEPATCH Path Missing.')