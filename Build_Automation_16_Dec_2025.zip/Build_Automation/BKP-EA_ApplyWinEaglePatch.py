import os, sys, wmi, win32wnet,winrm, glob
from configparser import ConfigParser
from datetime import datetime

from dotenv import load_dotenv

load_dotenv()

import fileHandling


def Apply_EaglePatch(conn, patch_loc, stage_loc, hostname, StaticConfig, INSTDIR_EMShell):
    print('Apply Eagle Patch')
    if os.path.exists(patch_loc):
        path_ini = os.path.join(patch_loc + '\\eaglepatch.ini')
        path_exe = os.path.join(stage_loc + '\\eaglepatch.exe')
        if os.path.isfile(path_ini):
            try:
                start_time = datetime.now().time().strftime('%H:%M:%S')
                fileHandling.replace_string(path_ini, "SilentMode=0", "SilentMode=1")
                #fileHandling.replace_string(path_ini, "Delta=1", "Delta=0")
                fileHandling.replace_string(path_ini, "~/eagle/eaglemgr/config/eaglepatch.ini", StaticConfig)
                fileHandling.replace_string(path_ini, "~/eagle/", INSTDIR_EMShell)
                print('Started applying Eagle Patch', hostname, start_time)
                result = conn.run_ps(path_exe)
                output = result.std_out.decode()
                print(output)
                end_time = datetime.now().time().strftime('%H:%M:%S')
                if result.status_code == 0:
                    print('Completed applying Eagle Patch', hostname, end_time)
                else:
                    print("failed to run eaglepatch.exe File ")
                total_time = (datetime.strptime(end_time, '%H:%M:%S') - datetime.strptime(start_time, '%H:%M:%S'))
                print('Total time taken to apply Eagle Patch', hostname, str(total_time))
            except OSError as error:
                print('Failed to apply Eagle Patch', hostname)
        else:
            print('Failed to apply Eagle Patch', hostname)
        fileHandling.check_patching_status(patch_loc, hostname)
    else:
        print(hostname, ' : EAGLEPATCH Path Missing.')


def main(argv):
    type = sys.argv[1]
    hostname = sys.argv[2]
    for host in hostname.split(','):
        build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
        print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        build_version = os.environ.get('build_version')
    if type == 'RPT':
        print(host)
        username = parser['REPORT_TIER_DETAIL']['username']
        password = parser['REPORT_TIER_DETAIL']['password']

        try:
            conn = winrm.Session(host,auth=(username,password),transport='ntlm')
            print('Connection Established to', host)
        except Exception as error:
            print('Failed to Establish Connection to', host)

        StaticConfig = parser['REPORT_TIER_DETAIL']['StaticConfig']
        INSTDIR_EMShell = parser['REPORT_TIER_DETAIL']['INSTDIR_EMShell']
        stage_loc = os.path.join(parser['REPORT_TIER_DETAIL']['stagePath'],build_version, 'EAGLE_PATCH')
        patch_loc = os.path.join('\\\\', host, 'Eagle_Install\\Stage', build_version, 'EAGLE_PATCH')
        print(patch_loc)
        
        try:
            win32wnet.WNetAddConnection2(0, None, patch_loc, None, username, password)
            print('connection sucessful to make changes in ini file')
        except Exception as error:
            print(str(error))
        Apply_EaglePatch(conn, patch_loc, stage_loc, hostname, StaticConfig, INSTDIR_EMShell)
    if type == 'WEB':
        print(host)
        username = parser['WEB_TIER_DETAIL']['username']
        password = parser['WEB_TIER_DETAIL']['password']
        try:
            conn = winrm.Session(host,auth=(username,password),transport='ntlm')
            print('Connection Established to', host)
        except Exception as error:
            print('Failed to Establish Connection to', host)
        StaticConfig = parser['WEB_TIER_DETAIL']['StaticConfig']
        INSTDIR_EMShell = parser['WEB_TIER_DETAIL']['INSTDIR_EMShell']
        stage_loc = os.path.join(parser['WEB_TIER_DETAIL']['stagePath'],build_version, 'EAGLE_PATCH')
        patch_loc = os.path.join('\\\\', host, 'Eagle_Install\\Stage', build_version, 'EAGLE_PATCH')
        print(patch_loc)
        
        try:
            win32wnet.WNetAddConnection2(0, None, patch_loc, None, username, password)
            print('connection sucessful to make changes in ini file')
        except Exception as error:
            print(str(error))
        Apply_EaglePatch(conn, patch_loc, stage_loc, hostname, StaticConfig, INSTDIR_EMShell)


if __name__ == "__main__":
    main(sys.argv)
