import sys
import jiradetails
import fileHandling

class CheckBuildAppliedStatus():
    @staticmethod
    def checkStatus(buildStatus, status):
        if buildStatus != 'Deployed To QA':
            print('Build not yet ready to apply in regression regions.')
            sys.exit(2)

        if status == True:
            print('Build Already Applied in the regression regions.')
            sys.exit(2)

build_details, build_version, build_number, build_status = jiradetails.get_jira_details()
status = fileHandling.readBuildAppliedNumber(build_number)

CheckBuildAppliedStatus.checkStatus(build_status, status)
