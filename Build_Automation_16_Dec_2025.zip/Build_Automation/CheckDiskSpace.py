import sys
import readConfigurationFile
import emailNotification

import winrm

def windows_disk_check(hostname, username, password):
    session = winrm.Session(hostname, auth=(username, password), transport='ntlm')
    #ps_script = """Get-PSDrive -PSProvider FileSystem | Select-Object Name, @{Name="FreeSpace(GB)";Expression={[math]::Round($_.Free/1GB,2)}}"""
    print('Checking space in', hostname)
    ps_script = """(Get-PSDrive -Name E).Free / 1GB"""
    result = session.run_ps(ps_script)

    free_space_gb = round(float(result.std_out.decode().strip()), 2)

    if free_space_gb > 10:
        print(f"The E: drive has more than 10 GB of free space ({free_space_gb} GB available).")
    else:
        print(f"The E: drive has less than 10 GB of free space ({free_space_gb} GB available).")
        emailNotification.send_mail('Disk Space Alert - ' + hostname)


def readKeyStorage(winPrivateKey):
    with open(winPrivateKey, 'r') as file:
        password = file.read()
    return password


hostname = sys.argv[1]
parser = readConfigurationFile.readConfigFile(hostname)
username = parser['REGION_DETAILS']['USERNAME']
winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
password = readKeyStorage(winPrivateKey)
windows_disk_check(hostname, username, password)
