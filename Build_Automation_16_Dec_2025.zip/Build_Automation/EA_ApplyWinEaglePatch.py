import os, sys, winrm, glob
from configparser import ConfigParser
from datetime import datetime

from dotenv import load_dotenv

load_dotenv()

import fileHandling
import emailNotification


def readKeyStorage(winPrivateKey):
    with open(winPrivateKey, 'r') as file:
        password = file.read()
    return password

def Apply_EaglePatch(conn, patch_loc, stage_loc, hostname, StaticConfig, INSTDIR_EMShell):
    print('Apply Eagle Patch at :', patch_loc)
    if os.path.exists(patch_loc):
        path_ini = os.path.join(patch_loc + '\\eaglepatch.ini')
        path_exe = os.path.join(stage_loc + '\\eaglepatch.exe')
        print("eaglepatch.ini file :", path_ini)
        print("eaglepatch.exe file :", path_exe)
        start_time = datetime.now().time().strftime('%H:%M:%S')
        fileHandling.replace_string(path_ini, "SilentMode=0", "SilentMode=1")
        fileHandling.replace_string(path_ini, "Delta=1", "Delta=0")
        fileHandling.replace_string(path_ini, "SkipBackup=0", "SkipBackup=1")
        fileHandling.replace_string(path_ini, "ServiceShutdown=1", "ServiceShutdown=0")
        fileHandling.replace_string(path_ini, "~/eagle/eaglemgr/config/eaglepatch.ini", StaticConfig)
        fileHandling.replace_string(path_ini, "~/eagle/", INSTDIR_EMShell)
        print('Started applying Eagle Patch', hostname, start_time)
        result = conn.run_ps(path_exe)
        output = result.std_out.decode() if isinstance(result.std_out, bytes) else result.std_out
        for line in output.splitlines():
            print(line)
        end_time = datetime.now().time().strftime('%H:%M:%S')
        if result.status_code == 0:
            print('Completed applying Eagle Patch', hostname, end_time)
        else:
            print("failed to run eaglepatch.exe File ")
        total_time = (datetime.strptime(end_time, '%H:%M:%S') - datetime.strptime(start_time, '%H:%M:%S'))
        print('Total time taken to apply Eagle Patch in ', hostname, "is",  str(total_time))
        fileHandling.check_patching_status(patch_loc, hostname)
    else:
        print(hostname, ' : EAGLE_PATCH Folder Missing.')

def main(argv):
    type = sys.argv[1]
    hostname = sys.argv[2]
    for host in hostname.split(','):
        build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
        print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        build_version = os.environ.get('build_version')

    if type == 'APP':
        username = parser['APP_TIER_DETAIL']['username']
        winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
        password = readKeyStorage(winPrivateKey)
        try:
            conn = winrm.Session(host,auth=(username,password),transport='ntlm')
            print('Connection Established to', host)
        except Exception as error:
            print('Failed to Establish Connection to', host)

        StaticConfig = parser['APP_TIER_DETAIL']['StaticConfig']
        INSTDIR_EMShell = parser['APP_TIER_DETAIL']['INSTDIR_EMShell']
        stage_loc = os.path.join(parser['APP_TIER_DETAIL']['stagePath'],build_version, 'EAGLE_PATCH')
        patch_loc = os.path.join('\\\\', host, 'Eagle_Install\\Stage', build_version, 'EAGLE_PATCH')

        Apply_EaglePatch(conn, patch_loc, stage_loc, hostname, StaticConfig, INSTDIR_EMShell)

    if type == 'RPT':
        username = parser['REPORT_TIER_DETAIL']['username']
        winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
        password = readKeyStorage(winPrivateKey)
        try:
            conn = winrm.Session(host,auth=(username,password),transport='ntlm')
            print('Connection Established to', host)
        except Exception as error:
            print('Failed to Establish Connection to', host)

        StaticConfig = parser['REPORT_TIER_DETAIL']['StaticConfig']
        INSTDIR_EMShell = parser['REPORT_TIER_DETAIL']['INSTDIR_EMShell']
        stage_loc = os.path.join(parser['REPORT_TIER_DETAIL']['stagePath'],build_version, 'EAGLE_PATCH')
        patch_loc = os.path.join('\\\\', host, 'Eagle_Install\\Stage', build_version, 'EAGLE_PATCH')

        Apply_EaglePatch(conn, patch_loc, stage_loc, hostname, StaticConfig, INSTDIR_EMShell)

    if type == 'WEB':
        username = parser['WEB_TIER_DETAIL']['username']
        winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
        password = readKeyStorage(winPrivateKey)
        try:
            conn = winrm.Session(host,auth=(username,password),transport='ntlm')
            print('Connection established with', host)
        except Exception as error:
            print('Failed to Establish Connection to', host)
        StaticConfig = parser['WEB_TIER_DETAIL']['StaticConfig']
        INSTDIR_EMShell = parser['WEB_TIER_DETAIL']['INSTDIR_EMShell']
        stage_loc = os.path.join(parser['WEB_TIER_DETAIL']['stagePath'],build_version, 'EAGLE_PATCH')
        patch_loc = os.path.join('\\\\', host, 'Eagle_Install\\Stage', build_version, 'EAGLE_PATCH')

        Apply_EaglePatch(conn, patch_loc, stage_loc, hostname, StaticConfig, INSTDIR_EMShell)


if __name__ == "__main__":
    main(sys.argv)
