import paramiko, sys, os, platform, time, subprocess
from configparser import ConfigParser
from datetime import datetime
import tarfile
from dotenv import load_dotenv

load_dotenv()

def connectin_execution(host, port, username, private_key_path, command):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    private_key=paramiko.RSAKey.from_private_key_file(private_key_path)
    ssh.connect(hostname=host,port=port,username=username, pkey=private_key)
    stdin, stdout, stderr = ssh.exec_command(command)
    for line in stdout:
        print(line.strip(), flush=True)
    print(stdout.read().decode(), flush=True)
    return ssh
	
def main(argv):
    now = datetime.now()
    try:
        host = sys.argv[1]
        #hostnames=sys.argv[2]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)
    hostname = host.split('.')[0]
    build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
    print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    services_path = str(parser['BUILD_DIR']['servicesPath'])
    port = parser['REGION_DETAILS']['port']
    username = parser['REGION_DETAILS']['username']
    private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], hostname)
    exec_stop_command = 'cd '+ services_path + ' && ' + './stop ALL'
    print(exec_stop_command)
    #connectin_execution(host, port, username, private_key_path, exec_stop_command)
    
if __name__ == "__main__":
    main(sys.argv)