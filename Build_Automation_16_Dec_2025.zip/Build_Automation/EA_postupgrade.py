import sys, os
import winrm
from configparser import ConfigParser


def post_upgrade(file, remote_host, username, password):
    try:
        connection = winrm.Session(remote_host,auth=(username,password),transport='ntlm')
        print('connection established to the ', remote_host)

        result = connection.run_cmd(file)
        output = result.std_out.decode()
        print(output)
        if result.status_code == 0:
            print(f'The Post Upgrade step  is Executed in {remote_host}')
        else:
            print(f"The Post Upgrade step  is Failed to Executed in {remote_host}")
    except Exception as e:
        print(str(e))

def readKeyStorage(winPrivateKey):
    with open(winPrivateKey, 'r') as file:
        password = file.read()
    return password


def main(argv):
    try:
        hostname = sys.argv[1]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)
    for host in hostname.split(','):
        build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
        if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
            print(build_ini_file, 'file present.')
        else:
            print(build_ini_file, 'file missing.')
            sys.exit(2)
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        section_name = 'POST_UPGRADE'
        if section_name in parser.sections():
            for option in parser.options(section_name):
                postupgarde = parser.get(section_name, option)
        utils_path=parser['REPORT_TIER_DETAIL']['utilsPath']
        username = parser['REPORT_TIER_DETAIL']['USERNAME']
        password = parser['REPORT_TIER_DETAIL']['PASSWORD']
        winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
        password = readKeyStorage(winPrivateKey)

        postupgarde_path = os.path.join(utils_path,postupgarde)
        print(postupgarde_path)
        post_upgrade(postupgarde_path, host, username, password)
if __name__ == "__main__":
    main(sys.argv)
    