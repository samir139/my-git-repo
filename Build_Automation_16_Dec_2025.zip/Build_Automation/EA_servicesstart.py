import sys, os
import winrm
from configparser import ConfigParser


def start_remote_service(services, remote_host, username, password):
    try:
        connection = winrm.Session(remote_host, auth=(username, password), transport='ntlm')
        print('connection established to the ', remote_host)
        for service_name in services.split(','):
            result = connection.run_cmd(f"sc start {service_name}")
            output = result.std_out.decode()
            print(output)
            if result.status_code == 0:
                print(f'the {service_name} service are started in {remote_host}')
            else:
                print(f"{service_name} is already started in {remote_host}")
    except Exception as e:
        print(str(e))

def readKeyStorage(winPrivateKey):
    with open(winPrivateKey, 'r') as file:
        password = file.read()
    return password


def main(argv):
    try:
        hostname = sys.argv[1]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)
		
		
    for host in hostname.split(','):
        
        build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
        if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
            print(build_ini_file, 'file present.')
        else:
            print(build_ini_file, 'file missing.')
            sys.exit(2)
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        services = str(parser['WEB_TIER_DETAIL']['services'])

        username = parser['WEB_TIER_DETAIL']['USERNAME']
        #password = parser['WEB_TIER_DETAIL']['PASSWORD']
        winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
        password = readKeyStorage(winPrivateKey)

        start_remote_service(services, host, username, password)

    try:
        hostname = sys.argv[2]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)
    for host in hostname.split(','):
        
        build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
        if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
            print(build_ini_file, 'file present.')
        else:
            print(build_ini_file, 'file missing.')
            sys.exit(2)
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        services = str(parser['REPORT_TIER_DETAIL']['services'])

        username = parser['REPORT_TIER_DETAIL']['USERNAME']
        #password = parser['REPORT_TIER_DETAIL']['PASSWORD']
        winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
        password = readKeyStorage(winPrivateKey)

        start_remote_service(services, host, username, password)
if __name__ == "__main__":
    main(sys.argv)