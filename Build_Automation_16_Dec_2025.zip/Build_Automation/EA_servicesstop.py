import sys, os, glob
import winrm
from configparser import ConfigParser


def readKeyStorage(winPrivateKey):
    with open(winPrivateKey, 'r') as file:
        password = file.read()
    return password

def stop_remote_service(services, remote_host, username, password):
    try:
        connection = winrm.Session(remote_host, auth=(username, password), transport='ntlm')
        print('connection established to the ', remote_host)
        for service_name in services.split(','):
            result = connection.run_cmd(f"sc stop {service_name}")
            output = result.std_out.decode()
            print(output)
            if result.status_code == 0:
                print(f'the {service_name} service has been stopped in {remote_host}')
            else:
                print(f"{service_name} is already stopped in {remote_host}")
    except Exception as e:
        print(str(e))
def delete_log_files(hostname,username,password):
    pattern = r"\\" + hostname + "\logs\**\*.log"
    file_count = 0
    for item in glob.iglob(pattern, recursive=True):
        try:
            #print("Deleting:", item)
            file_count += len(item)
            os.remove(item)
        except:
            print("Error while deleting file", item)
    print(file_count, 'No of log files deleted in ', hostname)

def delete_bkp_files(hostname,username,password):
    pattern = r"\\" + hostname + r"\Eagle Investment Systems\bkp\patch\**\*.res"
    #print('Deleting files from : ', hostname)
    res_file_count = 0
    for item in glob.iglob(pattern, recursive=True):
        try:
            #print("Deleting: ", item)
            res_file_count += len(item)
            os.remove(item)
        except:
            print("Error while deleting file", item)
    print(res_file_count, 'No. of res files deleted in ', hostname)

    pattern = r"\\" + hostname + r"\Eagle Investment Systems\bkp\patch\**\*.rar"
    #print('Deleting files from : ', hostname)
    rar_file_count = 0
    for item in glob.iglob(pattern, recursive=True):
        try:
            #print("Deleting:", item)
            rar_file_count += len(item)
            os.remove(item)
        except:
            print("Error while deleting file", item)
    print(rar_file_count, 'No. of rar files deleted in ', hostname)

def main(argv):
    try:
        hostname = sys.argv[1]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)
    for host in hostname.split(','):
        build_version = os.environ.get('build_version')
        build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
        if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
            print(build_ini_file, 'file present.')
        else:
            print(build_ini_file, 'file missing.')
            sys.exit(2)
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        services = str(parser['WEB_TIER_DETAIL']['services'])

        username = parser['WEB_TIER_DETAIL']['USERNAME']
        #password = parser['WEB_TIER_DETAIL']['PASSWORD']
        winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
        password = readKeyStorage(winPrivateKey)

        stop_remote_service(services, host, username, password)
        delete_log_files(host,username,password)
        delete_bkp_files(host,username,password)

    try:
        hostname = sys.argv[2]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)
    for host in hostname.split(','):
        build_version = os.environ.get('build_version')
        build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
        if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
            print(build_ini_file, 'file present.')
        else:
            print(build_ini_file, 'file missing.')
            sys.exit(2)
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        services = str(parser['REPORT_TIER_DETAIL']['services'])

        username = parser['REPORT_TIER_DETAIL']['USERNAME']
        #password = parser['REPORT_TIER_DETAIL']['PASSWORD']
        winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
        password = readKeyStorage(winPrivateKey)

        stop_remote_service(services, host, username, password)
        delete_log_files(host,username,password)
        delete_bkp_files(host,username,password)
if __name__ == "__main__":
    main(sys.argv)