from jira import JIRA
from tabulate import tabulate
import re
import sys
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet

from dotenv import load_dotenv

load_dotenv()

def get_build_lines_for_multiple(jira_url, username, token, issue_keys, year_val):
    jira = JIRA(server=jira_url, basic_auth=(username, token))

    grouped_rows = {}

    for issue_key in issue_keys:
        issue = jira.issue(issue_key)
        summary = issue.fields.summary
        comments = issue.fields.comment.comments

        rows = []

        for comment in comments:
            for line in comment.body.splitlines():

                if "Build:" in line:
                    # -------------------------
                    # YEAR FILTER: Allow only 2025
                    # -------------------------
                    # Expected Build line format:
                    # Build: 10-20-25 09:38 AM - commit: abc123
                    match = re.search(r"Build:\s*(\d{2}-\d{2}-\d{2})", line)
                    if not match:
                        continue

                    date_str = match.group(1)  # "10-20-25"

                    try:
                        month, day, yy = date_str.split("-")
                        full_year = 2000 + int(yy)

                        if full_year != 2025:
                            continue  # Skip builds not in year 2025

                    except Exception:
                        continue  # Skip malformed dates

                    # Passed year filter → add the row
                    rows.append([summary, line.strip()])

        print(f"Total Builds applied for {summary} : {len(rows)}")

        grouped_rows[summary] = rows

    # Print combined table to console
    print("\n=== Combined Build Table ===\n")
    all_rows_flat = [row for rows in grouped_rows.values() for row in rows]
    if all_rows_flat:
        print(tabulate(all_rows_flat, headers=["Summary", "Build Line"], tablefmt="grid"))
    else:
        print("No 'Build:' lines found across all issues.")

    return grouped_rows

def create_pdf_report(output_path, grouped_rows):
    styles = getSampleStyleSheet()
    story = []

    title = Paragraph("Matrics of Build Deployed into Regression Regions - " + sys.argv[1], styles['Title'])
    story.append(title)
    story.append(Spacer(1, 18))

    page_width, page_height = A4
    left_margin = 40
    right_margin = 40
    usable_width = page_width - left_margin - right_margin

    for summary, rows in grouped_rows.items():
        count = len(rows)

        count_text = Paragraph(
            f"Total Builds applied for <b>{summary}</b> : <b>{count}</b>",
            styles['Heading3']
        )
        story.append(count_text)
        story.append(Spacer(1, 6))

        table_data = [["Summary", "Build Line"]] + rows

        table = Table(
            table_data,
            colWidths=[
                usable_width * 0.25,
                usable_width * 0.85
            ]
        )

        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))

        story.append(table)
        story.append(Spacer(1, 24))

    doc = SimpleDocTemplate(output_path, pagesize=A4,
                            leftMargin=left_margin,
                            rightMargin=right_margin)
    doc.build(story)
    return output_path

def send_email_with_attachment(sender, receiver, smtp_server, subject, body, attachment_path):
    msg = MIMEMultipart()
    msg["From"] = sender
    msg["To"] = ", ".join(receiver)
    msg["Subject"] = subject

    msg.attach(MIMEText(body, "plain"))

    with open(attachment_path, "rb") as f:
        attach = MIMEApplication(f.read(), _subtype="pdf")
        attach.add_header("Content-Disposition", "attachment", filename=attachment_path.split("/")[-1])
        msg.attach(attach)

    server = smtplib.SMTP(smtp_server)
    server.starttls()
    server.sendmail(sender, receiver, msg.as_string())
    server.quit()

    print("Email sent successfully.")


if __name__ == "__main__":
    jira_url = "https://eagleinvsys.atlassian.net"
    username = "farm@eagleinvsys.com"
    token = "ATATT3xFfGF0rbjF1nTYoJHgVj1IaLx5Zj5JPoGmsZYDK8Tm5WhJXz5FFoQnff25Au85iVNEOGBWEe55gtO4qb9xhxAejAEs7V7t-k11pKd6jxjFGHp50Ee1PgE4kEcHOo7uWdDD-c-WRe2ua4wf_Ltfk8SfY0Idd9CdQsq-J1_fvd5_pU5MmTg=50C02953"
    issue_keys = [
        "DBT-531", # 25R1.2
        "DBT-524", # 25R1.1
        "DBT-516", # 2017 R2.55
        "DBT-507", # 2017 R2.54
        "DBT-498", # 2017 R2.53
        "DBT-483", # 2017 R2.52
        "DBT-482", # 2017 R2.51
        "DBT-545", # 2017 R2.55 CST05
        "DBT-543", # 2017 R2.55 CST04
        "DBT-530", # 2017 R2.55 CST03
        "DBT-529", # 2017 R2.55 CST02
        "DBT-523", # 2017 R2.55 CST01
        "DBT-544", # 2017 R2.54 CST06
        "DBT-533", # 2017 R2.54 CST05
        "DBT-532", # 2017 R2.54 CST04
        "DBT-527", # 2017 R2.54 CST03
        "DBT-520", # 2017 R2.54 CST02
        "DBT-515", # 2017 R2.54 CST01
        "DBT-526", # 2017 R2.53 CST04
        "DBT-522", # 2017 R2.53 CST03
        "DBT-513", # 2017 R2.53 CST02
        "DBT-508", # 2017 R2.53 CST01
        "DBT-540", # 2017 R2.51 CST09
        "DBT-528", # 2017 R2.51 CST08
        "DBT-521", # 2017 R2.51 CST07
        "DBT-512", # 2017 R2.51 CST06
        "DBT-510", # 2017 R2.51 CST05
        "DBT-504", # 2017 R2.51 CST04
        "DBT-501", # 2017 R2.51 CST03
        "DBT-500", # 2017 R2.51 CST02
        "DBT-496" # 2017 R2.51 CST01
    ]
    grouped_rows = get_build_lines_for_multiple(jira_url, username, token, issue_keys, sys.argv[1])

    # Generate PDF
    pdf_path = "jira_build_report.pdf"
    create_pdf_report(pdf_path, grouped_rows)
    print(f"PDF generated: {pdf_path}")
    send_email_with_attachment(
        sender="regops_support@eagleinvsys.com",
        receiver=["samir.ransingh@bny.com","marimuthu.mannathan@bny.com"],
        smtp_server="smtpvip-p-use2.eagleaccess.com",
        subject="JIRA Matrix Build Report - " + sys.argv[1],
        body="Attached is the consolidated deployment commits into Regression Regions .\n \n Thanks, \n Regression Team.",
        attachment_path=pdf_path
    )