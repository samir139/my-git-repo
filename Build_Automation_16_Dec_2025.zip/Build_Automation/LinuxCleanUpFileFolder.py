import os, sys, paramiko
from pathlib import Path
from configparser import ConfigParser
import jiradetails

def read_config_details():
    try:
        config_filename = 'CleanUpFileFolder.ini'
        path = Path(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', config_filename))
        if path.is_file():
            print(f'The Configuration file {config_filename} is present')
            print(path)
            parser = ConfigParser()
            parser.read(path)
        else:
            print(f'The Configuration file {config_filename} missing please verify')
        return parser
    except OSError as error:
        print(f'The Configuration file {config_filename} missing please verify')
        sys.exit(2)

def getpwdFile(hostname, keyPath):
    pwdFile = keyPath + '\\' + hostname.split('.')[0]
    return pwdFile

def runLinuxService(host, port, username, password, private_key_path, command):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        private_key=paramiko.RSAKey.from_private_key_file(private_key_path)
        ssh.connect(hostname=host,port=port,username=username, pkey=private_key)
        stdin, stdout, stderr = ssh.exec_command(command)
        for line in stdout:
            print(line.strip(), flush=True)
        print(stdout.read().decode(), flush=True)
    except:
        ssh.connect(hostname=host, port=port, username=username, password=password)
        stdin, stdout, stderr = ssh.exec_command(command)
        for line in stdout:
            print(line.strip(), flush=True)
        print(stdout.read().decode(), flush=True)
    return ssh

def deleteLinuxFiles(hostname, port, username, password, private_key_path):
    try:
        deleteLogFiles = "find /apps/eagle/logs -type f \( -name '*.log' -or -name '*.LOG' \) -mtime +1 -exec rm -rf {} \;"
        print(deleteLogFiles)
        runLinuxService(hostname, port, username, password, private_key_path, deleteLogFiles)

        deleteResRarFiles = "find /apps/eagle/bkp/patch -type f \( -name '*.res' -or -name '*.rar' \) -mtime +1 -exec rm -rf {} \;"
        print(deleteResRarFiles)
        runLinuxService(hostname, port, username, password, private_key_path, deleteResRarFiles)

        deleteStageFiles = "find /apps/eagle/software/stage -type d -name 'Eagle_V*' -mtime +1 -exec rm -rf {} \;"
        print(deleteStageFiles)
        runLinuxService(hostname, port, username, password, private_key_path, deleteStageFiles)

        deleteNFSFiles = "find /apps/eagle/nfs/dailybuild -type d -name 'Eagle_V*' -exec rm -rf {} \;"
        print(deleteNFSFiles)
        runLinuxService(hostname, port, username, password, private_key_path, deleteNFSFiles)
    except Exception as e:
        print(f"An error occurred: {e}")

hostname = sys.argv[1]
env = sys.argv[2]
buildDetails, buildVersion, buildNumber, buildStatus = jiradetails.get_jira_details()
configPar = read_config_details()

if env == 'EA':
    pwdFile = getpwdFile(hostname, configPar['CommonDetails']['EA_privatekey'])
    deleteLinuxFiles(hostname, configPar['CommonDetails']['linux_default_port'],
                     configPar['CommonDetails']['linux_user'], '', pwdFile)

if env == 'EIS':
    pwdFile = r'E:\Rundeck\var\storage\content\keys\EIS-LinuxAccount\eagle'
    with open(pwdFile) as f: key = f.read()
    deleteLinuxFiles(hostname, configPar['CommonDetails']['linux_default_port'],
                         configPar['CommonDetails']['linux_user'], key, '')