import paramiko, os
from configparser import ConfigParser


def read_id_rsa_key(host):
    build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    return parser

def delete_files_folders(command):
    server_file = "servers.txt"
    with open(server_file, "r") as f:
        servers = [line.strip() for line in f if line.strip()]

    username = "eagle"
    parser = read_id_rsa_key(servers)
    id_rsa_key = os.path.join(parser['REGION_DETAILS']['privatekey'], username.split('.')[0])

    for server in servers:
        print(f"\nConnecting to {server} ...")
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            key = paramiko.RSAKey.from_private_key_file(id_rsa_key)
            ssh.connect(server, username=username, pkey=key, timeout=10)
            stdin, stdout, stderr = ssh.exec_command(command)
            output = stdout.read().decode()
            error = stderr.read().decode()

            print(f"Output from {server}:\n{output}")
            if error:
                print(f"Errors from {server}:\n{error}")

            ssh.close()
        except Exception as e:
            print(f"Failed to connect to {server}: {e}")

# List of commands to be executed
delete_stage_files = "cd /apps/eagle/software/stage && rm -rf Eagle_*"
delete_log_files = "find /apps/eagle/logs -type f \( -name '*.log' -or -name '*.LOG' \) -exec rm -rf {} \;"
delete_bkp_files = "find /apps/eagle/bkp/patch -type f \( -name '*.res' -or -name '*.rar' \) -exec rm -rf {} \;"
delete_old_log_folders = "find /apps/eagle/logs/bkp -maxdepth 2 -type d -regextype posix-extended -regex '.*/[0-9]{4}_[0-9]{2}_[0-9]{2}' -exec rm -rf {} \;"
delete_nfs_daily_build_folder = "cd /apps/eagle/nfs/dailybuild && rm -rf Eagle_*"

# Execute the commands
delete_files_folders(delete_stage_files)
delete_files_folders(delete_log_files)
delete_files_folders(delete_bkp_files)
delete_files_folders(delete_old_log_folders)
delete_files_folders(delete_nfs_daily_build_folder)
