import sys
from configparser import ConfigParser

from dotenv import load_dotenv
from jira import JIRA
import re, os, csv
import pandas as pd
load_dotenv()

file_name = os.path.join(os.path.abspath(os.path.dirname(__file__)), r'..\reports', 'RegOpsBuildStatus.csv')


class getJiraDetails():
    @staticmethod
    def read_ini_file():
        ini_file = 'jiradetails.ini'
        print('The ini file to read is',
              os.path.join(os.path.abspath(os.path.dirname(__file__)), r'..\resources', ini_file))
        par_val = ConfigParser()
        par_val.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), r'..\resources', ini_file))
        return par_val

    @staticmethod
    def get_jira_details(jira_server, jira_uid, jira_token, build_id):
        jiraOptions = {'server': jira_server}
        jira = JIRA(options=jiraOptions, basic_auth=(jira_uid, jira_token))
        build_version = str('Eagle_V' + jira.issue(build_id).fields.summary.replace(" ", ""))
        build_status = str(jira.issue(build_id).fields.status)
        a = int(0)
        for i in jira.comments(build_id):
            if int(i.id) > a:
                a = int(i.id)

        build_details = jira.comment(build_id, a).body
        count = len(jira.comments(build_id))
        for i in range(count, 0, -1):
            build_details = jira.comment(build_id, jira.comments(build_id)[i - 1]).body
            if re.findall("Build:", build_details, re.MULTILINE):
                for line in build_details.splitlines():
                    if "Build" in line:
                        build_number = line
                        build_date = build_number.lstrip('Build: ')[:8]
                        break
                return build_version, build_date, build_number
                break

    @staticmethod
    def check_csv_header():
        headers = ['Build Version', 'Region', 'Environment', 'Build Date', 'Build Number', 'Build Status', 'Issues']
        print(headers)
        # Check if the file exists and is empty or does not contain headers
        if not os.path.isfile(file_name) or os.path.getsize(file_name) == 0:
            # Write headers to the CSV file
            with open(file_name, mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(headers)
            print(f"Headers have been added to '{file_name}'")
        else:
            # Headers are already present or the file is not empty
            print(f"Headers are already present in '{file_name}' or the file is not empty")

    @staticmethod
    def writetocsv(file_path, new_rows):
        # Read the existing CSV file into a DataFrame
        existing_data = pd.read_csv(file_path)

        # Convert the new data into a DataFrame
        new_data = pd.DataFrame(new_rows)

        # Append the new data to the existing DataFrame
        updated_data = existing_data._append(new_data, ignore_index=True)

        # Write the updated DataFrame back to the CSV file
        updated_data.to_csv(file_path, index=False)

        print(f"Record has been inserted into '{file_name}'")

    @staticmethod
    def search_csv(file_path, commit_id, env):
        # Read the CSV file into a DataFrame
        data = pd.read_csv(file_path)

        # Filter rows where 'Name' column matches the search_name
        #exists = any(data['Build Number'] == search_name)
        exists = data([(data['Build Number'] == commit_id) | (data['Environment'] == env)])

        # Output True if the string exists, otherwise output False
        return exists


region = sys.argv[1]
env = sys.argv[2]
status = sys.argv[3]

# Jira server and credentials
parser = getJiraDetails.read_ini_file()
jira_server = parser['GET_JIRA']['jira_server']
jira_uid = parser['GET_JIRA']['jira_uid']
jira_token = parser['GET_JIRA']['jira_token']
build_id = os.environ.get('build_id')

# Get jira details from JIRA ticket
build_version, build_date, build_number = getJiraDetails.get_jira_details(jira_server, jira_uid, jira_token, build_id)
getJiraDetails.check_csv_header()

new_record = [{'Build Version':	build_version, 'Region': region, 'Environment':	env, 'Build Date': build_date, 'Build Number': build_number,'Build Status': status, 'Issues': ''}]
getJiraDetails.writetocsv(file_name, new_record)
#print(new_record)

## Validate if the build/commit ID is already present or not
#val = getJiraDetails.search_csv(file_name, build_number, env)
## Insert into csv file
#if val == False:
#    new_record = [{'Build Version':	build_version, 'Region': region, 'Environment':	env, 'Build Date': build_date, 'Build Number': build_number,'Build Status': status, 'Issues': ''}]
#    #getJiraDetails.writetocsv(file_name, new_record)
#    print(new_record)
#else:
#    print(f'{build_number} already added to the csv file')
