import os
from configparser import ConfigParser

class get_jira():
    @staticmethod
    def read_ini_file():
        ini_file = 'jiradetails.ini'
        print('The ini file to read is',
              os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', ini_file))
        par_val = ConfigParser()
        par_val.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', ini_file))
        return par_val