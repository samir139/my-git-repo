/* Created by Regression Team for Post DB changes after DB Refresh */

SET SERVEROUTPUT ON SIZE UNLIMITED FORMAT WRAPPED;
SET ECHO OFF;
SET VERIFY OFF;
SET LINESIZE 255;

--spool Eagle_Post_DB_Activity.out

DEFINE l_old_app_hostname = &1
DEFINE l_new_app_hostname = &2
DEFINE l_old_rpt_hostname = &3
DEFINE l_new_rpt_hostname = &4
DEFINE l_old_web_hostname = &5
DEFINE l_new_web_hostname = &6
DEFINE l_old_db_name      = &7
DEFINE l_new_db_name      = &8

BEGIN
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line (' OLD APP HOSTNAME : &l_old_app_hostname');
    DBMS_OUTPUT.put_line (' NEW APP HOSTNAME : &l_old_app_hostname');
    DBMS_OUTPUT.put_line (' OLD RPT HOSTNAME : &l_old_rpt_hostname');
    DBMS_OUTPUT.put_line (' NEW RPT HOSTNAME : &l_new_rpt_hostname');
    DBMS_OUTPUT.put_line (' OLD WEB HOSTNAME : &l_old_web_hostname');
    DBMS_OUTPUT.put_line (' NEW WEB HOSTNAME : &l_new_web_hostname');
    DBMS_OUTPUT.put_line (' OLD DB NAME      : &l_old_db_name');
    DBMS_OUTPUT.put_line (' NEW DB NAME      : &l_new_db_name');
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
END;
/

--spool eagle_post_db_activity.out

BEGIN
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line (' EXECUTING EAGLE_POST_DB_ACTIVITY.SQL SCRIPT ');
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line (' VALIDATE PACE_MASTERDBO.PACE_SYSTEM TABLE ');
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
END;
/

DECLARE
    l_count   VARCHAR2 (128);
BEGIN
    l_count := 0;

    SELECT COUNT (*)
      INTO l_count
      FROM pace_masterdbo.pace_system
     WHERE sys_item IN (2, 39, 86) AND sys_value LIKE '%&l_old_app_hostname%';

    DBMS_OUTPUT.put_line (' NUMBER OF RECORDS PRESENT IS : ' || l_count);

    IF l_count > 0
    THEN
        DBMS_OUTPUT.put_line (' UPDATING PACE_MASTERDBO.PACE_SYSTEM TABLE. ');

        UPDATE pace_masterdbo.pace_system
           SET SYS_VALUE =
                   REPLACE (SYS_VALUE,
                            '%&l_old_app_hostname%',
                            '%&l_new_app_hostname%')
         WHERE SYS_VALUE LIKE '%&l_old_app_hostname%';
    ELSE
        DBMS_OUTPUT.put_line (
            ' NO RECORDS FOUND TO UPDATE PACE_MASTERDBO.PACE_SYSTEM TABLE. ');
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line (' VALIDATE RULESDBO.OPTIONS TABLE');
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
END;
/

DECLARE
    l_count   VARCHAR2 (128);
BEGIN
    l_count := 0;

    SELECT COUNT (*)
      INTO l_count
      FROM rulesdbo.options a
     WHERE option_default LIKE '%&l_old_app_hostname%';

    DBMS_OUTPUT.put_line (' NUMBER OF RECORDS PRESENT IS : ' || l_count);

    IF l_count > 0
    THEN
        DBMS_OUTPUT.put_line (' UPDATING RULESDBO.OPTIONS TABLE.');

        UPDATE pace_masterdbo.pace_system
           SET option_default =
                   REPLACE (option_default,
                            '%&l_old_app_hostname%',
                            '%&l_new_app_hostname%')
         WHERE option_default LIKE '%&l_old_app_hostname%';
    ELSE
        DBMS_OUTPUT.put_line (
            ' NO RECORDS FOUND TO UPDATE RULESDBO.OPTIONS TABLE.');
    END IF;

    l_count := 0;

    SELECT COUNT (*)
      INTO l_count
      FROM rulesdbo.options a
     WHERE option_default LIKE '%&l_old_rpt_hostname%';

    DBMS_OUTPUT.put_line (' NUMBER OF RECORDS PRESENT IS : ' || l_count);

    IF l_count > 0
    THEN
        DBMS_OUTPUT.put_line (' UPDATING RULESDBO.OPTIONS TABLE.');

        UPDATE pace_masterdbo.pace_system
           SET option_default =
                   REPLACE (option_default,
                            '%&l_old_rpt_hostname%',
                            '%&l_new_rpt_hostname%')
         WHERE option_default LIKE '%&l_old_rpt_hostname%';
    ELSE
        DBMS_OUTPUT.put_line (
            ' NO RECORDS FOUND TO UPDATE RULESDBO.OPTIONS TABLE.');
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line (
        ' VALIDATE PACE_MASTERDBO.CUSTOM_ARCHIVE_RULES TABLE');
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
END;
/

DECLARE
    l_count   VARCHAR2 (128);
BEGIN
    l_count := 0;

    SELECT COUNT (*)
      INTO l_count
      FROM pace_masterdbo.custom_archive_rules
     WHERE root_dir LIKE '%&l_old_app_hostname%';

    DBMS_OUTPUT.put_line (' NUMBER OF RECORDS PRESENT IS : ' || l_count);

    IF l_count > 0
    THEN
        DBMS_OUTPUT.put_line (
            ' UPDATING PACE_MASTERDBO.CUSTOM_ARCHIVE_RULES TABLE.');

        UPDATE pace_masterdbo.custom_archive_rules
           SET root_dir =
                   REPLACE (root_dir,
                            '%&l_old_app_hostname%',
                            '%&l_new_app_hostname%')
         WHERE root_dir LIKE '%&l_old_app_hostname%';
    ELSE
        DBMS_OUTPUT.put_line (
            ' NO RECORDS FOUND TO UPDATE PACE_MASTERDBO.CUSTOM_ARCHIVE_RULES TABLE.');
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line (
        ' VALIDATE PACE_MASTERDBO.EXPORTER_OPTION_VALUES TABLE');
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
END;
/

DECLARE
    l_count   VARCHAR2 (128);
BEGIN
    l_count := 0;

    SELECT COUNT (*)
      INTO l_count
      FROM pace_masterdbo.exporter_option_values a
     WHERE a.option_str_value LIKE '%&l_old_app_hostname%';

    DBMS_OUTPUT.put_line ('NUMBER OF RECORDS PRESENT IS : ' || l_count);

    IF l_count > 0
    THEN
        DBMS_OUTPUT.put_line (
            ' UPDATING PACE_MASTERDBO.EXPORTER_OPTION_VALUES TABLE.');

        UPDATE pace_masterdbo.exporter_option_values
           SET option_str_value =
                   REPLACE (option_str_value,
                            '%&l_old_app_hostname%',
                            '%&l_new_app_hostname%')
         WHERE option_str_value LIKE '%&l_old_app_hostname%';
    ELSE
        DBMS_OUTPUT.put_line (
            ' NO RECORDS FOUND TO UPDATE PACE_MASTERDBO.EXPORTER_OPTION_VALUES TABLE.');
    END IF;

    l_count := 0;

    SELECT COUNT (*)
      INTO l_count
      FROM pace_masterdbo.exporter_option_values a
     WHERE a.option_str_value LIKE '%&l_old_rpt_hostname%';

    DBMS_OUTPUT.put_line (' NUMBER OF RECORDS PRESENT IS : ' || l_count);

    IF l_count > 0
    THEN
        DBMS_OUTPUT.put_line (
            ' UPDATING PACE_MASTERDBO.EXPORTER_OPTION_VALUES TABLE.');

        UPDATE pace_masterdbo.exporter_option_values
           SET option_str_value =
                   REPLACE (option_str_value,
                            '%&l_old_rpt_hostname%',
                            '%&l_new_rpt_hostname%')
         WHERE option_str_value LIKE '%&l_old_rpt_hostname%';
    ELSE
        DBMS_OUTPUT.put_line (
            ' NO RECORDS FOUND TO UPDATE PACE_MASTERDBO.EXPORTER_OPTION_VALUES TABLE.');
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line (
        ' VALIDATE PACE_MASTERDBO.EXPORTER_OPTION_OVERRIDE TABLE');
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
END;
/

DECLARE
    l_count   VARCHAR2 (128);
BEGIN
    l_count := 0;

    SELECT COUNT (*)
      INTO l_count
      FROM pace_masterdbo.exporter_option_override a
     WHERE a.override_value LIKE '%&l_old_app_hostname%';

    DBMS_OUTPUT.put_line (' NUMBER OF RECORDS PRESENT IS : ' || l_count);

    IF l_count > 0
    THEN
        DBMS_OUTPUT.put_line (
            ' UPDATING PACE_MASTERDBO.EXPORTER_OPTION_OVERRIDE TABLE.');

        UPDATE pace_masterdbo.exporter_option_override
           SET override_value =
                   REPLACE (override_value,
                            '%&l_old_app_hostname%',
                            '%&l_new_app_hostname%')
         WHERE override_value LIKE '%&l_old_app_hostname%';
    ELSE
        DBMS_OUTPUT.put_line (
            ' NO RECORDS FOUND TO UPDATE PACE_MASTERDBO.EXPORTER_OPTION_OVERRIDE TABLE.');
    END IF;

    l_count := 0;

    SELECT COUNT (*)
      INTO l_count
      FROM pace_masterdbo.exporter_option_override a
     WHERE a.override_value LIKE '%&l_old_rpt_hostname%';

    DBMS_OUTPUT.put_line (' NUMBER OF RECORDS PRESENT IS : ' || l_count);

    IF l_count > 0
    THEN
        DBMS_OUTPUT.put_line (
            ' UPDATING PACE_MASTERDBO.EXPORTER_OPTION_OVERRIDE TABLE.');

        UPDATE pace_masterdbo.exporter_option_override
           SET override_value =
                   REPLACE (override_value,
                            '%&l_old_rpt_hostname%',
                            '%&l_new_rpt_hostname%')
         WHERE override_value LIKE '%&l_old_rpt_hostname%';
    ELSE
        DBMS_OUTPUT.put_line (
            ' NO RECORDS FOUND TO UPDATE PACE_MASTERDBO.EXPORTER_OPTION_OVERRIDE TABLE.');
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line (
        ' VALIDATE PACE_MASTERDBO.EXTERNAL_CONNECTION TABLE');
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
END;
/

DECLARE
    l_count   VARCHAR2 (128);
BEGIN
    l_count := 0;

    SELECT COUNT (*)
      INTO l_count
      FROM pace_masterdbo.external_connection
     WHERE connection_region = '%&l_old_db_name%';

    DBMS_OUTPUT.put_line (' NUMBER OF RECORDS PRESENT IS : ' || l_count);

    IF l_count > 0
    THEN
        DBMS_OUTPUT.put_line (
            ' UPDATING PACE_MASTERDBO.EXTERNAL_CONNECTION TABLE.');

        UPDATE pace_masterdbo.external_connection
           SET connection_region =
                   REPLACE (connection_region,
                            '&l_old_db_name',
                            '&l_new_db_name')
         WHERE connection_region LIKE '&l_old_db_name';
    ELSE
        DBMS_OUTPUT.put_line (
            ' NO RECORDS FOUND TO UPDATE PACE_MASTERDBO.EXTERNAL_CONNECTION TABLE.');
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line (
        ' REMOVE/DELETE RECORDS FROM EAGLEMGR.EAGLE_SERVICES TABLE');
    DBMS_OUTPUT.put_line (
        '---------------------------------------------------------------------------');
END;
/

DECLARE
    l_count   VARCHAR2 (128);
BEGIN
    l_count := 0;

    SELECT COUNT (*)
      INTO l_count
      FROM eaglemgr.eagle_services
     WHERE server_host = '%&l_old_app_hostname%';

    DBMS_OUTPUT.put_line (' NUMBER OF RECORDS PRESENT IS : ' || l_count);

    IF l_count > 0
    THEN
        DBMS_OUTPUT.put_line (
            ' DELETING RECORDS FROM EAGLEMGR.EAGLE_SERVICES AND EAGLEMGR.EAGLE_SERVICES_PROPERTIES TABLE.');

        DELETE FROM
            eaglemgr.eagle_service_properties
              WHERE service_instance IN
                        (SELECT instance
                           FROM eaglemgr.eagle_services
                          WHERE server_host = '%&l_old_app_hostname%');

        DELETE FROM eaglemgr.eagle_services
              WHERE server_host = '%&l_old_app_hostname%';
    ELSE
        DBMS_OUTPUT.put_line (
            ' NO RECORDS FOUND TO DELETE IN EAGLEMGR.EAGLE_SERVICES AND EAGLEMGR.EAGLE_SERVICES_PROPERTIES TABLE.');
    END IF;

    l_count := 0;

    SELECT COUNT (*)
      INTO l_count
      FROM eaglemgr.eagle_services
     WHERE server_host = '%&l_old_rpt_hostname%';

    DBMS_OUTPUT.put_line (' NUMBER OF RECORDS PRESENT IS : ' || l_count);

    IF l_count > 0
    THEN
        DBMS_OUTPUT.put_line (
            ' DELETING RECORDS FROM EAGLEMGR.EAGLE_SERVICES AND EAGLEMGR.EAGLE_SERVICES_PROPERTIES TABLE.');

        DELETE FROM
            eaglemgr.eagle_service_properties
              WHERE service_instance IN
                        (SELECT instance
                           FROM eaglemgr.eagle_services
                          WHERE server_host = '%&l_old_rpt_hostname%');

        DELETE FROM eaglemgr.eagle_services
              WHERE server_host = '%&l_old_rpt_hostname%';
    ELSE
        DBMS_OUTPUT.put_line (
            ' NO RECORDS FOUND TO DELETE IN EAGLEMGR.EAGLE_SERVICES AND EAGLEMGR.EAGLE_SERVICES_PROPERTIES TABLE.');
    END IF;

    l_count := 0;

    SELECT COUNT (*)
      INTO l_count
      FROM eaglemgr.eagle_services
     WHERE server_host = '%&l_old_web_hostname%';

    DBMS_OUTPUT.put_line (' NUMBER OF RECORDS PRESENT IS : ' || l_count);

    IF l_count > 0
    THEN
        DBMS_OUTPUT.put_line (
            ' DELETING RECORDS FROM EAGLEMGR.EAGLE_SERVICES AND EAGLEMGR.EAGLE_SERVICES_PROPERTIES TABLE.');

        DELETE FROM
            eaglemgr.eagle_service_properties
              WHERE service_instance IN
                        (SELECT instance
                           FROM eaglemgr.eagle_services
                          WHERE server_host = '%&l_old_web_hostname%');

        DELETE FROM eaglemgr.eagle_services
              WHERE server_host = '%&l_old_web_hostname%';
    ELSE
        DBMS_OUTPUT.put_line (
            ' NO RECORDS FOUND TO DELETE IN EAGLEMGR.EAGLE_SERVICES AND EAGLEMGR.EAGLE_SERVICES_PROPERTIES TABLE.');
    END IF;
END;
/

SET SERVEROUTPUT OFF;
SET ECHO ON;

EXIT