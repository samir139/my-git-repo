/* Engine re-group after DB Refresh for regression DB's */
/* To Execute : sqlplus schema_name/password@db_name @Post_StarEngine_ReGroup_Activity.sql */

SET SERVEROUTPUT ON SIZE UNLIMITED FORMAT WRAPPED;
SET ECHO OFF;
SET VERIFY OFF;
SET LINESIZE 255;

--spool Post_StarEngine_ReGroup_Activity.out

BEGIN
    DBMS_OUTPUT.put_line (
        '------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line (' Executing Post_StarEngine_ReGroup_Activity.sql... ');
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line ('Checking BT Engines to re-group... ');
END;
/

DECLARE
    l_count       VARCHAR2 (128);
    l_eng_count   VARCHAR2 (128);
    l_loopcount   VARCHAR2 (128);
BEGIN
    l_count := 0;
    l_eng_count := 0;
    l_loopcount := 0;

    SELECT COUNT (1)
      INTO l_count
      FROM EAGLEMGR.EAGLE_SERVICES es
     WHERE es.SERVICE_TYPE = 'ESTARENGINE' AND es.SERVICE_NAME LIKE 'BT-%';

    IF l_count = 0
    THEN
        DBMS_OUTPUT.put_line (' No BT engines found. ');
    ELSE
        SELECT COUNT (1)
          INTO l_eng_count
          FROM EAGLEMGR.EAGLE_SERVICES s, EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
         WHERE     s.INSTANCE = p.SERVICE_INSTANCE
               AND s.SERVICE_TYPE = 'ESTARENGINE'
			   AND p.PROPERTY_NAME = 'GROUP'
               AND (   p.PROPERTY_DEFAULT_VALUE LIKE 'BT%'
                    OR p.PROPERTY_VALUE LIKE 'BT%');

        DBMS_OUTPUT.put_line (
            ' Number of BT engines found before update is : ' || l_eng_count);

        IF l_eng_count = 0
        THEN
            FOR a
                IN (SELECT s.INSTANCE
                      FROM EAGLEMGR.EAGLE_SERVICES s
                     WHERE     s.SERVICE_TYPE = 'ESTARENGINE'
                           AND s.SERVICE_NAME LIKE 'BT-%')
            LOOP
                BEGIN
                   UPDATE EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
                      SET p.PROPERTY_DEFAULT_VALUE = 'BT',
                          p.PROPERTY_VALUE = 'BT'
                    WHERE p.SERVICE_INSTANCE = a.INSTANCE
                      AND p.PROPERTY_NAME = 'GROUP';
                END;
                l_loopcount := l_loopcount + 1;
            END LOOP;

            DBMS_OUTPUT.put_line (
                ' Number of BT engines updated is : ' || l_loopcount);
        ELSE
            DBMS_OUTPUT.put_line (' No BT engines found to be re-grouped... ');
        END IF;
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line ('Checking MT Engines to re-group... ');
END;
/

DECLARE
    l_count       VARCHAR2 (128);
    l_eng_count   VARCHAR2 (128);
    l_loopcount   VARCHAR2 (128);
BEGIN
    l_count := 0;
    l_eng_count := 0;
    l_loopcount := 0;

    SELECT COUNT (1)
      INTO l_count
      FROM EAGLEMGR.EAGLE_SERVICES es
     WHERE es.SERVICE_TYPE = 'ESTARENGINE' AND es.SERVICE_NAME LIKE 'MT-%';

    IF l_count = 0
    THEN
        DBMS_OUTPUT.put_line (' No MT engines found. ');
    ELSE
        SELECT COUNT (1)
          INTO l_eng_count
          FROM EAGLEMGR.EAGLE_SERVICES s, EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
         WHERE     s.INSTANCE = p.SERVICE_INSTANCE
               AND s.SERVICE_TYPE = 'ESTARENGINE'
			   AND p.PROPERTY_NAME = 'GROUP'
               AND (   p.PROPERTY_DEFAULT_VALUE LIKE 'MT%'
                    OR p.PROPERTY_VALUE LIKE 'MT%');

        DBMS_OUTPUT.put_line (
            ' Number of MT engines found before update is : ' || l_eng_count);

        IF l_eng_count = 0
        THEN
            FOR a
                IN (SELECT s.INSTANCE
                      FROM EAGLEMGR.EAGLE_SERVICES s
                     WHERE     s.SERVICE_TYPE = 'ESTARENGINE'
                           AND s.SERVICE_NAME LIKE 'MT-%')
            LOOP
                BEGIN
                   UPDATE EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
                      SET p.PROPERTY_DEFAULT_VALUE = 'MT',
                          p.PROPERTY_VALUE = 'MT'
                    WHERE p.SERVICE_INSTANCE = a.INSTANCE
                      AND p.PROPERTY_NAME = 'GROUP';
                END;
                l_loopcount := l_loopcount + 1;
            END LOOP;

            DBMS_OUTPUT.put_line (
                ' Number of MT engines updated is : ' || l_loopcount);
        ELSE
            DBMS_OUTPUT.put_line (' No MT engines found to be re-grouped... ');
        END IF;
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line ('Checking ST Engines to re-group... ');
END;
/

DECLARE
    l_count       VARCHAR2 (128);
    l_eng_count   VARCHAR2 (128);
    l_loopcount   VARCHAR2 (128);
BEGIN
    l_count := 0;
    l_eng_count := 0;
    l_loopcount := 0;

    SELECT COUNT (1)
      INTO l_count
      FROM EAGLEMGR.EAGLE_SERVICES es
     WHERE es.SERVICE_TYPE = 'ESTARENGINE' AND es.SERVICE_NAME LIKE 'ST-%';

    IF l_count = 0
    THEN
        DBMS_OUTPUT.put_line (' No ST engines found. ');
    ELSE
        SELECT COUNT (1)
          INTO l_eng_count
          FROM EAGLEMGR.EAGLE_SERVICES s, EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
         WHERE     s.INSTANCE = p.SERVICE_INSTANCE
               AND s.SERVICE_TYPE = 'ESTARENGINE'
			   AND p.PROPERTY_NAME = 'GROUP'
               AND (   p.PROPERTY_DEFAULT_VALUE LIKE 'ST%'
                    OR p.PROPERTY_VALUE LIKE 'ST%');

        DBMS_OUTPUT.put_line (
            ' Number of ST engines found before update is : ' || l_eng_count);

        IF l_eng_count = 0
        THEN
            FOR a
                IN (SELECT s.INSTANCE
                      FROM EAGLEMGR.EAGLE_SERVICES s
                     WHERE     s.SERVICE_TYPE = 'ESTARENGINE'
                           AND s.SERVICE_NAME LIKE 'ST-%')
            LOOP
                BEGIN
                   UPDATE EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
                      SET p.PROPERTY_DEFAULT_VALUE = 'ST',
                          p.PROPERTY_VALUE = 'ST'
                    WHERE p.SERVICE_INSTANCE = a.INSTANCE
                      AND p.PROPERTY_NAME = 'GROUP';
                END;
                l_loopcount := l_loopcount + 1;
            END LOOP;

            DBMS_OUTPUT.put_line (
                ' Number of ST engines updated is : ' || l_loopcount);
        ELSE
            DBMS_OUTPUT.put_line (' No ST engines found to be re-grouped... ');
        END IF;
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line ('Checking AD-MT Engines to re-group... ');
END;
/

DECLARE
    l_count       VARCHAR2 (128);
    l_eng_count   VARCHAR2 (128);
    l_loopcount   VARCHAR2 (128);
	l_service_name VARCHAR2 (128);
	l_server_host VARCHAR2 (128);
	l_server_port VARCHAR2 (128);
	l_property_value VARCHAR2 (128);
	l_property_default_value VARCHAR2 (128);
BEGIN
    l_count := 0;
    l_eng_count := 0;
    l_loopcount := 0;

    SELECT COUNT (1)
      INTO l_count
      FROM EAGLEMGR.EAGLE_SERVICES es
     WHERE es.SERVICE_TYPE = 'ESTARENGINE' AND es.SERVICE_NAME LIKE 'AD-MT-%';

    IF l_count = 0
    THEN
        DBMS_OUTPUT.put_line (' No AD-MT engines found. ');
    ELSE
        SELECT COUNT (1)
          INTO l_eng_count
          FROM EAGLEMGR.EAGLE_SERVICES s, EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
         WHERE     s.INSTANCE = p.SERVICE_INSTANCE
               AND s.SERVICE_TYPE = 'ESTARENGINE'
			   AND p.PROPERTY_NAME = 'GROUP'
               AND (   p.PROPERTY_DEFAULT_VALUE LIKE 'AD-MT%'
                    OR p.PROPERTY_VALUE LIKE 'AD-MT%');

        DBMS_OUTPUT.put_line (
            ' Number of AD-MT engines found before update is : ' || l_eng_count);

        IF l_eng_count = 0
        THEN
            FOR a
                IN (SELECT s.INSTANCE
                      FROM EAGLEMGR.EAGLE_SERVICES s
                     WHERE     s.SERVICE_TYPE = 'ESTARENGINE'
                           AND s.SERVICE_NAME LIKE 'AD-MT-%')
            LOOP
                BEGIN
                    UPDATE EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
                       SET p.PROPERTY_DEFAULT_VALUE = 'AD-MT',
                           p.PROPERTY_VALUE = 'AD-MT'
                     WHERE p.SERVICE_INSTANCE = a.INSTANCE
                       AND p.PROPERTY_NAME = 'GROUP';
                END;
                l_loopcount := l_loopcount + 1;
            END LOOP;

            DBMS_OUTPUT.put_line (
                ' Number of AD-MT engines updated is : ' || l_loopcount);
        ELSE
            DBMS_OUTPUT.put_line (' No AD-MT engines found to be re-grouped... ');
        END IF;			
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line ('Checking AD-ST Engines to re-group... ');
END;
/

DECLARE
    l_count       VARCHAR2 (128);
    l_eng_count   VARCHAR2 (128);
    l_loopcount   VARCHAR2 (128);
BEGIN
    l_count := 0;
    l_eng_count := 0;
    l_loopcount := 0;

    SELECT COUNT (1)
      INTO l_count
      FROM EAGLEMGR.EAGLE_SERVICES es
     WHERE es.SERVICE_TYPE = 'ESTARENGINE' AND es.SERVICE_NAME LIKE 'AD-ST-%';

    IF l_count = 0
    THEN
        DBMS_OUTPUT.put_line (' No AD-ST engines found. ');
    ELSE
        SELECT COUNT (1)
          INTO l_eng_count
          FROM EAGLEMGR.EAGLE_SERVICES s, EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
         WHERE     s.INSTANCE = p.SERVICE_INSTANCE
               AND s.SERVICE_TYPE = 'ESTARENGINE'
			   AND p.PROPERTY_NAME = 'GROUP'
               AND (   p.PROPERTY_DEFAULT_VALUE LIKE 'AD-ST%'
                    OR p.PROPERTY_VALUE LIKE 'AD-ST%');

        DBMS_OUTPUT.put_line (
            ' Number of AD-ST engines found before update is : ' || l_eng_count);

        IF l_eng_count = 0
        THEN
            FOR a
                IN (SELECT s.INSTANCE
                      FROM EAGLEMGR.EAGLE_SERVICES s
                     WHERE     s.SERVICE_TYPE = 'ESTARENGINE'
                           AND s.SERVICE_NAME LIKE 'AD-ST-%')
            LOOP
                BEGIN
                   UPDATE EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
                      SET p.PROPERTY_DEFAULT_VALUE = 'AD-ST',
                          p.PROPERTY_VALUE = 'AD-ST'
                    WHERE p.SERVICE_INSTANCE = a.INSTANCE
                      AND p.PROPERTY_NAME = 'GROUP';
                END;
                l_loopcount := l_loopcount + 1;
            END LOOP;

            DBMS_OUTPUT.put_line (
                ' Number of AD-ST engines updated is : ' || l_loopcount);
        ELSE
            DBMS_OUTPUT.put_line (' No AD-ST engines found to be re-grouped... ');
        END IF;
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line ('Checking OWS Engines to re-group... ');
END;
/

DECLARE
    l_count       VARCHAR2 (128);
    l_eng_count   VARCHAR2 (128);
    l_loopcount   VARCHAR2 (128);
BEGIN
    l_count := 0;
    l_eng_count := 0;
    l_loopcount := 0;

    SELECT COUNT (1)
      INTO l_count
      FROM EAGLEMGR.EAGLE_SERVICES es
     WHERE es.SERVICE_TYPE = 'ESTARENGINE' AND es.SERVICE_NAME LIKE 'OWS-%';

    IF l_count = 0
    THEN
        DBMS_OUTPUT.put_line (' No OWS engines found. ');
    ELSE
        SELECT COUNT (1)
          INTO l_eng_count
          FROM EAGLEMGR.EAGLE_SERVICES s, EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
         WHERE     s.INSTANCE = p.SERVICE_INSTANCE
               AND s.SERVICE_TYPE = 'ESTARENGINE'
			   AND p.PROPERTY_NAME = 'GROUP'
               AND (   p.PROPERTY_DEFAULT_VALUE LIKE 'OWS%'
                    OR p.PROPERTY_VALUE LIKE 'OWS%');

        DBMS_OUTPUT.put_line (
            ' Number of OWS engines found before update is : ' || l_eng_count);

        IF l_eng_count = 0
        THEN
            FOR a
                IN (SELECT s.INSTANCE
                      FROM EAGLEMGR.EAGLE_SERVICES s
                     WHERE     s.SERVICE_TYPE = 'ESTARENGINE'
                           AND s.SERVICE_NAME LIKE 'OWS-%')
            LOOP
                BEGIN
                   UPDATE EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
                      SET p.PROPERTY_DEFAULT_VALUE = 'OWS',
                          p.PROPERTY_VALUE = 'OWS'
                    WHERE p.SERVICE_INSTANCE = a.INSTANCE
                      AND p.PROPERTY_NAME = 'GROUP';
                END;
                l_loopcount := l_loopcount + 1;
            END LOOP;

            DBMS_OUTPUT.put_line (
                ' Number of OWS engines updated is : ' || l_loopcount);
        ELSE
            DBMS_OUTPUT.put_line (' No OWS engines found to be re-grouped... ');
        END IF;
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line ('Checking WBT Engines to re-group... ');
END;
/

DECLARE
    l_count       VARCHAR2 (128);
    l_eng_count   VARCHAR2 (128);
    l_loopcount   VARCHAR2 (128);
BEGIN
    l_count := 0;
    l_eng_count := 0;
    l_loopcount := 0;

    SELECT COUNT (1)
      INTO l_count
      FROM EAGLEMGR.EAGLE_SERVICES es
     WHERE es.SERVICE_TYPE = 'ESTARENGINE' AND es.SERVICE_NAME LIKE 'WBT%';

    IF l_count = 0
    THEN
        DBMS_OUTPUT.put_line (' No WBT engines found. ');
    ELSE
        SELECT COUNT (1)
          INTO l_eng_count
          FROM EAGLEMGR.EAGLE_SERVICES s, EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
         WHERE     s.INSTANCE = p.SERVICE_INSTANCE
               AND s.SERVICE_TYPE = 'ESTARENGINE'
			   AND p.PROPERTY_NAME = 'GROUP'
               AND (   p.PROPERTY_DEFAULT_VALUE LIKE 'WBT%'
                    OR p.PROPERTY_VALUE LIKE 'WBT%');

        DBMS_OUTPUT.put_line (
            ' Number of WBT engines found before update is : ' || l_eng_count);

        IF l_eng_count = 0
        THEN
            FOR a
                IN (SELECT s.INSTANCE
                      FROM EAGLEMGR.EAGLE_SERVICES s
                     WHERE     s.SERVICE_TYPE = 'ESTARENGINE'
                           AND s.SERVICE_NAME LIKE 'WBT%')
            LOOP
                BEGIN
                   UPDATE EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
                      SET p.PROPERTY_DEFAULT_VALUE = 'WBT',
                          p.PROPERTY_VALUE = 'WBT'
                    WHERE p.SERVICE_INSTANCE = a.INSTANCE
                      AND p.PROPERTY_NAME = 'GROUP';
                END;
                l_loopcount := l_loopcount + 1;
            END LOOP;

            DBMS_OUTPUT.put_line (
                ' Number of WBT engines updated is : ' || l_loopcount);
        ELSE
            DBMS_OUTPUT.put_line (' No WBT engines found to be re-grouped... ');
        END IF;
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line (' Checking BATCH Engines to re-group... ');
END;
/

DECLARE
    l_count       VARCHAR2 (128);
    l_eng_count   VARCHAR2 (128);
    l_loopcount   VARCHAR2 (128);
BEGIN
    l_count := 0;
    l_eng_count := 0;
    l_loopcount := 0;

    SELECT COUNT (1)
      INTO l_count
      FROM EAGLEMGR.EAGLE_SERVICES es
     WHERE es.SERVICE_TYPE = 'ESTARENGINE' AND es.SERVICE_NAME LIKE 'BATCH%';

    IF l_count = 0
    THEN
        DBMS_OUTPUT.put_line (' No BATCH engines found. ');
    ELSE
        SELECT COUNT (1)
          INTO l_eng_count
          FROM EAGLEMGR.EAGLE_SERVICES s, EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
         WHERE     s.INSTANCE = p.SERVICE_INSTANCE
               AND s.SERVICE_TYPE = 'ESTARENGINE'
			   AND p.PROPERTY_NAME = 'GROUP'
               AND (   p.PROPERTY_DEFAULT_VALUE LIKE 'BATCH%'
                    OR p.PROPERTY_VALUE LIKE 'BATCH%');

        DBMS_OUTPUT.put_line (
            ' Number of BATCH engines found before update is : ' || l_eng_count);

        IF l_eng_count = 0
        THEN
            FOR a
                IN (SELECT s.INSTANCE
                      FROM EAGLEMGR.EAGLE_SERVICES s
                     WHERE     s.SERVICE_TYPE = 'ESTARENGINE'
                           AND s.SERVICE_NAME LIKE 'BATCH%')
            LOOP
                BEGIN
                   UPDATE EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
                      SET p.PROPERTY_DEFAULT_VALUE = 'BATCH',
                          p.PROPERTY_VALUE = 'BATCH'
                    WHERE p.SERVICE_INSTANCE = a.INSTANCE
                      AND p.PROPERTY_NAME = 'GROUP';
                END;
                l_loopcount := l_loopcount + 1;
            END LOOP;

            DBMS_OUTPUT.put_line (
                ' Number of BATCH engines updated is : ' || l_loopcount);
        ELSE
            DBMS_OUTPUT.put_line (' No BATCH engines found to be re-grouped... ');
        END IF;
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line (' Checking TRAN Engines to re-group... ');
END;
/

DECLARE
    l_count       VARCHAR2 (128);
    l_eng_count   VARCHAR2 (128);
    l_loopcount   VARCHAR2 (128);
BEGIN
    l_count := 0;
    l_eng_count := 0;
    l_loopcount := 0;

    SELECT COUNT (1)
      INTO l_count
      FROM EAGLEMGR.EAGLE_SERVICES es
     WHERE es.SERVICE_TYPE = 'ESTARENGINE' AND es.SERVICE_NAME LIKE 'TRAN%';

    IF l_count = 0
    THEN
        DBMS_OUTPUT.put_line (' No TRAN engines found. ');
    ELSE
        SELECT COUNT (1)
          INTO l_eng_count
          FROM EAGLEMGR.EAGLE_SERVICES s, EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
         WHERE     s.INSTANCE = p.SERVICE_INSTANCE
               AND s.SERVICE_TYPE = 'ESTARENGINE'
			   AND p.PROPERTY_NAME = 'GROUP'
               AND (   p.PROPERTY_DEFAULT_VALUE LIKE 'TRAN%'
                    OR p.PROPERTY_VALUE LIKE 'TRAN%');

        DBMS_OUTPUT.put_line (
            ' Number of TRAN engines found before update is : ' || l_eng_count);

        IF l_eng_count = 0
        THEN
            FOR a
                IN (SELECT s.INSTANCE
                      FROM EAGLEMGR.EAGLE_SERVICES s
                     WHERE     s.SERVICE_TYPE = 'ESTARENGINE'
                           AND s.SERVICE_NAME LIKE 'TRAN%')
            LOOP
                BEGIN
                   UPDATE EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
                      SET p.PROPERTY_DEFAULT_VALUE = 'TRAN',
                          p.PROPERTY_VALUE = 'TRAN'
                    WHERE p.SERVICE_INSTANCE = a.INSTANCE
                      AND p.PROPERTY_NAME = 'GROUP';
                END;
                l_loopcount := l_loopcount + 1;
            END LOOP;

            DBMS_OUTPUT.put_line (
                ' Number of TRAN engines updated is : ' || l_loopcount);
        ELSE
            DBMS_OUTPUT.put_line (' No TRAN engines found to be re-grouped... ');
        END IF;
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.put_line (
        '------------------------------------------------------------------------');
    DBMS_OUTPUT.put_line ('Checking OTHERS Engines to re-group... ');
END;
/

DECLARE
    l_count       VARCHAR2 (128);
    l_eng_count   VARCHAR2 (128);
    l_loopcount   VARCHAR2 (128);
BEGIN
    l_count := 0;
    l_eng_count := 0;
    l_loopcount := 0;

    SELECT COUNT (1)
      INTO l_count
      FROM EAGLEMGR.EAGLE_SERVICES es
     WHERE es.SERVICE_TYPE = 'ESTARENGINE' 
	   AND es.SERVICE_NAME NOT LIKE 'MT-%'
       AND es.SERVICE_NAME NOT LIKE 'ST-%'
       AND es.SERVICE_NAME NOT LIKE 'BT-%'
       AND es.SERVICE_NAME NOT LIKE 'AD-ST-%'
       AND es.SERVICE_NAME NOT LIKE 'AD-MT-%'
       AND es.SERVICE_NAME NOT LIKE 'TRAN%'
       AND es.SERVICE_NAME NOT LIKE 'BATCH%'
       AND es.SERVICE_NAME NOT LIKE 'OWS-%'
       AND es.SERVICE_NAME NOT LIKE 'WBT_%';

    IF l_count = 0
    THEN
        DBMS_OUTPUT.put_line (' No OTHER engines found. ');
    ELSE
        SELECT COUNT (1)
          INTO l_eng_count
          FROM EAGLEMGR.EAGLE_SERVICES s, EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
         WHERE     s.INSTANCE = p.SERVICE_INSTANCE
               AND s.SERVICE_TYPE = 'ESTARENGINE'
			   AND p.PROPERTY_NAME = 'GROUP'
               AND s.SERVICE_NAME NOT LIKE 'MT-%'
               AND s.SERVICE_NAME NOT LIKE 'ST-%'
               AND s.SERVICE_NAME NOT LIKE 'BT-%'
               AND s.SERVICE_NAME NOT LIKE 'AD-ST-%'
               AND s.SERVICE_NAME NOT LIKE 'AD-MT-%'
               AND s.SERVICE_NAME NOT LIKE 'TRAN%'
               AND s.SERVICE_NAME NOT LIKE 'BATCH%'
               AND s.SERVICE_NAME NOT LIKE 'OWS-%'
               AND s.SERVICE_NAME NOT LIKE 'WBT_%'
               AND (   p.PROPERTY_DEFAULT_VALUE LIKE 'OTHER%'
                    OR p.PROPERTY_VALUE LIKE 'OTHER%');

        DBMS_OUTPUT.put_line (
            ' Number of OTHER engines found before update is : ' || l_eng_count);

        IF l_eng_count = 0
        THEN
            FOR a
                IN (SELECT s.INSTANCE
                      FROM EAGLEMGR.EAGLE_SERVICES s
                     WHERE     s.SERVICE_TYPE = 'ESTARENGINE'
                       AND s.SERVICE_NAME NOT LIKE 'MT-%'
                       AND s.SERVICE_NAME NOT LIKE 'ST-%'
                       AND s.SERVICE_NAME NOT LIKE 'BT-%'
                       AND s.SERVICE_NAME NOT LIKE 'AD-ST-%'
                       AND s.SERVICE_NAME NOT LIKE 'AD-MT-%'
                       AND s.SERVICE_NAME NOT LIKE 'TRAN%'
                       AND s.SERVICE_NAME NOT LIKE 'BATCH%'
                       AND s.SERVICE_NAME NOT LIKE 'OWS-%'
                       AND s.SERVICE_NAME NOT LIKE 'WBT_%')
            LOOP
                BEGIN
                   UPDATE EAGLEMGR.EAGLE_SERVICE_PROPERTIES p
                      SET p.PROPERTY_DEFAULT_VALUE = 'OTHER',
                          p.PROPERTY_VALUE = 'OTHER'
                    WHERE p.SERVICE_INSTANCE = a.INSTANCE
                      AND p.PROPERTY_NAME = 'GROUP';
                END;
                l_loopcount := l_loopcount + 1;
            END LOOP;

            DBMS_OUTPUT.put_line (
                ' Number of OTHER engines updated is : ' || l_loopcount);
        ELSE
            DBMS_OUTPUT.put_line (' No OTHER engines found to be re-grouped... ');
        END IF;
    END IF;
END;
/

--spool off;
SET SERVEROUTPUT OFF;
SET ECHO ON;

EXIT