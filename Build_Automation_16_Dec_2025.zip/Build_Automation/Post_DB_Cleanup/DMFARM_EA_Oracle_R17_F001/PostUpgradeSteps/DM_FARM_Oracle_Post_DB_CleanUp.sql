delete pace_masterdbo.egl_sched_def_params where parameter_type = 4;
commit;

declare 
  lval char(100);
begin
  reset_farm_cycle (lval,1);
end;
/
commit;
/