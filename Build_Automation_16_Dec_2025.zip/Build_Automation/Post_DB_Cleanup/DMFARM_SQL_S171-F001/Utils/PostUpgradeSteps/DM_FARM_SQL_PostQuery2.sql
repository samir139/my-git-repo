USE [PACE_MASTER]
GO

IF NOT EXISTS (SELECT name from sysobjects  where name = 'RULES_ENTITY_DETAIL' and type = 'P' ) 
 EXEC (' CREATE PROC RULES_ENTITY_DETAIL
(@in_cc_entity varchar(1),
@in_username char(100),
@in_entity_id char(8),
@in_entity_name char(30),
@in_entity_type char(4),
@in_switch varchar(15),
@in_lead_clone varchar(8),
@in_sector_type varchar(30)
) AS
BEGIN 
  SELECT NULL 
END
')
GO

USE [PACE_MASTER]
GO

IF NOT EXISTS (SELECT name from sysobjects  where name = 'ENTITY_HIST_QUERY' and type = 'P' ) 
 EXEC (' CREATE PROC ENTITY_HIST_QUERY
(@in_entity_id char(8),
@in_entity_name char(30),
@in_entity_type char(4),
@in_start_date varchar(8),
@in_end_date varchar(8),
@in_switch varchar(15)
) AS
BEGIN 
  SELECT NULL 
END
')
GO