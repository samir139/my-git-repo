USE [HOLDING]
GO
  
CREATE PROCEDURE QRY_TOTAL_LOTS_SUMMARY (  
  @in_pos_entity_id               CHAR(8),          --5  
  @in_source_l                    VARCHAR(20),      --1102   
  @in_source_r                    VARCHAR(20),      --1104   
  @in_effective_date              VARCHAR(8),       --1109  
  @in_effective_date_start        VARCHAR(8),       --220  
  --@in_effective_date_start        VARCHAR(8),       --220  
  @in_effective_date_end          VARCHAR(8),       --221  
  @in_security_alias              INTEGER,          -- 10  
  @in_entity_list_id              VARCHAR(8),       --1091  
  @in_update_source               VARCHAR(255)      --944  
  
) AS    
  
        DECLARE @lv_effective_date  DATETIME,  
                @current_date       DATETIME,  
    @lv_user_business_group_id INTEGER,  
    @lv_is_superuser INTEGER  
  
        SET @lv_effective_date = CONVERT(DATETIME,RTRIM(@in_effective_date),112)  
        SET @current_date=getdate()  
  
   CREATE TABLE #TEMP_COMP_GROUP_RESOLVE (entity_id CHAR(8) NULL)  
  
/* FIND BUSINESS GROUPS FOR CURRENT USER AND CHECK ON SUPERUSER */  
  
IF @in_pos_entity_id IS NULL   
BEGIN   
    SELECT @lv_user_business_group_id = GU.GROUP_ID  
      FROM PACE_MASTER.DBO.PACE_USERS U, PACE_MASTER.DBO.PACE_USER_GROUPS GU  
     WHERE U.GROUP_ID = GU.GROUP_ID   
       AND RTRIM(U.USERNAME) = RTRIM(@in_update_source)  
      
 EXEC  PACE_MASTER.DBO.RESOLVE_COMPOUND_GROUP @in_update_source,@lv_is_superuser OUTPUT  
END  
  
BEGIN  
        
    CREATE TABLE #LotsBE(  
                            INSTANCE                        BIGINT         ,      
                            LOT_ID_L                        BIGINT         ,      
                            LOT_ID_R                        BIGINT         ,      
                            MASTER_TICKET_NUMBER_L          VARCHAR(60)    ,   
                            MASTER_TICKET_NUMBER_R          VARCHAR(60)    ,  
                            ORIG_EVENT_ID_L                 VARCHAR(55)    ,  
                            ORIG_EVENT_ID_R                 VARCHAR(55)    ,  
                            LOT_ID_FLAG                     INTEGER        ,  
                            SRC_INTFC_INST_L                INTEGER        ,  
                            SRC_INTFC_INST_R                INTEGER        ,  
                            L_LONG_SOURCE_NAME              VARCHAR(100)   ,  
                            R_LONG_SOURCE_NAME              VARCHAR(100)   ,  
                            SECURITY_ALIAS                  INTEGER        ,  
                            ENTITY_ID                       CHAR(8)        ,  
                            ENTITY_NAME                     VARCHAR(30)    ,  
                            ACCOUNTING_BASIS                VARCHAR(15)    ,   
                            PRIMARY_ASSET_ID                VARCHAR(100)   ,  
                            PRIMARY_ASSET_ID_TYPE           VARCHAR(100)   ,   
                            LONG_SHORT_IND                  VARCHAR(25)    ,  
                            CURRENCY_CODE                   VARCHAR(30)    ,  
                            BASE_CURRENCY                   VARCHAR(30)    ,    
                            PROCESS_SEC_TYPE                VARCHAR(30)    ,    
                            SECURITY_TYPE                   VARCHAR(15)    ,    
                            ORIG_FACE_OOB                   DECIMAL(38,12) ,    
                            PAR_OR_SHARES_OOB               DECIMAL(38,12) ,    
                            BOOK_VALUE_OOB                  DECIMAL(38,12) ,     
                            ACCRUED_INCOME_OOB              DECIMAL(38,12) ,     
                            AMORT_LTD_BASE_OOB              DECIMAL(38,12) ,     
                            INTEREST_SOLD_BASE_OOB          DECIMAL(38,12) ,     
                            INT_RECEIVED_OOB                DECIMAL(38,12) ,    
                            OID_LTD_INCOME_OOB              DECIMAL(38,12) ,    
                            MARKET_VALUE_INCOME_OOB         DECIMAL(38,12) ,    
                            NOTIONAL_COST_OOB               DECIMAL(38,12) ,   
                            MKT_VALUE_BASE_OOB              DECIMAL(38,12) ,    
                            NOTIONAL_MARKET_VALUE_OOB       DECIMAL(38,12) ,    
                            TIP_LTD_INCOME_OOB              DECIMAL(38,12) ,    
                            CLS_AMORT_BASE_OOB              DECIMAL(38,12) ,    
                            CLS_OID_INCOME_OOB              DECIMAL(38,12) ,   
                            CLS_TIPS_INCOME_OOB             DECIMAL(38,12) ,    
                            ACCR_LTD_BASE_OOB               DECIMAL(38,12) ,    
                            AMORT_PTD_BASE_OOB              DECIMAL(38,12) ,   
                            CREDIT_LOSS_B_OOB               DECIMAL(38,12) ,   
                            DEF_INCM_TOTAL_PTD_B_OOB        DECIMAL(38,12) ,   
                            IMPAIRMENT_LTD_BASE_OOB         DECIMAL(38,12) ,  
                            NON_CREDIT_LOSS_B_OOB           DECIMAL(38,12) ,     
                            OID_PTD_BASE_OOB                DECIMAL(38,12) ,     
                            ORIG_ACCR_PTD_BASE_OOB          DECIMAL(38,12) ,     
                            ORIG_SOLD_INT_BASE_OOB          DECIMAL(38,12) ,     
                            ORIG_TRADED_INT_BASE_OOB        DECIMAL(38,12) ,     
                            ORIG_ACQ_COST_BASE_OOB          DECIMAL(38,12) ,     
                            TIPS_PTD_BASE_OOB               DECIMAL(38,12) ,     
                            CURR_WS_DIS_LOSS_B_OOB          DECIMAL(38,12) ,  
                            TRADE_DATE_OOB                  VARCHAR(9)    ,  
                            ORIG_FACE_TOL                   DECIMAL(38,12) ,       
                            PAR_OR_SHARES_TOL               DECIMAL(38,12) ,       
                            BOOK_VALUE_TOL                  DECIMAL(38,12) ,       
                            ACCRUED_INCOME_TOL              DECIMAL(38,12) ,       
                            AMORT_LTD_BASE_TOL              DECIMAL(38,12) ,       
                            INTEREST_SOLD_BASE_TOL          DECIMAL(38,12) ,       
                            INT_RECEIVED_TOL                DECIMAL(38,12) ,       
                            OID_LTD_INCOME_TOL              DECIMAL(38,12) ,       
                            MARKET_VALUE_INCOME_TOL         DECIMAL(38,12) ,       
                            NOTIONAL_COST_TOL               DECIMAL(38,12) ,       
                            MKT_VALUE_BASE_TOL              DECIMAL(38,12) ,       
                            NOTIONAL_MARKET_VALUE_TOL       DECIMAL(38,12) ,       
                            TIP_LTD_INCOME_TOL              DECIMAL(38,12) ,       
                            CLS_AMORT_BASE_TOL              DECIMAL(38,12) ,       
                            CLS_OID_INCOME_TOL              DECIMAL(38,12) ,       
                            CLS_TIPS_INCOME_TOL             DECIMAL(38,12) ,       
                            ACCR_LTD_BASE_TOL               DECIMAL(38,12) ,       
                            AMORT_PTD_BASE_TOL              DECIMAL(38,12) ,       
                            CREDIT_LOSS_B_TOL               DECIMAL(38,12) ,       
                            DEF_INCM_TOTAL_PTD_B_TOL        DECIMAL(38,12) ,       
                            IMPAIRMENT_LTD_BASE_TOL         DECIMAL(38,12) ,       
                            NON_CREDIT_LOSS_B_TOL           DECIMAL(38,12) ,       
                            OID_PTD_BASE_TOL                DECIMAL(38,12) ,       
                            ORIG_ACCR_PTD_BASE_TOL          DECIMAL(38,12) ,       
                            ORIG_SOLD_INT_BASE_TOL          DECIMAL(38,12) ,       
                            ORIG_TRADED_INT_BASE_TOL        DECIMAL(38,12) ,       
                            ORIG_ACQ_COST_BASE_TOL          DECIMAL(38,12) ,       
                            TIPS_PTD_BASE_TOL               DECIMAL(38,12) ,       
                            CURR_WS_DIS_LOSS_B_TOL          DECIMAL(38,12) ,  
                            EFFECTIVE_DATE_EX               VARCHAR(10)    ,      
                            UPDATE_DATE_EX                  VARCHAR(10)    ,       
                            UPDATE_SOURCE                   VARCHAR(32)    ,  
                            STATUS                          INTEGER        ,         
                            R_ORIG_FACE                     DECIMAL(38,12) ,       
                            R_PAR_OR_SHARES                 DECIMAL(38,12) ,        
                            R_BOOK_VALUE                    DECIMAL(38,12) ,        
                            R_ACCRUED_INCOME                DECIMAL(38,12) ,        
                            R_AMORTIZATION_LTD_BASE         DECIMAL(38,12) ,       
                            R_INTEREST_SOLD_BASE            DECIMAL(38,12) ,      
                            R_INT_RECEIVED                  DECIMAL(38,12) ,     
                            R_OID_LTD_INCOME                DECIMAL(38,12) ,    
                            R_MARKET_VALUE_INCOME           DECIMAL(38,12) ,   
                            R_NOTIONAL_COST                 DECIMAL(38,12) ,     
                            R_MARKET_VALUE                  DECIMAL(38,12) ,     
                            R_NOTIONAL_MARKET_VALUE         DECIMAL(38,12) ,     
                            R_TIP_LTD_INCOME                DECIMAL(38,12) ,      
                            R_CLS_AMORT_BASE                DECIMAL(38,12) ,      
                            R_CLS_OID_INCOME                DECIMAL(38,12) ,  
                            R_CLS_TIPS_INCOME               DECIMAL(38,12) ,  
                            TRADE_DATE_R_LLP                VARCHAR(10)    ,  
                            SETTLEMENT_DATE_R_LLP           VARCHAR(10)    ,    
                            ORIG_ACQ_DATE_R_LLP             VARCHAR(10)    ,  
                            ORIG_OPEN_SETTLE_DATE_R_LLP     VARCHAR(10)    ,  
                            R_ACCR_LTD_BASE                 DECIMAL(38,12) ,         
                            R_AMORT_PTD_BASE                DECIMAL(38,12) ,         
                            R_CREDIT_LOSS_B                 DECIMAL(38,12) ,         
                            R_DEFERRED_INCOME_TOTAL_PTD_B   DECIMAL(38,12) ,         
                            R_IMPAIRMENT_LTD_BASE           DECIMAL(38,12) ,         
                            R_NON_CREDIT_LOSS_B             DECIMAL(38,12) ,         
                            R_OID_PTD_BASE                  DECIMAL(38,12) ,         
                            R_ORIG_ACCR_PTD_BASE            DECIMAL(38,12) ,         
                            R_ORIG_SOLD_INTEREST_BASE       DECIMAL(38,12) ,         
                            R_ORIG_TRADED_INTEREST_BASE     DECIMAL(38,12) ,         
                            R_ORIG_ACQ_COST_BASE            DECIMAL(38,12) ,         
                            R_TIPS_PTD_BASE                 DECIMAL(38,12) ,         
                            CURR_WS_DIS_LOSS_B_R            DECIMAL(38,12) ,   
                            PCL_USER_DATE3_R                VARCHAR(10)    ,  
                            ORIG_ACQ_DATE_r                 VARCHAR(10)    ,  
                            TRADE_DATE_r                    VARCHAR(10)    ,  
                            L_ORIG_FACE                     DECIMAL(38,12) ,         
                            L_PAR_OR_SHARES                 DECIMAL(38,12) ,         
                            L_BOOK_VALUE                    DECIMAL(38,12) ,         
                            L_ACCRUED_INCOME                DECIMAL(38,12) ,         
                            L_AMORTIZATION_LTD_BASE         DECIMAL(38,12) ,         
                            L_INTEREST_SOLD_BASE            DECIMAL(38,12) ,         
                            L_INT_RECEIVED                  DECIMAL(38,12) ,         
                            L_OID_LTD_INCOME                DECIMAL(38,12) ,   
                            L_MARKET_VALUE_INCOME           DECIMAL(38,12) ,         
                            L_NOTIONAL_COST                 DECIMAL(38,12) ,         
                            L_MARKET_VALUE                  DECIMAL(38,12) ,         
                            L_NOTIONAL_MARKET_VALUE         DECIMAL(38,12) ,         
                            L_TIP_LTD_INCOME                DECIMAL(38,12) ,         
                            L_CLS_AMORT_BASE                DECIMAL(38,12) ,          
                            L_CLS_OID_INCOME                DECIMAL(38,12) ,          
                            L_CLS_TIPS_INCOME               DECIMAL(38,12) ,     
                            L_TRADE_DATE                    VARCHAR(10)    ,  
                            L_SETTLEMENT_DATE               VARCHAR(10)    ,  
                            L_ORIG_ACQ_DATE                 VARCHAR(10)    ,  
                            L_ORIG_OPEN_SETTLE_DATE         VARCHAR(10)    ,  
                            L_ACCR_LTD_BASE                 DECIMAL(38,12) ,        
                            L_AMORT_PTD_BASE                DECIMAL(38,12) ,        
                            L_CREDIT_LOSS_B                 DECIMAL(38,12) ,        
                            L_DEFERRED_INCOME_TOTAL_PTD_B   DECIMAL(38,12) ,        
                            L_IMPAIRMENT_LTD_BASE           DECIMAL(38,12) ,        
                            L_NON_CREDIT_LOSS_B             DECIMAL(38,12) ,        
                            L_OID_PTD_BASE                  DECIMAL(38,12) ,        
                            L_ORIG_ACCR_PTD_BASE            DECIMAL(38,12) ,        
                            L_ORIG_SOLD_INTEREST_BASE       DECIMAL(38,12) ,        
                            L_ORIG_TRADED_INTEREST_BASE     DECIMAL(38,12) ,        
                            L_ORIG_ACQ_COST_BASE            DECIMAL(38,12) ,        
                            L_TIPS_PTD_BASE                 DECIMAL(38,12) ,        
                            CURR_WS_DIS_LOSS_B_L            DECIMAL(38,12) ,        
                            PCL_USER_DATE3_L                VARCHAR(10)    ,  
                            ORIG_ACQ_DATE_L                 VARCHAR(10)    ,  
                            TRADE_DATE_L                    VARCHAR(10)    ,    
                            ASSIGN_TO                       VARCHAR(60)    ,  
                            ASSIGN_TO_GROUP                 VARCHAR(60)    ,  
                            ASSIGN_FROM                     VARCHAR(60)    ,  
                            CATEGORY                        VARCHAR(60)    ,  
                            COMMENT_TEXT                    VARCHAR(2000)  ,  
                            SUB_CATEGORY                    VARCHAR(60)    ,  
                            OPEN_CLOSE_STATUS               VARCHAR(1)     ,  
                            CATEGORY_IS_CODE                VARCHAR(1)     ,  
                            EFFECTIVE_DATE_RC               VARCHAR(10)    ,  
                            SUBCATEGORY_IS_CODE             VARCHAR(8)     ,  
                            APPROVED                        VARCHAR(8)     ,  
                            ISSUE_NAME                      VARCHAR(255)   ,  
                            COMM_AGE                        INTEGER  
                        );  
  
INSERT INTO #LotsBE      
                SELECT   
                    INSTANCE                        ,  
                    LOT_ID_L                        ,  
                    LOT_ID_R                        ,  
                    MASTER_TICKET_NUMBER_L          ,  
                    MASTER_TICKET_NUMBER_R          ,  
                    ORIG_EVENT_ID_L                 ,  
                    ORIG_EVENT_ID_R                 ,  
                    LOT_ID_FLAG                     ,  
                    SRC_INTFC_INST_L                ,  
                    SRC_INTFC_INST_R                ,  
                    L_LONG_SOURCE_NAME        ,  
                    R_LONG_SOURCE_NAME              ,  
                    SECURITY_ALIAS                  ,  
                    ENTITY_ID                       ,  
                    ENTITY_NAME                     ,  
                    ACCOUNTING_BASIS                ,  
                    PRIMARY_ASSET_ID                ,  
                    PRIMARY_ASSET_ID_TYPE           ,  
                    LONG_SHORT_IND                  ,  
                    CURRENCY_CODE                   ,  
                    BASE_CURRENCY                   ,  
                    PROCESS_SEC_TYPE                ,  
                    SECURITY_TYPE                   ,  
                    ORIG_FACE_OOB                   ,  
                    PAR_OR_SHARES_OOB               ,  
                    BOOK_VALUE_OOB                  ,  
                    ACCRUED_INCOME_OOB              ,  
                    AMORT_LTD_BASE_OOB              ,  
                    INTEREST_SOLD_BASE_OOB          ,  
                    INT_RECEIVED_OOB                ,  
                    OID_LTD_INCOME_OOB              ,  
                    MARKET_VALUE_INCOME_OOB         ,  
                    NOTIONAL_COST_OOB               ,  
                    MKT_VALUE_BASE_OOB              ,  
                    NOTIONAL_MARKET_VALUE_OOB       ,  
                    TIP_LTD_INCOME_OOB              ,  
                    CLS_AMORT_BASE_OOB              ,  
                    CLS_OID_INCOME_OOB              ,  
                    CLS_TIPS_INCOME_OOB             ,  
                    ACCR_LTD_BASE_OOB               ,  
                    AMORT_PTD_BASE_OOB              ,  
                    CREDIT_LOSS_B_OOB               ,  
                    DEF_INCM_TOTAL_PTD_B_OOB        ,  
                    IMPAIRMENT_LTD_BASE_OOB         ,  
                    NON_CREDIT_LOSS_B_OOB           ,  
                    OID_PTD_BASE_OOB                ,  
                    ORIG_ACCR_PTD_BASE_OOB          ,  
                    ORIG_SOLD_INT_BASE_OOB          ,  
                    ORIG_TRADED_INT_BASE_OOB        ,  
                    ORIG_ACQ_COST_BASE_OOB          ,  
                    TIPS_PTD_BASE_OOB               ,  
                    CURR_WS_DIS_LOSS_B_OOB          ,  
                    TRADE_DATE_OOB                  ,  
                    ORIG_FACE_TOL                   ,  
                    PAR_OR_SHARES_TOL               ,  
                    BOOK_VALUE_TOL                  ,  
                    ACCRUED_INCOME_TOL              ,  
                    AMORT_LTD_BASE_TOL              ,  
                    INTEREST_SOLD_BASE_TOL          ,  
                    INT_RECEIVED_TOL                ,  
                    OID_LTD_INCOME_TOL              ,  
                    MARKET_VALUE_INCOME_TOL         ,  
                    NOTIONAL_COST_TOL               ,  
                    MKT_VALUE_BASE_TOL              ,  
                    NOTIONAL_MARKET_VALUE_TOL       ,  
                    TIP_LTD_INCOME_TOL              ,  
                    CLS_AMORT_BASE_TOL              ,  
                    CLS_OID_INCOME_TOL              ,  
                    CLS_TIPS_INCOME_TOL             ,  
                    ACCR_LTD_BASE_TOL               ,  
                    AMORT_PTD_BASE_TOL              ,  
                    CREDIT_LOSS_B_TOL               ,  
                    DEF_INCM_TOTAL_PTD_B_TOL        ,  
                    IMPAIRMENT_LTD_BASE_TOL         ,  
                    NON_CREDIT_LOSS_B_TOL           ,  
                    OID_PTD_BASE_TOL                ,  
                    ORIG_ACCR_PTD_BASE_TOL          ,  
                    ORIG_SOLD_INT_BASE_TOL          ,  
                    ORIG_TRADED_INT_BASE_TOL        ,  
                    ORIG_ACQ_COST_BASE_TOL          ,  
                    TIPS_PTD_BASE_TOL               ,  
                    CURR_WS_DIS_LOSS_B_TOL          ,  
                    EFFECTIVE_DATE_EX               ,  
                    UPDATE_DATE_EX                  ,  
                    UPDATE_SOURCE                   ,  
                    STATUS                          ,  
                    R_ORIG_FACE                     ,  
                    R_PAR_OR_SHARES                 ,  
                    R_BOOK_VALUE                    ,  
                    R_ACCRUED_INCOME                ,  
                    R_AMORTIZATION_LTD_BASE         ,  
                    R_INTEREST_SOLD_BASE            ,  
                    R_INT_RECEIVED                  ,  
                    R_OID_LTD_INCOME                ,  
                    R_MARKET_VALUE_INCOME           ,  
                    R_NOTIONAL_COST                 ,  
                    R_MARKET_VALUE                  ,  
                    R_NOTIONAL_MARKET_VALUE         ,  
                    R_TIP_LTD_INCOME                ,  
                    R_CLS_AMORT_BASE                ,  
                    R_CLS_OID_INCOME                ,  
                    R_CLS_TIPS_INCOME               ,  
                    TRADE_DATE_R_LLP                ,  
                    SETTLEMENT_DATE_R_LLP           ,  
                    ORIG_ACQ_DATE_R_LLP             ,  
                    ORIG_OPEN_SETTLE_DATE_R_LLP     ,  
                    R_ACCR_LTD_BASE                 ,  
                    R_AMORT_PTD_BASE                ,  
                    R_CREDIT_LOSS_B                 ,  
                    R_DEFERRED_INCOME_TOTAL_PTD_B   ,  
                    R_IMPAIRMENT_LTD_BASE           ,  
                    R_NON_CREDIT_LOSS_B             ,  
                    R_OID_PTD_BASE                  ,  
                    R_ORIG_ACCR_PTD_BASE            ,  
                    R_ORIG_SOLD_INTEREST_BASE       ,  
                    R_ORIG_TRADED_INTEREST_BASE     ,  
                    R_ORIG_ACQ_COST_BASE            ,  
                    R_TIPS_PTD_BASE                 ,  
                    CURR_WS_DIS_LOSS_B_R            ,  
                    --PCL_USER_DATE3_R                ,  
                    --ORIG_ACQ_DATE_r                 ,  
                    --TRADE_DATE_r                    ,  
                    L_ORIG_FACE                     ,  
                    L_PAR_OR_SHARES                 ,  
                    L_BOOK_VALUE                    ,  
                    L_ACCRUED_INCOME                ,  
                    L_AMORTIZATION_LTD_BASE         ,  
                    L_INTEREST_SOLD_BASE            ,  
                    L_INT_RECEIVED                  ,  
                    L_OID_LTD_INCOME                ,  
                    L_MARKET_VALUE_INCOME           ,  
                    L_NOTIONAL_COST                 ,  
                    L_MARKET_VALUE                  ,  
                    L_NOTIONAL_MARKET_VALUE         ,  
                    L_TIP_LTD_INCOME                ,  
                    L_CLS_AMORT_BASE                ,  
                    L_CLS_OID_INCOME                ,  
                    L_CLS_TIPS_INCOME               ,  
                    L_TRADE_DATE                    ,  
                    L_SETTLEMENT_DATE               ,  
                    L_ORIG_ACQ_DATE                 ,  
                    L_ORIG_OPEN_SETTLE_DATE         ,  
                    L_ACCR_LTD_BASE                 ,  
                    L_AMORT_PTD_BASE                ,  
                    L_CREDIT_LOSS_B                 ,  
                    L_DEFERRED_INCOME_TOTAL_PTD_B   ,  
                    L_IMPAIRMENT_LTD_BASE           ,  
                    L_NON_CREDIT_LOSS_B             ,  
                    L_OID_PTD_BASE                  ,  
                    L_ORIG_ACCR_PTD_BASE            ,  
                    L_ORIG_SOLD_INTEREST_BASE       ,  
                    L_ORIG_TRADED_INTEREST_BASE     ,  
                    L_ORIG_ACQ_COST_BASE            ,  
                    L_TIPS_PTD_BASE                 ,  
                    CURR_WS_DIS_LOSS_B_L            ,  
                    --PCL_USER_DATE3_L                ,  
     --ORIG_ACQ_DATE_L                 ,  
                    --TRADE_DATE_L                    ,  
                    ASSIGN_TO                       ,  
                    ASSIGN_TO_GROUP                 ,  
                    ASSIGN_FROM                     ,  
                    CATEGORY                        ,  
                    COMMENT_TEXT                    ,  
                    SUB_CATEGORY                    ,  
                    OPEN_CLOSE_STATUS               ,  
                    CATEGORY_IS_CODE                ,  
                    EFFECTIVE_DATE_RC               ,  
                    SUBCATEGORY_IS_CODE             ,  
                    APPROVED                        ,  
                    ISSUE_NAME                      ,  
                    COMM_AGE                           
                FROM ( SELECT  
                            -- exception table  
                            ex.INSTANCE                                      INSTANCE                   ,   -- 2769          
                            ex.LOT_ID_L                                      LOT_ID_L                   ,   -- 7251          
                            ex.LOT_ID_R                                      LOT_ID_R                   ,   -- 7252          
                            ex.MASTER_TICKET_NUMBER_L                        MASTER_TICKET_NUMBER_L     ,   -- 761           
                            ex.MASTER_TICKET_NUMBER_R                        MASTER_TICKET_NUMBER_R     ,   -- 762           
                            ex.orig_event_id_l                               orig_event_id_l            ,                
                            ex.orig_event_id_r                               orig_event_id_r            ,         
                            ex.lot_id_flag                                   lot_id_flag                ,  
                            ex.SRC_INTFC_INST_L                              SRC_INTFC_INST_L           ,   -- 1168          
                            ex.SRC_INTFC_INST_R                              SRC_INTFC_INST_R           ,   -- 4507          
                            msgcenter.dbo.get_long_desc(ex.SRC_INTFC_INST_L) L_long_source_name         ,   -- 1102  
                            msgcenter.dbo.get_long_desc(ex.SRC_INTFC_INST_R) R_long_source_name         ,   -- 1774  
                            ex.SECURITY_ALIAS                                SECURITY_ALIAS             ,   -- 10   
                            ex.ENTITY_ID                                     ENTITY_ID                  ,   -- 1163  
                            e.ENTITY_NAME                                    ENTITY_NAME                ,   -- 1164  
                            e.accounting_basis                               accounting_basis           ,   -- 309  
                            sm.primary_asset_id                              primary_asset_id           ,   -- 14   
                            sm.primary_asset_id_type                         primary_asset_id_type      ,   -- 1432   
                            ex.LONG_SHORT_IND                                LONG_SHORT_IND             ,   -- 15   
                            SM.currency_code                                 currency_code              ,   -- 85  
                            e.base_currency                                  base_currency              ,   -- 86  
                            sm.process_sec_type                              process_sec_type           ,   -- 3931  
                            sm.security_type                                 security_type              ,   -- 82  
                    -- Matching parameters  
                            ex.orig_face_OOB                                 orig_face_OOB              ,   -- 8608  
                            ex.par_or_shares_OOB                             par_or_shares_OOB          ,   -- 8609  
                            ex.book_value_OOB                                book_value_OOB ,   -- 8610  
                            ex.accrued_income_OOB                            accrued_income_OOB         ,   -- 8611  
                            ex.amort_ltd_base_OOB                            amort_ltd_base_OOB         ,   -- 8612  
                            ex.interest_sold_base_OOB                        interest_sold_base_OOB     ,   -- 8613  
                            ex.int_received_OOB                              int_received_OOB           ,   -- 8614  
                            ex.oid_ltd_income_OOB                            oid_ltd_income_OOB         ,   -- 8615  
                            ex.market_value_income_OOB                       market_value_income_OOB    ,   -- 8616  
                            ex.notional_cost_OOB                             notional_cost_OOB          ,   -- 8617  
                            ex.mkt_value_base_OOB                            mkt_value_base_OOB         ,   -- 8618  
                            ex.notional_market_value_OOB                     notional_market_value_OOB  ,   -- 8619  
                            ex.tip_ltd_income_OOB                            tip_ltd_income_OOB         ,   -- 8620  
                            ex.cls_amort_base_OOB                            cls_amort_base_OOB         ,   -- 8621  
                            ex.cls_oid_income_OOB                            cls_oid_income_OOB         ,   -- 8622  
                            ex.cls_tips_income_OOB                           cls_tips_income_OOB        ,   -- 8623  
                            ex.accr_ltd_base_OOB                             accr_ltd_base_OOB          ,   -- 8624  
                            ex.amort_ptd_base_OOB                            amort_ptd_base_OOB         ,   -- 8625  
                            ex.credit_loss_b_OOB                             credit_loss_b_OOB          ,   -- 8626  
                            ex.DEF_INCM_TOTAL_PTD_B_OOB                      DEF_INCM_TOTAL_PTD_B_OOB   ,   -- 8627  
                            ex.impairment_ltd_base_OOB                       impairment_ltd_base_OOB    ,   -- 8628  
                            ex.non_credit_loss_b_OOB                         non_credit_loss_b_OOB      ,   -- 8629  
                            ex.oid_ptd_base_OOB                              oid_ptd_base_OOB           ,   -- 8630  
                            ex.orig_accr_ptd_base_OOB                        orig_accr_ptd_base_OOB     ,   -- 8631  
                            ex.ORIG_SOLD_INT_BASE_OOB                        ORIG_SOLD_INT_BASE_OOB     ,   -- 8632  
                            ex.ORIG_TRADED_INT_BASE_OOB                      ORIG_TRADED_INT_BASE_OOB   ,   -- 8633  
                            ex.orig_acq_cost_base_OOB                        orig_acq_cost_base_OOB     ,   -- 8634  
                            ex.tips_ptd_base_OOB                             tips_ptd_base_OOB          ,   -- 8635  
                            ex.curr_ws_dis_loss_b_OOB                        curr_ws_dis_loss_b_OOB     ,   -- 8652  
                            CASE WHEN ex.trade_date_oob IS NULL THEN 'MATCHED' ELSE 'UNMATCHED' END trade_date_oob,  
                    -- Input TOL values  
                            ex.orig_face_TOL                                 orig_face_TOL              ,   -- 4064  
                            ex.par_or_shares_TOL                             par_or_shares_TOL          ,   -- 4065  
                            ex.book_value_TOL                                book_value_TOL             ,   -- 4066  
                            ex.accrued_income_TOL                            accrued_income_TOL         ,   -- 4067  
                            ex.amort_ltd_base_TOL                            amort_ltd_base_TOL         ,   -- 4068  
                            ex.interest_sold_base_TOL                        interest_sold_base_TOL     ,   -- 4069  
                            ex.int_received_TOL                              int_received_TOL           ,   -- 4070  
                            ex.oid_ltd_income_TOL                            oid_ltd_income_TOL         ,   -- 4071  
                            ex.market_value_income_TOL                       market_value_income_TOL    ,   -- 4072  
                            ex.notional_cost_TOL                             notional_cost_TOL          ,   -- 4073  
                            ex.mkt_value_base_TOL                            mkt_value_base_TOL         ,   -- 4074  
                            ex.notional_market_value_TOL                     notional_market_value_TOL  ,   -- 4075  
                            ex.tip_ltd_income_TOL                            tip_ltd_income_TOL         ,   -- 4076  
                            ex.cls_amort_base_TOL                            cls_amort_base_TOL         ,   -- 4077  
                            ex.cls_oid_income_TOL                            cls_oid_income_TOL         ,   -- 4078  
                            ex.cls_tips_income_TOL                           cls_tips_income_TOL        ,   -- 4079  
                            ex.accr_ltd_base_TOL                             accr_ltd_base_TOL          ,   -- 4080  
                            ex.amort_ptd_base_TOL                            amort_ptd_base_TOL         ,   -- 4081  
                            ex.credit_loss_b_TOL                             credit_loss_b_TOL          ,   -- 4082  
                            ex.DEF_INCM_TOTAL_PTD_B_TOL                      DEF_INCM_TOTAL_PTD_B_TOL   ,   -- 4083  
                            ex.impairment_ltd_base_TOL                       impairment_ltd_base_TOL    ,   -- 4084  
                            ex.non_credit_loss_b_TOL                         non_credit_loss_b_TOL      ,   -- 4085  
                            ex.oid_ptd_base_TOL                              oid_ptd_base_TOL           ,   -- 4086  
                            ex.orig_accr_ptd_base_TOL                        orig_accr_ptd_base_TOL     ,   -- 4087  
                            ex.ORIG_SOLD_INT_BASE_TOL                        ORIG_SOLD_INT_BASE_TOL     ,   -- 4088  
                            ex.ORIG_TRADED_INT_BASE_TOL                      ORIG_TRADED_INT_BASE_TOL   ,   -- 4089  
                            ex.orig_acq_cost_base_TOL                        orig_acq_cost_base_TOL     ,   -- 4090  
                            ex.tips_ptd_base_TOL                             tips_ptd_base_TOL          ,   -- 4091  
                            ex.curr_ws_dis_loss_b_TOL                        curr_ws_dis_loss_b_TOL     ,   -- 5625  
                    -- End of Matching parameters                                        
                            CONVERT(CHAR(10),ex.EFFECTIVE_DATE,120)          EFFECTIVE_DATE_EX          ,   -- 1109  
                            CONVERT(CHAR(10),ex.UPDATE_DATE,120)             UPDATE_DATE_EX             ,   -- 1106  
                            ex.UPDATE_SOURCE                                 UPDATE_SOURCE              ,   -- 944  
                            ex.status                                        status                     ,   -- 5574  
                    -- Details from RIGHT table                                                    
                            R_llp.ORIG_FACE                                   R_ORIG_FACE                     ,   -- 7960   
                            R_llp.PAR_OR_SHARES                               R_PAR_OR_SHARES                 ,   -- 7961  
                            R_llp.BOOK_VALUE                                  R_BOOK_VALUE                    ,   -- 7962  
                            R_llp.ACCRUED_INCOME                              R_ACCRUED_INCOME                ,   -- 7963  
                            R_llp.AMORTIZATION_LTD_BASE                       R_AMORTIZATION_LTD_BASE         ,   -- 7964  
                            R_llp.INTEREST_SOLD_BASE                          R_INTEREST_SOLD_BASE            ,   -- 7965  
                            R_llp.INT_RECEIVED                                R_INT_RECEIVED                  ,   -- 7966  
                            R_llp.OID_LTD_INCOME                              R_OID_LTD_INCOME                ,   -- 7967  
                            R_llp.MARKET_VALUE_INCOME                         R_MARKET_VALUE_INCOME           ,   -- 7968  
                            R_llp.NOTIONAL_COST                               R_NOTIONAL_COST                 ,   -- 7969  
                            R_llp.MARKET_VALUE                                R_MARKET_VALUE                  ,   -- 7970  
                            R_llp.NOTIONAL_MARKET_VALUE                       R_NOTIONAL_MARKET_VALUE         ,   -- 7971  
                            R_llp.TIP_LTD_INCOME                              R_TIP_LTD_INCOME                ,   -- 7972  
                            R_llp.CLS_AMORT_BASE                              R_CLS_AMORT_BASE                ,   -- 7973  
                            R_llp.CLS_OID_INCOME                              R_CLS_OID_INCOME                ,   -- 7974  
                            R_llp.CLS_TIPS_INCOME                             R_CLS_TIPS_INCOME               ,   -- 7975  
                            CONVERT(CHAR(10),R_llp.TRADE_DATE,120)            TRADE_DATE_R_llp                ,   -- 36  
                            CONVERT(CHAR(10),R_llp.SETTLEMENT_DATE,120)       SETTLEMENT_DATE_R_llp           ,   -- 38  
                            CONVERT(CHAR(10),R_llp.ORIG_ACQ_DATE,120)         ORIG_ACQ_DATE_R_llp             ,   -- 217  
                            CONVERT(CHAR(10),R_llp.ORIG_OPEN_SETTLE_DATE,120) ORIG_OPEN_SETTLE_DATE_R_llp     ,   -- 155    
                            R_pcl.ACCR_LTD_BASE                               R_ACCR_LTD_BASE                 ,   -- 7976  
                            R_pcl.AMORT_PTD_BASE                              R_AMORT_PTD_BASE                ,   -- 7977  
                            R_pcl.CREDIT_LOSS_B                               R_CREDIT_LOSS_B                 ,   -- 7978  
                            R_pcl.DEFERRED_INCOME_TOTAL_PTD_B                 R_DEFERRED_INCOME_TOTAL_PTD_B   ,   -- 7979  
                            R_pcl.IMPAIRMENT_LTD_BASE                         R_IMPAIRMENT_LTD_BASE           ,   -- 7980  
                            R_pcl.NON_CREDIT_LOSS_B                           R_NON_CREDIT_LOSS_B             ,   -- 7981  
                            R_pcl.OID_PTD_BASE                                R_OID_PTD_BASE                  ,   -- 7982  
                            R_pcl.ORIG_ACCR_PTD_BASE                          R_ORIG_ACCR_PTD_BASE            ,   -- 7983  
                            R_pcl.ORIG_SOLD_INTEREST_BASE                     R_ORIG_SOLD_INTEREST_BASE       ,   -- 7984  
                            R_pcl.ORIG_TRADED_INTEREST_BASE                   R_ORIG_TRADED_INTEREST_BASE     ,   -- 7985  
                            R_pcl.ORIG_ACQ_COST_BASE                          R_ORIG_ACQ_COST_BASE            ,   -- 7986  
                            R_pcl.TIPS_PTD_BASE                               R_TIPS_PTD_BASE                 ,   -- 7987  
                            ex.CURR_WS_DIS_LOSS_B_R                           CURR_WS_DIS_LOSS_B_R            ,  
                            --CONVERT(CHAR(10),ex.PCL_USER_DATE3_R,120)         PCL_USER_DATE3_R                ,   -- 164 open holding period date  
                            --CONVERT(CHAR(10),ex.ORIG_ACQ_DATE_R,120)          ORIG_ACQ_DATE_r                 ,  
                            --CONVERT(CHAR(10),ex.TRADE_DATE_R,120)             TRADE_DATE_r                    ,  
                    -- Details from OUTER LEFT table                                               
                            L_llp.ORIG_FACE                                   L_ORIG_FACE                     ,   -- 8634  
                            L_llp.PAR_OR_SHARES                               L_PAR_OR_SHARES             ,   -- 8635  
                            L_llp.BOOK_VALUE                                  L_BOOK_VALUE                    ,   -- 8636  
                            L_llp.ACCRUED_INCOME                              L_ACCRUED_INCOME                ,   -- 8637  
                            L_llp.AMORTIZATION_LTD_BASE                       L_AMORTIZATION_LTD_BASE         ,   -- 8638  
                            L_llp.INTEREST_SOLD_BASE                          L_INTEREST_SOLD_BASE            ,   -- 8639  
                            L_llp.INT_RECEIVED                                L_INT_RECEIVED                  ,   -- 8640  
                            L_llp.OID_LTD_INCOME                              L_OID_LTD_INCOME                ,   -- 8641  
                            L_llp.MARKET_VALUE_INCOME                         L_MARKET_VALUE_INCOME           ,   -- 8642  
                            L_llp.NOTIONAL_COST                               L_NOTIONAL_COST                 ,   -- 8643  
                            L_llp.MARKET_VALUE                                L_MARKET_VALUE                  ,   -- 8644  
                            L_llp.NOTIONAL_MARKET_VALUE                       L_NOTIONAL_MARKET_VALUE         ,   -- 8645  
                            L_llp.TIP_LTD_INCOME                              L_TIP_LTD_INCOME                ,   -- 8646  
                            L_llp.CLS_AMORT_BASE                              L_CLS_AMORT_BASE                ,   -- 8647  
                            L_llp.CLS_OID_INCOME                              L_CLS_OID_INCOME                ,   -- 8680  
                            L_llp.CLS_TIPS_INCOME                             L_CLS_TIPS_INCOME               ,   -- 8681  
                            CONVERT(CHAR(10),L_llp.TRADE_DATE,120)            L_TRADE_DATE                    ,   -- 35  
                            CONVERT(CHAR(10),L_llp.SETTLEMENT_DATE,120)       L_SETTLEMENT_DATE               ,   -- 37  
                            CONVERT(CHAR(10),L_llp.ORIG_ACQ_DATE,120)         L_ORIG_ACQ_DATE                 ,   -- 216  
                            CONVERT(CHAR(10),L_llp.ORIG_OPEN_SETTLE_DATE,120) L_ORIG_OPEN_SETTLE_DATE         ,   -- 154  
                            L_pcl.ACCR_LTD_BASE                               L_ACCR_LTD_BASE                 ,   -- 8682  
                            L_pcl.AMORT_PTD_BASE                              L_AMORT_PTD_BASE                ,   -- 8683  
                            L_pcl.CREDIT_LOSS_B                               L_CREDIT_LOSS_B                 ,   -- 8684  
                            L_pcl.DEFERRED_INCOME_TOTAL_PTD_B                 L_DEFERRED_INCOME_TOTAL_PTD_B   ,   -- 8685  
                            L_pcl.IMPAIRMENT_LTD_BASE                         L_IMPAIRMENT_LTD_BASE           ,   -- 8686  
                            L_pcl.NON_CREDIT_LOSS_B                           L_NON_CREDIT_LOSS_B             ,   -- 8687  
                            L_pcl.OID_PTD_BASE                                L_OID_PTD_BASE                  ,   -- 8688  
                            L_pcl.ORIG_ACCR_PTD_BASE                          L_ORIG_ACCR_PTD_BASE            ,   -- 8689  
                            L_pcl.ORIG_SOLD_INTEREST_BASE                     L_ORIG_SOLD_INTEREST_BASE       ,   -- 8690  
                            L_pcl.ORIG_TRADED_INTEREST_BASE                   L_ORIG_TRADED_INTEREST_BASE     ,   -- 8691  
                            L_pcl.ORIG_ACQ_COST_BASE                          L_ORIG_ACQ_COST_BASE            ,   -- 8692  
                            L_pcl.TIPS_PTD_BASE                               L_TIPS_PTD_BASE                 ,   -- 8693  
                            ex.CURR_WS_DIS_LOSS_B_L                           CURR_WS_DIS_LOSS_B_L            ,   -- 8694  
                            --CONVERT(CHAR(10),ex.PCL_USER_DATE3_L,120)         PCL_USER_DATE3_L               ,   -- 156 open holding period date  
      --CONVERT(CHAR(10),ex.ORIG_ACQ_DATE_l,120)          ORIG_ACQ_DATE_L                 ,  
                            --CONVERT(CHAR(10),ex.TRADE_DATE_l,120)             TRADE_DATE_L                    ,  
                    -- Comments Table  
                            RC.assign_to                                      assign_to                       ,   -- 1887  
                            RC.assign_to_group                                assign_to_group                 ,   -- 1741  
                            RC.assign_from                                    assign_from                     ,   -- 1888  
                            RC.category                                       category                        ,   -- 104  
                            RC.comment_text                                   comment_text                    ,   -- 1104  
                            RC.sub_category                                   sub_category                    ,   -- 5922  
                            RC.open_close_status                              open_close_status               ,   -- 181  
                            RC.category_is_code                               category_is_code                ,   -- 1444  
                            CONVERT(CHAR(10),RC.effective_date,120)           effective_date_rc               ,   -- 220  
                            RC.subcategory_is_code                            subcategory_is_code             ,   -- 9602  
                            ex.approved                                       approved                        ,   -- 54  
                            sm.issue_name                                     issue_name                      ,   -- 961   
                            DATEDIFF(dd,RC.update_date,@current_date)         comm_age                            -- 621  
                        FROM   
                            MSGCENTER.DBO.LOTS_BALANCES_EXCEPTION ex  
                            INNER JOIN POSITION_COST_LOT R_pcl ON ex.LOT_ID_R = R_pcl.position_lot_id  
                            INNER JOIN security.dbo.SECURITY_MASTER sm ON ex.security_alias = sm.security_alias  
                            INNER JOIN RULES.DBO.ENTITY e ON ex.entity_id = e.entity_id                            
                            INNER JOIN LOT_LEVEL_POSITION R_llp ON R_llp.lot_level_position  = R_pcl.position_lot_id    
                            LEFT OUTER JOIN POSITION_COST_LOT L_pcl ON ex.LOT_ID_L = L_pcl.position_lot_id  
                            LEFT OUTER JOIN LOT_LEVEL_POSITION L_llp ON L_llp.lot_level_position = L_pcl.position_lot_id                                            
                            LEFT OUTER JOIN msgcenter.dbo.recon_comments RC ON ex.last_open = RC.instance     
                    WHERE   
                            1=1  
                        AND (@lv_effective_date IS NULL OR ex.effective_date = @lv_effective_date)  
                        AND (@in_pos_entity_id IS NULL OR ex.entity_id = @in_pos_entity_id)  
                        AND (@in_entity_list_id IS NULL OR LTRIM(RTRIM(e.entity_id)) IN (SELECT LTRIM(RTRIM(el.code_value))  
                                                                                            FROM rules.dbo.entity_list el  
                                                                                        WHERE LTRIM(RTRIM(el.entity_id)) = RIGHT(@in_entity_list_id,8)  
                                                                                        )  
                            )  
                UNION     
                    SELECT   
                    -- exception table  
                            ex.INSTANCE                                         INSTANCE                        ,   -- 2769  
                            ex.LOT_ID_L                                         LOT_ID_L                        ,   -- 7251  
                            ex.LOT_ID_R                                         LOT_ID_R    ,   -- 7252  
                            ex.MASTER_TICKET_NUMBER_L                           MASTER_TICKET_NUMBER_L          ,   -- 761  
                            ex.MASTER_TICKET_NUMBER_R                           MASTER_TICKET_NUMBER_R          ,   -- 762  
                            ex.orig_event_id_l                                  orig_event_id_l                 ,      
                            ex.orig_event_id_r                                  orig_event_id_r                 ,    
                            ex.lot_id_flag                                      lot_id_flag                     ,  
                            ex.SRC_INTFC_INST_L                                 SRC_INTFC_INST_L                ,   -- 1168  
                            ex.SRC_INTFC_INST_R                                 SRC_INTFC_INST_R                ,   -- 4507  
                            msgcenter.dbo.get_long_desc(ex.SRC_INTFC_INST_L)    L_long_source_name,   -- 1102  
                            msgcenter.dbo.get_long_desc(ex.SRC_INTFC_INST_R)    R_long_source_name,   -- 1774  
                            ex.SECURITY_ALIAS                                   SECURITY_ALIAS                  ,   -- 10   
                            ex.ENTITY_ID                                        ENTITY_ID                       ,   -- 1163  
                            e.ENTITY_NAME                                       ENTITY_NAME                     ,   -- 1164  
                            e.accounting_basis                                  accounting_basis                ,   -- 309  
                            sm.primary_asset_id                                 primary_asset_id                ,   -- 14   
                            sm.primary_asset_id_type                            primary_asset_id_type           ,   -- 1432   
                            ex.LONG_SHORT_IND                                   LONG_SHORT_IND                  ,   -- 15   
                            SM.currency_code                                    currency_code                   ,   -- 85  
                            e.base_currency                                     base_currency                   ,   -- 86  
                            sm.process_sec_type                                 process_sec_type                ,   -- 3931  
                            sm.security_type                                    security_type                   ,   -- 82  
                    -- Matching parameters  
                            ex.orig_face_OOB                                    orig_face_OOB                   ,   -- 8608  
                            ex.par_or_shares_OOB                                par_or_shares_OOB               ,   -- 8609  
                            ex.book_value_OOB                                   book_value_OOB                  ,   -- 8610  
                            ex.accrued_income_OOB                               accrued_income_OOB              ,   -- 8611  
                            ex.amort_ltd_base_OOB                               amort_ltd_base_OOB              ,   -- 8612  
                            ex.interest_sold_base_OOB                           interest_sold_base_OOB          ,   -- 8613  
                            ex.int_received_OOB                                 int_received_OOB                ,   -- 8614  
                            ex.oid_ltd_income_OOB                               oid_ltd_income_OOB              ,   -- 8615  
                            ex.market_value_income_OOB                          market_value_income_OOB         ,   -- 8616  
                            ex.notional_cost_OOB                                notional_cost_OOB               ,   -- 8617  
                            ex.mkt_value_base_OOB                               mkt_value_base_OOB              ,   -- 8618  
                            ex.notional_market_value_OOB                        notional_market_value_OOB       ,   -- 8619  
                         ex.tip_ltd_income_OOB                               tip_ltd_income_OOB              ,   -- 8620  
                            ex.cls_amort_base_OOB                               cls_amort_base_OOB              ,   -- 8621  
                            ex.cls_oid_income_OOB                               cls_oid_income_OOB              ,   -- 8622  
                            ex.cls_tips_income_OOB                              cls_tips_income_OOB             ,   -- 8623  
                            ex.accr_ltd_base_OOB                                accr_ltd_base_OOB               ,   -- 8624  
                            ex.amort_ptd_base_OOB                               amort_ptd_base_OOB              ,   -- 8625  
                            ex.credit_loss_b_OOB                                credit_loss_b_OOB               ,   -- 8626  
                            ex.DEF_INCM_TOTAL_PTD_B_OOB                         DEF_INCM_TOTAL_PTD_B_OOB        ,   -- 8627  
                            ex.impairment_ltd_base_OOB                          impairment_ltd_base_OOB         ,   -- 8628  
                            ex.non_credit_loss_b_OOB                            non_credit_loss_b_OOB           ,   -- 8629  
                            ex.oid_ptd_base_OOB                                 oid_ptd_base_OOB                ,   -- 8630  
                            ex.orig_accr_ptd_base_OOB                           orig_accr_ptd_base_OOB          ,   -- 8631  
                            ex.ORIG_SOLD_INT_BASE_OOB                           ORIG_SOLD_INT_BASE_OOB          ,   -- 8632  
                            ex.ORIG_TRADED_INT_BASE_OOB                         ORIG_TRADED_INT_BASE_OOB        ,   -- 8633  
                            ex.orig_acq_cost_base_OOB                           orig_acq_cost_base_OOB          ,   -- 8634  
                            ex.tips_ptd_base_OOB                                tips_ptd_base_OOB               ,   -- 8635  
                            ex.curr_ws_dis_loss_b_OOB                           curr_ws_dis_loss_b_OOB          ,   -- 8652  
                            CASE WHEN ex.trade_date_oob IS NULL THEN 'MATCHED' ELSE 'UNMATCHED' END trade_date_oob,  
                    -- Input TOL values  
                            ex.orig_face_TOL                                    orig_face_TOL                   ,   -- 4064  
                            ex.par_or_shares_TOL                                par_or_shares_TOL               ,   -- 4065  
                            ex.book_value_TOL                                   book_value_TOL                  ,   -- 4066  
                            ex.accrued_income_TOL                               accrued_income_TOL              ,   -- 4067  
                            ex.amort_ltd_base_TOL                               amort_ltd_base_TOL              ,   -- 4068  
                            ex.interest_sold_base_TOL                           interest_sold_base_TOL          ,   -- 4069  
                            ex.int_received_TOL                                 int_received_TOL                ,   -- 4070  
                            ex.oid_ltd_income_TOL                               oid_ltd_income_TOL              ,   -- 4071  
                            ex.market_value_income_TOL                          market_value_income_TOL         ,   -- 4072  
                            ex.notional_cost_TOL                                notional_cost_TOL               ,   -- 4073  
                            ex.mkt_value_base_TOL                               mkt_value_base_TOL              ,   -- 4074  
                            ex.notional_market_value_TOL                        notional_market_value_TOL       ,   -- 4075  
                            ex.tip_ltd_income_TOL                               tip_ltd_income_TOL              ,   -- 4076  
                            ex.cls_amort_base_TOL                               cls_amort_base_TOL              ,   -- 4077  
                            ex.cls_oid_income_TOL                               cls_oid_income_TOL              ,   -- 4078  
                            ex.cls_tips_income_TOL                              cls_tips_income_TOL             ,   -- 4079  
                            ex.accr_ltd_base_TOL                                accr_ltd_base_TOL               ,   -- 4080  
                            ex.amort_ptd_base_TOL                               amort_ptd_base_TOL              ,   -- 4081  
                            ex.credit_loss_b_TOL                                credit_loss_b_TOL               ,   -- 4082  
                            ex.DEF_INCM_TOTAL_PTD_B_TOL                         DEF_INCM_TOTAL_PTD_B_TOL        ,   -- 4083  
                            ex.impairment_ltd_base_TOL                          impairment_ltd_base_TOL         ,   -- 4084  
                            ex.non_credit_loss_b_TOL                            non_credit_loss_b_TOL           ,   -- 4085  
                            ex.oid_ptd_base_TOL                                 oid_ptd_base_TOL                ,   -- 4086  
                            ex.orig_accr_ptd_base_TOL                           orig_accr_ptd_base_TOL          ,   -- 4087  
                            ex.ORIG_SOLD_INT_BASE_TOL                           ORIG_SOLD_INT_BASE_TOL          ,   -- 4088  
                            ex.ORIG_TRADED_INT_BASE_TOL                         ORIG_TRADED_INT_BASE_TOL        ,   -- 4089  
                            ex.orig_acq_cost_base_TOL                           orig_acq_cost_base_TOL          ,   -- 4090  
                            ex.tips_ptd_base_TOL                                tips_ptd_base_TOL               ,   -- 4091  
                            ex.curr_ws_dis_loss_b_TOL                           curr_ws_dis_loss_b_TOL          ,   -- 5625  
                    -- End of Matching parameters                                        
                            CONVERT(CHAR(10),ex.EFFECTIVE_DATE,120)             EFFECTIVE_DATE_EX               ,   -- 1109  
                            CONVERT(CHAR(10),ex.UPDATE_DATE,120)                UPDATE_DATE_EX                  ,         -- 1106  
                            ex.UPDATE_SOURCE                                    UPDATE_SOURCE                   ,   -- 944  
                            ex.status                                           status                          ,   -- 5574  
                    -- Details from RIGHT table                                                    
                            R_llp.ORIG_FACE                                     R_ORIG_FACE                     ,   -- 7960   
                            R_llp.PAR_OR_SHARES                                 R_PAR_OR_SHARES                 ,   -- 7961  
                            R_llp.BOOK_VALUE                                    R_BOOK_VALUE                    ,   -- 7962  
                            R_llp.ACCRUED_INCOME                                R_ACCRUED_INCOME                ,   -- 7963  
                            R_llp.AMORTIZATION_LTD_BASE                         R_AMORTIZATION_LTD_BASE         ,   -- 7964  
                            R_llp.INTEREST_SOLD_BASE                            R_INTEREST_SOLD_BASE            ,   -- 7965  
                            R_llp.INT_RECEIVED                                  R_INT_RECEIVED                  ,   -- 7966  
                            R_llp.OID_LTD_INCOME                                R_OID_LTD_INCOME                ,   -- 7967  
                            R_llp.MARKET_VALUE_INCOME                           R_MARKET_VALUE_INCOME           ,   -- 7968  
                            R_llp.NOTIONAL_COST                                 R_NOTIONAL_COST                 ,   -- 7969  
                            R_llp.MARKET_VALUE                                  R_MARKET_VALUE                  ,   -- 7970  
  R_llp.NOTIONAL_MARKET_VALUE                         R_NOTIONAL_MARKET_VALUE         ,   -- 7971  
                            R_llp.TIP_LTD_INCOME                                R_TIP_LTD_INCOME                ,   -- 7972  
                            R_llp.CLS_AMORT_BASE                                R_CLS_AMORT_BASE                ,   -- 7973  
                            R_llp.CLS_OID_INCOME                                R_CLS_OID_INCOME                ,   -- 7974  
                            R_llp.CLS_TIPS_INCOME                               R_CLS_TIPS_INCOME               ,   -- 7975  
                            CONVERT(CHAR(10),R_llp.TRADE_DATE,120)              TRADE_DATE_R_llp                ,   -- 36  
                            CONVERT(CHAR(10),R_llp.SETTLEMENT_DATE,120)         SETTLEMENT_DATE_R_llp           ,   -- 38  
                            CONVERT(CHAR(10),R_llp.ORIG_ACQ_DATE,120)           ORIG_ACQ_DATE_R_llp             ,   -- 217  
                            CONVERT(CHAR(10),R_llp.ORIG_OPEN_SETTLE_DATE,120)   ORIG_OPEN_SETTLE_DATE_R_llp     ,   -- 155    
                            R_pcl.ACCR_LTD_BASE                                 R_ACCR_LTD_BASE                 ,   -- 7976  
                            R_pcl.AMORT_PTD_BASE                                R_AMORT_PTD_BASE                ,   -- 7977  
                            R_pcl.CREDIT_LOSS_B                                 R_CREDIT_LOSS_B                 ,   -- 7978  
                            R_pcl.DEFERRED_INCOME_TOTAL_PTD_B                   R_DEFERRED_INCOME_TOTAL_PTD_B   ,   -- 7979  
                            R_pcl.IMPAIRMENT_LTD_BASE                           R_IMPAIRMENT_LTD_BASE           ,   -- 7980  
                            R_pcl.NON_CREDIT_LOSS_B                             R_NON_CREDIT_LOSS_B             ,   -- 7981  
                            R_pcl.OID_PTD_BASE                                  R_OID_PTD_BASE                  ,   -- 7982  
                            R_pcl.ORIG_ACCR_PTD_BASE                            R_ORIG_ACCR_PTD_BASE            ,   -- 7983  
                            R_pcl.ORIG_SOLD_INTEREST_BASE                       R_ORIG_SOLD_INTEREST_BASE       ,   -- 7984  
                            R_pcl.ORIG_TRADED_INTEREST_BASE                     R_ORIG_TRADED_INTEREST_BASE     ,   -- 7985  
                            R_pcl.ORIG_ACQ_COST_BASE                            R_ORIG_ACQ_COST_BASE            ,   -- 7986  
                            R_pcl.TIPS_PTD_BASE                                 R_TIPS_PTD_BASE                 ,   -- 7987  
                            ex.CURR_WS_DIS_LOSS_B_R                             CURR_WS_DIS_LOSS_B_R            ,  
                            --CONVERT(CHAR(10),ex.PCL_USER_DATE3_R,120)           PCL_USER_DATE3_R                ,   -- 164 open holding period date  
                            --CONVERT(CHAR(10),ex.ORIG_ACQ_DATE_R,120)            ORIG_ACQ_DATE_r                 ,  
                            --CONVERT(CHAR(10),ex.TRADE_DATE_R,120)               TRADE_DATE_r                    ,  
                    -- Details from OUTER LEFT table                                               
                            L_llp.ORIG_FACE                                     L_ORIG_FACE                     ,   -- 8634  
                            L_llp.PAR_OR_SHARES                                 L_PAR_OR_SHARES                 ,   -- 8635  
                            L_llp.BOOK_VALUE                                    L_BOOK_VALUE                    ,   -- 8636  
                            L_llp.ACCRUED_INCOME                                L_ACCRUED_INCOME                ,   -- 8637  
                            L_llp.AMORTIZATION_LTD_BASE                         L_AMORTIZATION_LTD_BASE         ,   -- 8638  
                            L_llp.INTEREST_SOLD_BASE                            L_INTEREST_SOLD_BASE            ,   -- 8639  
                            L_llp.INT_RECEIVED                   L_INT_RECEIVED                  ,   -- 8640  
                            L_llp.OID_LTD_INCOME                                L_OID_LTD_INCOME                ,   -- 8641  
                            L_llp.MARKET_VALUE_INCOME                           L_MARKET_VALUE_INCOME           ,   -- 8642  
                            L_llp.NOTIONAL_COST                                 L_NOTIONAL_COST                 ,   -- 8643  
                            L_llp.MARKET_VALUE                                  L_MARKET_VALUE                  ,   -- 8644  
                            L_llp.NOTIONAL_MARKET_VALUE                         L_NOTIONAL_MARKET_VALUE         ,   -- 8645  
                            L_llp.TIP_LTD_INCOME                                L_TIP_LTD_INCOME                ,   -- 8646  
                            L_llp.CLS_AMORT_BASE                                L_CLS_AMORT_BASE                ,   -- 8647  
                            L_llp.CLS_OID_INCOME                                L_CLS_OID_INCOME                ,   -- 8680  
                            L_llp.CLS_TIPS_INCOME                               L_CLS_TIPS_INCOME               ,   -- 8681  
                            CONVERT(CHAR(10),L_llp.TRADE_DATE,120)              L_TRADE_DATE                    ,   -- 35  
                            CONVERT(CHAR(10),L_llp.SETTLEMENT_DATE,120)         L_SETTLEMENT_DATE               ,   -- 37  
                            CONVERT(CHAR(10),L_llp.ORIG_ACQ_DATE,120)           L_ORIG_ACQ_DATE                 ,   -- 216  
                            CONVERT(CHAR(10),L_llp.ORIG_OPEN_SETTLE_DATE,120)   L_ORIG_OPEN_SETTLE_DATE         ,   -- 154  
                            L_pcl.ACCR_LTD_BASE                                 L_ACCR_LTD_BASE                 ,   -- 8682  
                            L_pcl.AMORT_PTD_BASE                                L_AMORT_PTD_BASE                ,   -- 8683  
                            L_pcl.CREDIT_LOSS_B                                 L_CREDIT_LOSS_B                 ,   -- 8684  
                            L_pcl.DEFERRED_INCOME_TOTAL_PTD_B                   L_DEFERRED_INCOME_TOTAL_PTD_B   ,   -- 8685  
                            L_pcl.IMPAIRMENT_LTD_BASE                           L_IMPAIRMENT_LTD_BASE           ,   -- 8686  
                            L_pcl.NON_CREDIT_LOSS_B                             L_NON_CREDIT_LOSS_B             ,   -- 8687  
                            L_pcl.OID_PTD_BASE                                  L_OID_PTD_BASE                  ,   -- 8688  
                            L_pcl.ORIG_ACCR_PTD_BASE                            L_ORIG_ACCR_PTD_BASE            ,   -- 8689  
                            L_pcl.ORIG_SOLD_INTEREST_BASE                       L_ORIG_SOLD_INTEREST_BASE       ,   -- 8690  
                            L_pcl.ORIG_TRADED_INTEREST_BASE                     L_ORIG_TRADED_INTEREST_BASE     ,   -- 8691  
                            L_pcl.ORIG_ACQ_COST_BASE                            L_ORIG_ACQ_COST_BASE            ,   -- 8692  
                            L_pcl.TIPS_PTD_BASE                                 L_TIPS_PTD_BASE                 ,   -- 8693  
                            ex.CURR_WS_DIS_LOSS_B_L                             CURR_WS_DIS_LOSS_B_L            ,   -- 8694  
                            --CONVERT(CHAR(10),ex.PCL_USER_DATE3_L,120)           PCL_USER_DATE3_L               ,   -- 156 open holding period date  
                           -- CONVERT(CHAR(10),ex.ORIG_ACQ_DATE_l,120)            ORIG_ACQ_DATE_L                 ,  
                            --CONVERT(CHAR(10),ex.TRADE_DATE_l,120)               TRADE_DATE_L                    ,  
                    -- Comments Table  
                            RC.assign_to                                        assign_to                       ,   -- 1887  
                            RC.assign_to_group                                  assign_to_group                 ,   -- 1741  
  RC.assign_from                                      assign_from                     ,   -- 1888  
                            RC.category                                         category                        ,   -- 104  
                            RC.comment_text                                     comment_text                    ,   -- 1104  
                            RC.sub_category                                     sub_category                    ,   -- 5922  
                            RC.open_close_status                                open_close_status               ,   -- 181  
                            RC.category_is_code                                 category_is_code                ,   -- 1444  
                            CONVERT(CHAR(10),RC.effective_date,120)             effective_date_rc               ,   -- 220  
                            RC.subcategory_is_code                              subcategory_is_code             ,   -- 9602  
                            ex.approved                                         approved                        ,   -- 54  
                            sm.issue_name                                       issue_name                      ,   -- 961     
                            DATEDIFF(dd,RC.update_date,@current_date)           comm_age                            -- 621  
                        FROM   
                            MSGCENTER.DBO.LOTS_BALANCES_EXCEPTION ex  
                            INNER JOIN POSITION_COST_LOT L_pcl ON ex.LOT_ID_L = L_pcl.position_lot_id  
                            INNER JOIN security.dbo.SECURITY_MASTER sm ON ex.security_alias = sm.security_alias  
                            INNER JOIN RULES.DBO.ENTITY e ON ex.entity_id = e.entity_id       
                            INNER JOIN LOT_LEVEL_POSITION L_llp ON L_llp.lot_level_position  = L_pcl.position_lot_id    
                            LEFT OUTER JOIN POSITION_COST_LOT R_pcl ON ex.LOT_ID_R = R_pcl.position_lot_id  
                            LEFT OUTER JOIN LOT_LEVEL_POSITION R_llp ON R_llp.lot_level_position = R_pcl.position_lot_id  
                            LEFT OUTER JOIN msgcenter.dbo.recon_comments RC ON ex.last_open = RC.instance       
          
                    WHERE   
                            1=1  
                        AND (@lv_effective_date IS NULL OR ex.effective_date = @lv_effective_date)  
                        AND (@in_pos_entity_id IS NULL OR ex.entity_id = @in_pos_entity_id)       
                        AND (@in_entity_list_id IS NULL OR LTRIM(RTRIM(e.entity_id)) IN (SELECT LTRIM(RTRIM(el.code_value))   
                                                                                            FROM rules.dbo.entity_list el  
                                                                                        WHERE LTRIM(RTRIM(el.entity_id)) = RIGHT(@in_entity_list_id,8)  
                                                                                        )  
                            )  
                    ) T1  
                WHERE 1=1  
                  AND (@in_effective_date_start IS NULL OR CONVERT(DATE,EFFECTIVE_DATE_EX,120) >= CONVERT(DATE,RTRIM(@in_effective_date_start),112))  
                  AND (@in_effective_date_end IS NULL OR CONVERT(DATE,EFFECTIVE_DATE_EX,120) <=  CONVERT(DATE,RTRIM(@in_effective_date_end),112))      
                       
  
            SELECT   
                    LBE.entity_id                           entity_id                       ,   
                    LBE.entity_name                         entity_name                     ,   
                    LBE.security_alias                      security_alias                  ,  
                    LBE.primary_asset_id                    primary_asset_id                ,  
                    LBE.primary_asset_id_type               primary_asset_id_type           ,  
                    LBE.EFFECTIVE_DATE_EX                   EFFECTIVE_DATE_EX               ,  
  LBE.PCL_USER_DATE3_R                    PCL_USER_DATE3_R                ,  
                    LBE.ORIG_ACQ_DATE_r                     ORIG_ACQ_DATE_r                 ,  
                    LBE.TRADE_DATE_r                        TRADE_DATE_r                    ,  
                    LBE.PCL_USER_DATE3_L                    PCL_USER_DATE3_L                ,  
                    LBE.ORIG_ACQ_DATE_L                     ORIG_ACQ_DATE_L                 ,  
                    LBE.TRADE_DATE_L                        TRADE_DATE_L                    ,  
                    LBE.TRADE_DATE_OOB                      TRADE_DATE_OOB                  ,  
                    SUM(LBE.orig_face_OOB)                  orig_face_OOB                   ,  
                    SUM(LBE.R_ORIG_FACE)                    R_ORIG_FACE                     ,  
                    SUM(LBE.L_ORIG_FACE)                    L_ORIG_FACE                     ,  
                    SUM(LBE.par_or_shares_OOB)              par_or_shares_OOB               ,  
                    SUM(LBE.R_PAR_OR_SHARES)                R_PAR_OR_SHARES                 ,  
                    SUM(LBE.L_PAR_OR_SHARES)                L_PAR_OR_SHARES                 ,  
                    SUM(LBE.book_value_OOB)                 book_value_OOB                  ,  
                    SUM(LBE.R_BOOK_VALUE)                   R_BOOK_VALUE                    ,  
                    SUM(LBE.L_BOOK_VALUE)                   L_BOOK_VALUE                    ,  
                    SUM(LBE.accrued_income_OOB)             accrued_income_OOB              ,  
                    SUM(LBE.R_ACCRUED_INCOME)               R_ACCRUED_INCOME                ,  
                    SUM(LBE.L_ACCRUED_INCOME)               L_ACCRUED_INCOME                ,  
                    SUM(LBE.amort_ltd_base_OOB)             amort_ltd_base_OOB              ,  
                    SUM(LBE.R_AMORTIZATION_LTD_BASE)        R_AMORTIZATION_LTD_BASE         ,  
                    SUM(LBE.L_AMORTIZATION_LTD_BASE)        L_AMORTIZATION_LTD_BASE         ,  
                    SUM(LBE.interest_sold_base_OOB)         interest_sold_base_OOB          ,  
                    SUM(LBE.R_INTEREST_SOLD_BASE)           R_INTEREST_SOLD_BASE            ,  
                    SUM(LBE.L_INTEREST_SOLD_BASE)           L_INTEREST_SOLD_BASE            ,  
                    SUM(LBE.int_received_OOB)               int_received_OOB                ,  
                    SUM(LBE.R_INT_RECEIVED)                 R_INT_RECEIVED                  ,  
                    SUM(LBE.L_INT_RECEIVED)                 L_INT_RECEIVED                  ,  
                    SUM(LBE.oid_ltd_income_OOB)             oid_ltd_income_OOB              ,  
                    SUM(LBE.R_OID_LTD_INCOME)               R_OID_LTD_INCOME                ,  
                    SUM(LBE.L_OID_LTD_INCOME)               L_OID_LTD_INCOME                ,  
                    SUM(LBE.market_value_income_OOB)        market_value_income_OOB         ,  
                    SUM(LBE.R_MARKET_VALUE_INCOME)          R_MARKET_VALUE_INCOME           ,  
                    SUM(LBE.L_MARKET_VALUE_INCOME)          L_MARKET_VALUE_INCOME           ,  
                    SUM(LBE.notional_cost_OOB)              notional_cost_OOB               ,  
                    SUM(LBE.R_NOTIONAL_COST)                R_NOTIONAL_COST                 ,  
                    SUM(LBE.L_NOTIONAL_COST)                L_NOTIONAL_COST                 ,  
                    SUM(LBE.mkt_value_base_OOB)             mkt_value_base_OOB              ,  
                    SUM(LBE.R_MARKET_VALUE)                 R_MARKET_VALUE                  ,  
                    SUM(LBE.L_MARKET_VALUE)                 L_MARKET_VALUE                  ,  
                    SUM(LBE.notional_market_value_OOB)      notional_market_value_OOB       ,  
                    SUM(LBE.R_NOTIONAL_MARKET_VALUE)        R_NOTIONAL_MARKET_VALUE         ,  
                    SUM(LBE.L_NOTIONAL_MARKET_VALUE)        L_NOTIONAL_MARKET_VALUE         ,  
                    SUM(LBE.tip_ltd_income_OOB)             tip_ltd_income_OOB              ,  
                    SUM(LBE.R_TIP_LTD_INCOME)               R_TIP_LTD_INCOME                ,  
                    SUM(LBE.L_TIP_LTD_INCOME)               L_TIP_LTD_INCOME                ,  
                    SUM(LBE.cls_amort_base_OOB)             cls_amort_base_OOB              ,  
                    SUM(LBE.R_CLS_AMORT_BASE)               R_CLS_AMORT_BASE                ,  
                    SUM(LBE.L_CLS_AMORT_BASE)               L_CLS_AMORT_BASE                ,  
                    SUM(LBE.cls_oid_income_OOB)             cls_oid_income_OOB              ,  
                    SUM(LBE.R_CLS_OID_INCOME)               R_CLS_OID_INCOME                ,  
                    SUM(LBE.L_CLS_OID_INCOME)               L_CLS_OID_INCOME                ,  
                    SUM(LBE.cls_tips_income_OOB)            cls_tips_income_OOB             ,  
                    SUM(LBE.R_CLS_TIPS_INCOME)              R_CLS_TIPS_INCOME               ,  
                    SUM(LBE.L_CLS_TIPS_INCOME)              L_CLS_TIPS_INCOME               ,  
                    SUM(LBE.accr_ltd_base_OOB)              accr_ltd_base_OOB               ,  
                    SUM(LBE.R_ACCR_LTD_BASE)                R_ACCR_LTD_BASE                 ,  
                    SUM(LBE.L_ACCR_LTD_BASE)                L_ACCR_LTD_BASE                 ,  
                    SUM(LBE.amort_ptd_base_OOB)             amort_ptd_base_OOB              ,  
                    SUM(LBE.R_AMORT_PTD_BASE)               R_AMORT_PTD_BASE                ,  
                    SUM(LBE.L_AMORT_PTD_BASE)               L_AMORT_PTD_BASE                ,  
                    SUM(LBE.credit_loss_b_OOB)              credit_loss_b_OOB               ,  
                    SUM(LBE.R_CREDIT_LOSS_B)                R_CREDIT_LOSS_B                 ,  
                    SUM(LBE.L_CREDIT_LOSS_B)                L_CREDIT_LOSS_B                 ,  
                    SUM(LBE.DEF_INCM_TOTAL_PTD_B_OOB)       DEF_INCM_TOTAL_PTD_B_OOB        ,  
                    SUM(LBE.R_DEFERRED_INCOME_TOTAL_PTD_B)  R_DEFERRED_INCOME_TOTAL_PTD_B   ,  
                    SUM(LBE.L_DEFERRED_INCOME_TOTAL_PTD_B)  L_DEFERRED_INCOME_TOTAL_PTD_B   ,  
                    SUM(LBE.impairment_ltd_base_OOB)        impairment_ltd_base_OOB         ,  
                    SUM(LBE.R_IMPAIRMENT_LTD_BASE)          R_IMPAIRMENT_LTD_BASE           ,  
                    SUM(LBE.L_IMPAIRMENT_LTD_BASE)          L_IMPAIRMENT_LTD_BASE           ,  
                    SUM(LBE.non_credit_loss_b_OOB)          non_credit_loss_b_OOB           ,  
                    SUM(LBE.R_NON_CREDIT_LOSS_B)            R_NON_CREDIT_LOSS_B             ,  
                    SUM(LBE.L_NON_CREDIT_LOSS_B)            L_NON_CREDIT_LOSS_B             ,  
                    SUM(LBE.oid_ptd_base_OOB)               oid_ptd_base_OOB                ,  
                    SUM(LBE.R_OID_PTD_BASE)                 R_OID_PTD_BASE                  ,  
                    SUM(LBE.L_OID_PTD_BASE)                 L_OID_PTD_BASE                  ,  
                    SUM(LBE.orig_accr_ptd_base_OOB)         orig_accr_ptd_base_OOB          ,  
                    SUM(LBE.R_ORIG_ACCR_PTD_BASE)           R_ORIG_ACCR_PTD_BASE            ,  
                    SUM(LBE.L_ORIG_ACCR_PTD_BASE)           L_ORIG_ACCR_PTD_BASE            ,  
                    SUM(LBE.ORIG_SOLD_INT_BASE_OOB)         ORIG_SOLD_INT_BASE_OOB          ,  
                    SUM(LBE.R_ORIG_SOLD_INTEREST_BASE)      R_ORIG_SOLD_INTEREST_BASE       ,  
                    SUM(LBE.L_ORIG_SOLD_INTEREST_BASE)      L_ORIG_SOLD_INTEREST_BASE       ,  
                    SUM(LBE.ORIG_TRADED_INT_BASE_OOB)       ORIG_TRADED_INT_BASE_OOB        ,  
                    SUM(LBE.R_ORIG_TRADED_INTEREST_BASE)    R_ORIG_TRADED_INTEREST_BASE     ,  
                    SUM(LBE.L_ORIG_TRADED_INTEREST_BASE)    L_ORIG_TRADED_INTEREST_BASE     ,  
                    SUM(LBE.orig_acq_cost_base_OOB)         orig_acq_cost_base_OOB          ,  
                    SUM(LBE.R_ORIG_ACQ_COST_BASE)           R_ORIG_ACQ_COST_BASE            ,  
                    SUM(LBE.L_ORIG_ACQ_COST_BASE)           L_ORIG_ACQ_COST_BASE            ,  
                    SUM(LBE.tips_ptd_base_OOB)              tips_ptd_base_OOB               ,  
                    SUM(LBE.R_TIPS_PTD_BASE)                R_TIPS_PTD_BASE                 ,  
                    SUM(LBE.L_TIPS_PTD_BASE)                L_TIPS_PTD_BASE                 ,  
                    SUM(LBE.curr_ws_dis_loss_b_OOB)         curr_ws_dis_loss_b_OOB          ,  
                    SUM(LBE.CURR_WS_DIS_LOSS_B_R)           CURR_WS_DIS_LOSS_B_R            ,  
                    SUM(LBE.CURR_WS_DIS_LOSS_B_L)           CURR_WS_DIS_LOSS_B_L            ,  
                    NULL BOOK_COST_B_OOB                                                    ,  
                    NULL R_BOOK_COST_B                                                      ,  
                    NULL L_BOOK_COST_B                                                      ,  
                    NULL BOOK_COST_L_OOB                                                    ,  
                    NULL R_BOOK_COST_L                                                      ,  
                    NULL L_BOOK_COST_L                                                      ,  
                    SUM(CASE WHEN LBE.status = 0 THEN 1 ELSE 0 END) status0 ,  
                    SUM(CASE WHEN LBE.status = 1 THEN 1 ELSE 0 END) status1 ,  
                    SUM(CASE WHEN LBE.status = 2 THEN 1 ELSE 0 END) status2 ,  
                    SUM(CASE WHEN LBE.status = 4 THEN 1 ELSE 0 END) status4  
            FROM #LotsBE LBE  
            WHERE 1=1  
             AND (@in_security_alias IS NULL OR LBE.security_alias = @in_security_alias)  
 /* FILTER BY ENTITY FROM USER BUSINESS GROUPS */  
    AND ( @lv_is_superuser = 1 OR (  
     @in_pos_entity_id IS NOT NULL OR LBE.entity_id IN (  
               SELECT DISTINCT ge.entity_id  
                  FROM pace_master.dbo.group_entities ge  
                  WHERE ge.group_id = @lv_user_business_group_id  
                )))  
         GROUP BY LBE.entity_id,   
                  LBE.entity_name,   
                  LBE.security_alias,   
                  LBE.primary_asset_id,   
                  LBE.primary_asset_id_type,   
                  LBE.EFFECTIVE_DATE_EX,  
                  LBE.PCL_USER_DATE3_R,  
                  LBE.ORIG_ACQ_DATE_r ,  
                  LBE.TRADE_DATE_r    ,  
                  LBE.PCL_USER_DATE3_L,  
                  LBE.ORIG_ACQ_DATE_L ,  
                  LBE.TRADE_DATE_L ,  
                  LBE.TRADE_DATE_OOB  
            ;  
              
            DROP TABLE #LotsBE;   
   DROP TABLE #TEMP_COMP_GROUP_RESOLVE;  
  
END  