ALTER PACKAGE msgcenter_dbo.recon_common COMPILE;
ALTER PACKAGE msgcenter_dbo.recon_common COMPILE PACKAGE;
ALTER PACKAGE msgcenter_dbo.recon_common COMPILE BODY;