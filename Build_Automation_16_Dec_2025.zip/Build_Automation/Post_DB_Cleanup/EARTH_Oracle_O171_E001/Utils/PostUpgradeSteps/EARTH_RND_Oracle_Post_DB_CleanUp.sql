truncate table msgcenter_dbo.msg_detail;
truncate table msgcenter_dbo.msg_detail_status;
truncate table msgcenter_dbo.msg_record_resultmessage;
truncate table msgcenter_dbo.msg_record_status;
truncate table msgcenter_dbo.msg_records;
truncate table msgcenter_dbo.msg_rejections;
truncate table msgcenter_dbo.msg_ext_response;
truncate table estar.SPD_DELTA_TRIGGER_LOG;
truncate table estar.SPD_DELTA_TRIGGER_LOG_HIST;
truncate table msgcenter_dbo.schedule_event_summary;
truncate table msgcenter_dbo.schedule_run;
truncate table estar.estar_loopback_events;
truncate table estar01.estar_loopback_events; 
truncate table estar.ESTAR_INTERNAL_RECON_TEMP;
truncate table estar01.ESTAR_INTERNAL_RECON_TEMP; 
truncate table estar.ESTAR_TEMP_INTINC_DATE_RANGE;
truncate table estar01.ESTAR_TEMP_INTINC_DATE_RANGE; 
truncate table pace_masterdbo.schedule_queue;
truncate table pace_masterdbo.schedule_def_details;
truncate table pace_masterdbo.schedule_def_messages;
truncate table pace_masterdbo.egl_sched_queue;
truncate table pace_masterdbo.egl_sched_queue_detail;
truncate table pace_masterdbo.egl_sched_def_details;
truncate table pace_masterdbo.egl_sched_def_msgs;
truncate table pace_masterdbo.workflow_status;
truncate table pace_masterdbo.workflow_status_details; 
truncate table pace_masterdbo.generic_regression_results;
delete pace_masterdbo.egl_sched_process_def where purge_flag = 1;
Commit;
delete pace_masterdbo.egl_sched_def where not spd_instance in (select instance from pace_masterdbo.egl_sched_process_def); 
Commit;
delete pace_masterdbo.schedule_def where custom_proc_name like '%[EVENT%';
commit;
delete pace_masterdbo.schedule_def where custom_proc_name like '%Adhoc - MSG CNTR Move File Exporter%';
commit;
delete pace_masterdbo.schedule_def where custom_proc_name like '%CANCELTHREAD%';
commit;

delete pace_masterdbo.egl_sched_def_params where parameter_type = 4;
commit;

truncate table msgcenter_dbo.msg_detail;                  
truncate table msgcenter_dbo.msg_detail_status;            
truncate table msgcenter_dbo.msg_records;                  
truncate table msgcenter_dbo.msg_record_resultmessage;    
truncate table msgcenter_dbo.msg_record_status;            
truncate table msgcenter_dbo.msg_rejections;              
truncate table msgcenter_dbo.schedule_event_summary;      
truncate table msgcenter_dbo.schedule_run;                
truncate table msgcenter_dbo.msg_record_resultmessage;  
truncate table msgcenter_dbo.tasks;  
truncate table msgcenter_dbo.tasks_hist;
truncate table msgcenter_dbo.msg_message_stat;
truncate table pace_masterdbo.orch_queue;
truncate table pace_masterdbo.orch_request_def;
truncate table pace_masterdbo.orch_request_params;
truncate table pace_masterdbo.egl_sched_def_hist;
truncate table pace_masterdbo.egl_sched_process_def_hist;
truncate table pace_masterdbo.egl_sched_queue_hist;
truncate table pace_masterdbo.egl_sched_def_msgs_hist;

update estar.bind_detail a
   set a.param_name = 'IN_MESSAGE',
       A.PARAM_DATA_TYPE = 5,
       a.param_type_len = 100,
       a.param_tag = 1618
 where a.bind_instance = 10002139245
   and a.param_order = 1;
   
commit;

ALTER PACKAGE holdingdbo.spd_holding COMPILE PACKAGE;
ALTER PACKAGE holdingdbo.spd_holding COMPILE BODY;

ALTER PACKAGE holdingdbo01.spd_holding COMPILE PACKAGE;
ALTER PACKAGE holdingdbo01.spd_holding COMPILE BODY;

ALTER PACKAGE pace_masterdbo.rdc_pricing COMPILE PACKAGE;
ALTER PACKAGE pace_masterdbo.rdc_pricing COMPILE BODY;