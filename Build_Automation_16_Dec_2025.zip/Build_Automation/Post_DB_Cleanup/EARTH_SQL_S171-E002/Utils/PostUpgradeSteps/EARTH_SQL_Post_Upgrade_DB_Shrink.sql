Use ESTAR
Go

declare @L_inst int
select @L_inst = isnull(MAX(instance),0) from estar..SEQ_PORT_SYNC
if (@L_inst > 0)
begin
	truncate table estar..SEQ_PORT_SYNC
	SET IDENTITY_INSERT estar..SEQ_PORT_SYNC ON
	INSERT INTO estar..SEQ_PORT_SYNC (instance) Values(@L_inst)
	SET IDENTITY_INSERT estar..SEQ_PORT_SYNC OFF
end
go

declare @L_inst int
select @L_inst = isnull(MAX(instance),0) from estar..SEQ_LEDGER_ACCT_ID
if (@L_inst > 0)
begin
	truncate table estar..SEQ_LEDGER_ACCT_ID
	SET IDENTITY_INSERT estar..SEQ_LEDGER_ACCT_ID ON
	INSERT INTO estar..SEQ_LEDGER_ACCT_ID (instance) Values(@L_inst)
	SET IDENTITY_INSERT estar..SEQ_LEDGER_ACCT_ID OFF
end
go

declare @L_inst int
select @L_inst = isnull(MAX(instance),0) from estar..SEQ_LEDGER_LOG_ID
if (@L_inst > 0)
begin
	truncate table estar..SEQ_LEDGER_LOG_ID
	SET IDENTITY_INSERT estar..SEQ_LEDGER_LOG_ID ON
	INSERT INTO estar..SEQ_LEDGER_LOG_ID (instance) Values(@L_inst)
	SET IDENTITY_INSERT estar..SEQ_LEDGER_LOG_ID OFF
end
go

declare @L_inst int
select @L_inst = isnull(MAX(instance),0) from estar..SEQ_LEDGER_POST_ID
if (@L_inst > 0)
begin
	truncate table estar..SEQ_LEDGER_POST_ID
	SET IDENTITY_INSERT estar..SEQ_LEDGER_POST_ID ON
	INSERT INTO estar..SEQ_LEDGER_POST_ID (instance) Values(@L_inst)
	SET IDENTITY_INSERT estar..SEQ_LEDGER_POST_ID OFF
end
go

declare @L_inst int
select @L_inst = isnull(MAX(instance),0) from estar.dbo.SEQ_CASH_ACT
if (@L_inst > 0)
begin
	truncate table estar.dbo.SEQ_CASH_ACT
	SET IDENTITY_INSERT estar.dbo.SEQ_CASH_ACT ON
	INSERT INTO estar.dbo.SEQ_CASH_ACT (instance) Values(@L_inst)
	SET IDENTITY_INSERT estar.dbo.SEQ_CASH_ACT OFF
end
go

declare @L_inst int
select @L_inst = isnull(MAX(instance),0) from estar..SEQ_TEER_REJN_ID
if (@L_inst > 0)
begin
	truncate table estar..SEQ_TEER_REJN_ID
	SET IDENTITY_INSERT estar..SEQ_TEER_REJN_ID ON
	INSERT INTO estar..SEQ_TEER_REJN_ID (instance) Values(@L_inst)
	SET IDENTITY_INSERT estar..SEQ_TEER_REJN_ID OFF
end
go

declare @L_inst int
select @L_inst = isnull(MAX(instance),0) from estar..SEQ_INCOME_LOG
if (@L_inst > 0)
begin
	truncate table estar..SEQ_INCOME_LOG
	SET IDENTITY_INSERT estar..SEQ_INCOME_LOG ON
	INSERT INTO estar..SEQ_INCOME_LOG (instance) Values(@L_inst)
	SET IDENTITY_INSERT estar..SEQ_INCOME_LOG OFF
end
go

declare @L_inst int
select @L_inst = isnull(MAX(instance),0) from estar..SEQ_TEPO_POSN_ID
if (@L_inst > 0)
begin
	truncate table estar..SEQ_TEPO_POSN_ID
	SET IDENTITY_INSERT estar..SEQ_TEPO_POSN_ID ON
	INSERT INTO estar..SEQ_TEPO_POSN_ID (instance) Values(@L_inst)
	SET IDENTITY_INSERT estar..SEQ_TEPO_POSN_ID OFF
end
go
declare @L_inst int
select @L_inst = isnull(MAX(instance),0) from estar.dbo.SEQ_CASH_FIN_EVT
if (@L_inst > 0)
begin
	truncate table estar.dbo.SEQ_CASH_FIN_EVT
	SET IDENTITY_INSERT estar.dbo.SEQ_CASH_FIN_EVT ON
	INSERT INTO estar.dbo.SEQ_CASH_FIN_EVT (instance) Values(@L_inst)
	SET IDENTITY_INSERT estar.dbo.SEQ_CASH_FIN_EVT OFF
end