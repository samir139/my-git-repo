USE [PACE_MASTER]
GO
/****** Object:  StoredProcedure [dbo].[MSG_CTR_QUEUE_INSERT]    Script Date: 05/23/2013 15:52:08 ******/
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[MSG_CTR_QUEUE_INSERT] 
(
@l_file_name            VARCHAR(100),   --1618
@l_feed_type		VARCHAR(8)      --1167
) 
AS                                              

DECLARE @l_sched_def_inst integer,
	@l_sched_queue_inst integer,
	@l_event_inst integer,
	@l_feed char(3)

DECLARE @l_version integer
	
BEGIN

	Select @l_version = convert(integer, sys_value) 
	From pace_master.dbo.pace_system Where  sys_item = 147

	SET @l_sched_def_inst = 99999

    	select @l_event_inst = ev.instance 
    	from pace_master.dbo.events ev
    	where ev.process_desc = 'UPLOADER';

    	SET @l_feed = substring(@l_feed_type,1,3);

    	If @l_event_inst is NOT NULL
        Begin

		If @l_version = 0 
		Begin
            	    exec pace_master.dbo.GET_NEXT_INSTANCE 'PACE_MASTER.DBO.SCHEDULE_QUEUE', 1, @l_sched_queue_inst OUTPUT
	            insert into pace_master.dbo.schedule_queue
        	    (instance,
            		pinstance,
            		status,
            		sched_dt_time,
            		run_dt_time,
            		user_data,
            		actual_start_dt_time,
            		actual_stop_dt_time,
            		log_file_name,
            		parent_qinstance,
            		parent_flag
            	    )
            	   values
            		(@l_sched_queue_inst,
            		@l_sched_def_inst,
            		'D',
            		getdate(),
            		getdate(),
            		@l_file_name,
            		getdate(),
            		getdate(),
            		NULL,
            		0,
            		0
            		)
		End
		Else
		Begin
            	    exec pace_master.dbo.GET_NEXT_INSTANCE 'PACE_MASTER.DBO.EGL_SCHED_QUEUE', 1, @l_sched_queue_inst OUTPUT
	            insert into pace_master.dbo.egl_sched_queue
        	    (instance,
            		sd_instance,
            		status,
			effective_date,
            		actual_start_time,
            		actual_stop_time,
            		user_data,
			parent_sq_instance,
	    		update_source
            	    )
            	   values
            		(@l_sched_queue_inst,
            		@l_sched_def_inst,
            		2,
			getdate(),
            		getdate(),
            		getdate(),
    			@l_file_name,
            		0,
            		'EAGLEADMIN'
            		)
		End
        End
END
