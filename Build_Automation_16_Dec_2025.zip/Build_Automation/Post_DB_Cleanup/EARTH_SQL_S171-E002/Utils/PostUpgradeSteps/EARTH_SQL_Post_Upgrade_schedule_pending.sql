USE [MSGCENTER]
GO
/****** Object:  StoredProcedure [dbo].[schedule_pending_reports_ui]    Script Date: 7/23/2014 12:32:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO

ALTER PROC [dbo].[schedule_pending_reports_ui]
    @schedule_name   varchar(50),
    @start_time      varchar(8000) = NULL,
    @app_id          int = 0,
    @run_by          varchar(255) = NULL,
    @user_grp        varchar(255) = NULL,
    @switch          char(20) = NULL,
    @run_tags        text = NULL
AS
  DECLARE @l_version            INT,
    @my_process_instance		int,
    @my_error_message			varchar(1024),
    @my_process_name			varchar(1000),
    @my_user_data				varchar(255),
    
    @schedule_id				int,
    @srvr_id					int,
    @pos						int,
    @start_pos					int,
    @s_time						varchar(20),
    @pending_id					int,
    @my_pending_id_str        VARCHAR(38),
	@my_pending_id			INT,
	
	@my_status            INT = 0
  
  
BEGIN
    SET @l_version  = ISNULL(CAST(PACE_MASTER.DBO.GET_PACE_SYS_VALUE(147) AS INT), 0)

    --IF @l_version >= 2 BEGIN
    --    raiserror('The environment is configured for Integrated Scheduler mode. This panel may not be used to submit schedules. Schedules must be submitted through Process Center in Eagle NxG.', 11, 1)
    --    GOTO SP_END
    --END
    
    IF @l_version >= 2 BEGIN
    --    raiserror('The environment is configured for Integrated Scheduler mode. This panel may not be used to submit schedules. Schedules must be submitted through Process Center in Eagle NxG.', 11, 1)
    --    GOTO SP_END
    Select @my_status = 6
    END

    IF @switch = 'GRP'
       SELECT @schedule_id=schedule_id, @user_grp=user_grp,
              @run_by=modified_by, @app_id=app_id, @srvr_id=svr_id
         FROM schedule
         WHERE (name = @schedule_name)
           AND (status = 0)
           AND (isnull(@app_id, 0) = 0 OR app_id = @app_id)
           AND (@user_grp IS NOT NULL AND UPPER(user_grp) = UPPER(@user_grp))
    ELSE IF @switch = 'USR'
       SELECT @schedule_id=schedule_id, @user_grp=user_grp,
              @run_by=modified_by, @app_id=app_id, @srvr_id=svr_id
         FROM schedule
         WHERE (name = @schedule_name)
           AND (status = 0)
           AND (isnull(@app_id, 0) = 0 OR app_id = @app_id)
           AND (@run_by IS NOT NULL AND UPPER(modified_by) = UPPER(@run_by))
           AND (@user_grp IS NOT NULL AND UPPER(user_grp) = UPPER(@user_grp))
    ELSE
       SELECT @schedule_id=schedule_id, @user_grp=user_grp,
              @run_by=modified_by, @app_id=app_id, @srvr_id=svr_id
         FROM schedule
         WHERE (name = @schedule_name)
           AND (status = 0)
           AND (isnull(@app_id, 0) = 0 OR app_id = @app_id)

    IF @@ROWCOUNT = 0
    BEGIN
        RAISERROR('The schedule "%s" is not present in the database.', 16, 1, @schedule_name)
        RETURN
    END

    IF @@ROWCOUNT > 1
    BEGIN
        RAISERROR('Not one schedule "%s" is present in the database.', 16, 1, @schedule_name)
        RETURN
    END

    IF @start_time IS NULL
    BEGIN
        -- insert "Run Now" pending event, time = curr - 1 day for start on next refresh
        INSERT INTO schedule_pending_reports
                (schedule_id, app_id, srvr_id,
                 start_time, end_time, status, type,
                 run_tags, run_by, user_grp )
            VALUES
                (@schedule_id, @app_id, @srvr_id,
                 dateadd(d, -1, getdate()), NULL, @my_status, 'R',
                 @run_tags, @run_by, @user_grp )
			SET @my_pending_id = SCOPE_IDENTITY()
            SET @my_pending_id_str = CONVERT(VARCHAR(MAX), @my_pending_id)                 
        --RETURN
    END
	ELSE
	BEGIN
    IF (SUBSTRING(@start_time, LEN(@start_time), 1) <> '|')
        SELECT @start_time = @start_time + '|'

    SELECT @pos = 0, @start_pos = 1

    SELECT @pos = CHARINDEX('|', @start_time, @start_pos)
    WHILE (@pos > 0)
    BEGIN
        SELECT @s_time = SUBSTRING(@start_time, @start_pos, @pos-@start_pos)

        SELECT @pending_id=pending_id
          FROM schedule_pending_reports
         WHERE schedule_id=@schedule_id
           AND app_id=@app_id
           AND srvr_id=@srvr_id
           AND start_time=convert(datetime, @s_time)

        IF @@ROWCOUNT = 0
        BEGIN
            INSERT INTO schedule_pending_reports
                    (schedule_id, app_id, srvr_id,
                     start_time, end_time, status, type,
                     run_tags, run_by, user_grp )
                VALUES
                    (@schedule_id, @app_id, @srvr_id,
                     convert(datetime, @s_time), NULL, 0, 'R',
                     @run_tags, @run_by, @user_grp )
			SET @my_pending_id = SCOPE_IDENTITY()
            SET @my_pending_id_str = CONVERT(VARCHAR(MAX), @my_pending_id)                     
        END

        SELECT @start_pos = @pos + 1
        SELECT @pos = CHARINDEX('|', @start_time, @start_pos)
    END    
    END
   IF (@l_version >= 2) 
   BEGIN
       --SET @my_user_data = 'PENDING_ID!' + @pending_id
       SET @my_user_data = 'PENDING_ID!' + @my_pending_id_str
       SET @my_process_name = @schedule_name + ' [ADHOC]'
       SET @run_by = ISNULL(@run_by,'SCHEDULE_PENDING_REPORTS_UI')
       -- Execute PACE proc
       EXEC PACE_MASTER.DBO.EGLSCHED_SUBMIT_ADHOC @my_process_name, 'STAR_EVENT',0,@run_by, @my_user_data, @my_process_instance OUTPUT, @my_error_message OUTPUT, 0
   END  

SP_END:
END