declare
sqlStmt VARCHAR2(1000);
BEGIN
For x in (SELECT SID,SERIAL# FROM V$SESSION WHERE STATUS in ('INACTIVE')) loop
sqlStmt := 'ALTER SYSTEM KILL SESSION ''' ||X.SId ||',' ||X.Serial# ||'''' ;
dbms_output.put_line( sqlStmt );
EXECUTE IMMEDIATE sqlStmt;
End loop;
end;
/
commit;
/

exit;