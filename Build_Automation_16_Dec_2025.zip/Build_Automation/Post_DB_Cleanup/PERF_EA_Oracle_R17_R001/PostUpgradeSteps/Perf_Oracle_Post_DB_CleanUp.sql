delete pace_masterdbo.egl_sched_def where freq_type in (1,2) and enable = 1 ;
delete pace_masterdbo.egl_sched_def where freq_type in (1,2);
truncate table pace_masterdbo.egl_sched_queue;
truncate table pace_masterdbo.egl_sched_queue_detail;
truncate table pace_masterdbo.egl_sched_def_details ;
truncate table pace_masterdbo.egl_sched_def_msgs;
delete pace_masterdbo.workflow_status;
delete pace_masterdbo.workflow_status_details;
delete pace_masterdbo.egl_sched_def where spd_instance not in (select instance from pace_masterdbo.egl_sched_process_def);
delete pace_masterdbo.egl_sched_process_def where purge_flag = 1;
truncate table pace_masterdbo.event_packages;
truncate table pace_masterdbo.feed_results ;
truncate table pace_masterdbo.feed_errors ;
truncate table pace_masterdbo.feed_error_details ;
delete from performdbo.entity_commit_check;
delete pace_masterdbo.rpt_profile_override v where v.sched_def_inst > 0;
COMMIT;

delete pace_masterdbo.egl_sched_def_params where parameter_type = 4;
commit;

update custom_archive_rules
   set root_dir = '\\r17-r001-wr01\unixworking\newset\linux_data', 
       custom_dir = 'Deposit'
 where description = 'REGR'
   and instance = 1011;
commit;