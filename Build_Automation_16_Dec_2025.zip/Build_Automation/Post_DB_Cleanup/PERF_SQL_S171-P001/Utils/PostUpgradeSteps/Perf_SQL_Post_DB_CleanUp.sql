use pace_master
go

delete pace_master.dbo.schedule_def
 where freq_type in ('N','S')
 and enable = 'Y'
delete pace_master.dbo.schedule_def where freq_type in ('N','S')
delete pace_master.dbo.event_packages
delete pace_master.dbo.schedule_queue
delete pace_master.dbo.schedule_def_details
delete pace_master.dbo.schedule_def_messages
delete pace_master.dbo.feed_results
delete pace_master.dbo.feed_errors
delete pace_master.dbo.feed_error_details
delete from perform.dbo.entity_commit_check
UPDATE PACE_MASTER.dbo.DM_MODEL_MGR_RESULTS
 SET MGR_STATUS = 'C'
 WHERE (MGR_STATUS = 'B' 
  OR MGR_STATUS = 'S'
  OR MGR_STATUS = 'SS'
  OR MGR_STATUS IS NULL)

delete pace_master.dbo.egl_sched_def 
where freq_type in (1,2) 
and enable = 1 
delete pace_master.dbo.egl_sched_def where freq_type in (1,2)
truncate table pace_master.dbo.egl_sched_queue
truncate table pace_master.dbo.egl_sched_queue_detail
truncate table pace_master.dbo.egl_sched_def_details 
truncate table pace_master.dbo.egl_sched_def_msgs
delete pace_master.dbo.workflow_status
delete pace_master.dbo.workflow_status_details
delete pace_master.dbo.egl_sched_def where spd_instance not in (select instance from pace_master.dbo.egl_sched_process_def)
delete pace_master.dbo.egl_sched_process_def where purge_flag = 1
truncate table pace_master.dbo.event_packages
truncate table pace_master.dbo.feed_results 
truncate table pace_master.dbo.feed_errors 
truncate table pace_master.dbo.feed_error_details 
delete from perform.dbo.entity_commit_check
delete pace_master.dbo.rpt_profile_override where sched_def_inst > 0
UPDATE PACE_MASTER.dbo.DM_MODEL_MGR_RESULTS
SET MGR_STATUS = 'C'
WHERE (MGR_STATUS = 'B' 
OR MGR_STATUS = 'S'
OR MGR_STATUS = 'SS'
OR MGR_STATUS IS NULL)

