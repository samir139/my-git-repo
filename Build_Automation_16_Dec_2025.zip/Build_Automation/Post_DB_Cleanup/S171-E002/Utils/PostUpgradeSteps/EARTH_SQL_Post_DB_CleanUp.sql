USE [PACE_MASTER]
GO

truncate table msgcenter.dbo.msg_detail
truncate table msgcenter.dbo.msg_detail_status
truncate table msgcenter.dbo.msg_record_resultmessage
truncate table msgcenter.dbo.msg_record_status
truncate table msgcenter.dbo.msg_records
truncate table msgcenter.dbo.msg_rejections
truncate table msgcenter.dbo.msg_ext_response
truncate table estar.dbo.SPD_DELTA_TRIGGER_LOG
truncate table estar.dbo.SPD_DELTA_TRIGGER_LOG_HIST
truncate table msgcenter.dbo.schedule_event_summary
truncate table msgcenter.dbo.schedule_run
truncate table estar.dbo.estar_loopback_events
truncate table estar.dbo.ESTAR_INTERNAL_RECON_TEMP
truncate table estar.dbo.ESTAR_TEMP_INTINC_DATE_RANGE
truncate table pace_master.dbo.SCHEDULE_DEF_DETAILS
truncate table pace_master.dbo.schedule_queue
truncate table pace_master.dbo.SCHEDULE_DEF_MESSAGES
truncate table CTRLCTR.dbo.CTRLC_ADD_ENTITY_ERRORS_HIST
truncate table pace_master.dbo.egl_sched_queue
truncate table pace_master.dbo.egl_sched_queue_detail
truncate table pace_master.dbo.egl_sched_def_details
truncate table pace_master.dbo.egl_sched_def_msgs
truncate table pace_master.dbo.workflow_status
truncate table pace_master.dbo.workflow_status_details 
truncate table pace_master.dbo.generic_regression_results
delete pace_master.dbo.egl_sched_process_def where purge_flag = 1
delete pace_master.dbo.egl_sched_def where spd_instance not in (select instance from pace_master.dbo.egl_sched_process_def) 
delete pace_master.dbo.egl_sched_def_params where sd_instance not in (select instance from pace_master.dbo.egl_sched_def) 
delete pace_master.dbo.schedule_def where custom_proc_name like '%[EVENT%'
delete pace_master.dbo.schedule_def where custom_proc_name like '%Adhoc - MSG CNTR Move File Exporter%'
delete pace_master.dbo.schedule_def where custom_proc_name like '%CANCELTHREAD%' 
delete pace_master.dbo.egl_sched_def_params where parameter_type = 4

update estar.dbo.BIND_DETAIL
   set param_name = 'in_message',
       param_data_type = 5,
	   param_type_len = 100,
	   param_tag = 1618
 where BIND_INSTANCE = 1418041
   and param_order = 1;