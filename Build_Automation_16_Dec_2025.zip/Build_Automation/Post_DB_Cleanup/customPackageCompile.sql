ALTER PACKAGE holdingdbo.spd_holding COMPILE PACKAGE;
ALTER PACKAGE holdingdbo.spd_holding COMPILE BODY;
ALTER PACKAGE holdingdbo01.spd_holding COMPILE PACKAGE;
ALTER PACKAGE holdingdbo01.spd_holding COMPILE BODY;
ALTER PACKAGE pace_masterdbo.rdc_pricing COMPILE PACKAGE;
ALTER PACKAGE pace_masterdbo.rdc_pricing COMPILE BODY;