/* Created by Regression Team for Post DB changes after DB Refresh */
set serveroutput on

spool eagle_post_db_activity.out

BEGIN
  dbms_output.put_line('---------------------------------------------------------------------------');
  dbms_output.put_line('EXECUTING EAGLE_POST_DB_ACTIVITY.SQL SCRIPT');	         		        
  dbms_output.put_line('---------------------------------------------------------------------------');
END;
/

connect pace_masterdbo/eagle@r17a003

DECLARE
    l_count varchar2(128);
BEGIN
    l_count := 0;

    SELECT COUNT (*)
      INTO l_count
      FROM pace_masterdbo.pace_system
     WHERE sys_item IN (2, 39, 86) AND sys_value LIKE '%10.130.42.62%';
    dbms_output.put_line('NUMBER OF RECORDS PRESENT IS : ' || l_count);
    
    if l_count > 0 then
        dbms_output.put_line('UPDATING PACE_MASTERDBO.PACE_SYSTEM TABLE.');
        --update pace_masterdbo.pace_system
        -- set SYS_VALUE = replace(SYS_VALUE, '10.80.104.30',
        --                                    '10.80.104.39')
        --where SYS_VALUE like '%10.80.104.30%';
	else
		dbms_output.put_line('NO RECORDS FOUND FOR UPDATING PACE_MASTERDBO.PACE_SYSTEM TABLE.');
    end if;
END;