import os, sys
from datetime import datetime
from configparser import ConfigParser
import fileHandling

from dotenv import load_dotenv
load_dotenv('.env')

def main(argv):
    now = datetime.now()
    try:
        host = sys.argv[2]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)
    build_version = os.environ.get('build_version')
    build_ini_file = host[0:host.find('-', host.find('-')+1)] + '.ini'
    if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
        print(build_ini_file, 'file present.')
    else:
        print(build_ini_file, 'file missing.')
        sys.exit(2)
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))

    print('Changing Staging Folders in Application/Reporting/Web Tiers START TIME :',
          datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    fileHandling.rename_directory(os.path.join(parser['APP_TIER_DETAIL']['STAGE_LOC'], build_version))
    fileHandling.rename_directory(os.path.join(parser['REPORT_TIER_DETAIL']['STAGE_LOC'], build_version))
    fileHandling.rename_directory(os.path.join(parser['WEB_TIER_DETAIL']['STAGE_LOC'], build_version))
    print('Changing Staging Folders in Application/Reporting/Web Tiers END TIME :',
          datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))


if __name__ == "__main__":
    main(sys.argv)
