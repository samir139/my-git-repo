import os, sys, wmi, winrm, time
from datetime import datetime
from configparser import ConfigParser
from multiprocessing.pool import ThreadPool
from multiprocessing import Process
from subprocess import Popen
import configdetails
import jiradetails
import shareDriveMap
import emailsender
import fileHandling
import ApplyWinEaglePatch
import eagleServices

from dotenv import load_dotenv
load_dotenv('.env')

def win_remote_server_connection (hostname,username, password):
    try:
        connection = winrm.Session(hostname, auth=(username, password), transport='ntlm')
        print('connection established to the ', hostname)
    except Exception as error:
        print('Failed to Establish the Connection with', hostname)
    return connection


def stop_start_remote_service(intype,services, hostname, username, password):
    try:
        connection=win_remote_server_connection(hostname,username,password)

        for service_name in services.split(','):
            print('Executing sc ' + intype + ' "' + service_name + '"')
            result = connection.run_cmd('sc ' + intype + ' "' + service_name + '"')
            output = result.std_out.decode()
            print(output)
            if result.status_code == 0:
                print(f'{intype} {service_name} service is successful in {hostname}')
    except Exception as e:
        print(str(e))

def logs_cleanup(parser):
    print('Deleting Log Files. START TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    fileHandling.delete_log_files(parser['APP_TIER_DETAIL']['HOSTNAME'])
    fileHandling.delete_log_files(parser['REPORT_TIER_DETAIL']['HOSTNAME'])
    fileHandling.delete_log_files(parser['WEB_TIER_DETAIL']['HOSTNAME'])
    print('Deleting Log Files. END TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    print('Deleting bkp Files. START TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    fileHandling.delete_bkp_files(parser['APP_TIER_DETAIL']['HOSTNAME'])
    fileHandling.delete_bkp_files(parser['REPORT_TIER_DETAIL']['HOSTNAME'])
    fileHandling.delete_bkp_files(parser['WEB_TIER_DETAIL']['HOSTNAME'])
    print('Deleting bkp Files. END TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))

def post_upgrade_steps(parser,host):
    print('Apply Post-upgrade Steps. START TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    folder_name = host[0:host.find('-', host.find('-')+1)]
    os.chdir('E:\Build_Automation')
    if parser['ENV_Details']['region'] == 'EARTH':
        fileHandling.execute_postUpgrade_Step(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','EARTH_SQL_'+ folder_name,'Utils','PostUpgradeSteps'),
                                              os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','EARTH_SQL_'+ folder_name,'Utils','PostUpgradeSteps','EARTH_SQL_Post_Upgrade_DB_Cleanup.bat'))

    if parser['ENV_Details']['region'] == 'DMFARM':
        fileHandling.execute_postUpgrade_Step(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','DMFARM_SQL_'+ folder_name,'Utils','PostUpgradeSteps'),
                                              os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','DMFARM_SQL_'+ folder_name,'Utils','PostUpgradeSteps','DM_FARM_SQL_Post_Upgrade_DB_Cleanup.bat'))
        fileHandling.execute_postUpgrade_Step(os.path.join(os.path.abspath(os.path.dirname(__file__))),'DM_FARM_SQL_Reset_Farm_Cycle_Copy.bat')

    if parser['ENV_Details']['region'] == 'PERFFARM':
        fileHandling.execute_postUpgrade_Step(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','PERF_SQL_'+ folder_name,'Utils','PostUpgradeSteps'),
                                              os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup','PERF_SQL_'+ folder_name,'Utils','PostUpgradeSteps','PERF_SQL_Post_Upgrade_DB_Cleanup.bat'))
        fileHandling.execute_postUpgrade_Step(os.path.join(os.path.abspath(os.path.dirname(__file__))), 'PERF_SQL_Post_Upgrade_RegisterDLL.bat')
    print('Apply Post-upgrade Steps. END TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))


def main(argv):
    try:
        host = sys.argv[1]
    except IndexError:
        print('No Environment Variable passed for regression cycle restart. Please provide the Environment Name.')
        sys.exit(2)
    build_ini_file = host[0:host.find('-', host.find('-')+1)] + '.ini'
    if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
        print(build_ini_file, 'file present.')
    else:
        print(build_ini_file, 'file missing.')
        sys.exit(2)
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))

    #Stopping all the engines and services for all tiers.
    stop_start_remote_service('stop', parser['WEB_TIER_DETAIL']['services'], parser['WEB_TIER_DETAIL']['HOSTNAME'], parser['WEB_TIER_DETAIL']['USERNAME'], parser['WEB_TIER_DETAIL']['PASSWORD'])
    stop_start_remote_service('stop', parser['REPORT_TIER_DETAIL']['services'], parser['REPORT_TIER_DETAIL']['HOSTNAME'], parser['REPORT_TIER_DETAIL']['USERNAME'], parser['REPORT_TIER_DETAIL']['PASSWORD'])
    stop_start_remote_service('stop', parser['APP_TIER_DETAIL']['services'], parser['APP_TIER_DETAIL']['HOSTNAME'], parser['APP_TIER_DETAIL']['USERNAME'], parser['APP_TIER_DETAIL']['PASSWORD'])
    time.sleep(300)

    #Clearning the all .log extention files
    logs_cleanup(parser)

    #Doing Pre Regression cycles run steps
    post_upgrade_steps(parser,host)

    # Starting all the engines and services for all tiers.
    stop_start_remote_service('start', parser['WEB_TIER_DETAIL']['services'], parser['WEB_TIER_DETAIL']['HOSTNAME'], parser['WEB_TIER_DETAIL']['USERNAME'], parser['WEB_TIER_DETAIL']['PASSWORD'])
    stop_start_remote_service('start', parser['REPORT_TIER_DETAIL']['services'], parser['REPORT_TIER_DETAIL']['HOSTNAME'], parser['REPORT_TIER_DETAIL']['USERNAME'], parser['REPORT_TIER_DETAIL']['PASSWORD'])
    stop_start_remote_service('start', parser['APP_TIER_DETAIL']['services'], parser['APP_TIER_DETAIL']['HOSTNAME'], parser['APP_TIER_DETAIL']['USERNAME'], parser['APP_TIER_DETAIL']['PASSWORD'])

if __name__ == "__main__":
    main(sys.argv)
