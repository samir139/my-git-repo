import os, sys, wmi, winrm, time
from datetime import datetime
from configparser import ConfigParser
import fileHandling
from dotenv import load_dotenv
load_dotenv('.env')
from enum import Enum
class InputCommand(Enum):
    start = 0
    restart=2
    stop = 6

def win_remote_server_connection (hostname,username, password):
    try:
        connection = winrm.Session(hostname, auth=(username, password), transport='ntlm')
        print('connection established to the ', hostname)
    except Exception as error:
        print('Failed to Establish the Connection with', hostname)
    return connection


def manage_services(intype,services, hostname, username, password):
    try:
        connection=win_remote_server_connection(hostname,username,password)
        for service_name in services.split(','):
            print('Executing sc ' + intype + ' "' + service_name + '"')
            result = connection.run_cmd('sc ' + intype + ' "' + service_name + '"')
            #output = result.std_out.decode()
            print(result.std_out.decode())
            print(f'{intype} {service_name} service is successful in {hostname}')
    except Exception as e:
        print("Exception details : \n" + str(e) + "\n" + str(e.__cause__))

def logs_cleanup(parser):
    print('Deleting Log Files. START TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    fileHandling.delete_log_files(parser['APP_TIER_DETAIL']['HOSTNAME'])
    fileHandling.delete_log_files(parser['REPORT_TIER_DETAIL']['HOSTNAME'])
    fileHandling.delete_log_files(parser['WEB_TIER_DETAIL']['HOSTNAME'])
    print('Deleting Log Files. END TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    print('Deleting bkp Files. START TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    fileHandling.delete_bkp_files(parser['APP_TIER_DETAIL']['HOSTNAME'])
    fileHandling.delete_bkp_files(parser['REPORT_TIER_DETAIL']['HOSTNAME'])
    fileHandling.delete_bkp_files(parser['WEB_TIER_DETAIL']['HOSTNAME'])
    print('Deleting bkp Files. END TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))

def post_upgrade_steps(parser,scriptpath,scriptfilename,addtionalscriptFile):
    os.chdir(os.environ.get('HomeScriptPath'))
    fileHandling.execute_postUpgrade_Step(scriptpath,scriptfilename)
    fileHandling.execute_postUpgrade_Step(scriptpath, addtionalscriptFile)
    if parser['ENV_Details']['region'] == 'PERFFARM':
       fileHandling.deleteDir(parser['APP_TIER_DETAIL']['depositFolder'])
    print('Apply Post-upgrade Steps. END TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))


def main(argv):
    try:
        host = sys.argv[1]
    except IndexError:
        print('No Environment Variable passed for regression cycle restart. Please provide the Environment Name.')
        sys.exit(2)
    build_ini_file = host[0:host.find('-', host.find('-')+1)] + '.ini'
    if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
        print(build_ini_file, 'file present.')
    else:
        print(build_ini_file, 'file missing.')
        sys.exit(2)
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))

    #Stopping all the engines and services for all tiers.
    manage_services(InputCommand.stop.name, parser['WEB_TIER_DETAIL']['services'], parser['WEB_TIER_DETAIL']['HOSTNAME'], parser['WEB_TIER_DETAIL']['USERNAME'], parser['WEB_TIER_DETAIL']['PASSWORD'])
    manage_services(InputCommand.stop.name, parser['REPORT_TIER_DETAIL']['services'], parser['REPORT_TIER_DETAIL']['HOSTNAME'], parser['REPORT_TIER_DETAIL']['USERNAME'], parser['REPORT_TIER_DETAIL']['PASSWORD'])
    manage_services(InputCommand.stop.name, parser['APP_TIER_DETAIL']['services'], parser['APP_TIER_DETAIL']['HOSTNAME'], parser['APP_TIER_DETAIL']['USERNAME'], parser['APP_TIER_DETAIL']['PASSWORD'])
    time.sleep(5)

    #Clearning the all .log extention files
    logs_cleanup(parser)

    #Doing Pre Regression cycles step
    print('Apply Post-upgrade Steps. START TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    folder_name = host[0:host.find('-', host.find('-') + 1)]
    scriptpath=os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup',folder_name,'Utils','PostUpgradeSteps')
    post_upgrade_steps(parser,scriptpath,'Post_Upgrade_DB_Cleanup.bat','Additional_Script.bat')

    # Starting all the engines and services for all tiers.
    manage_services(InputCommand.start.name, parser['WEB_TIER_DETAIL']['services'], parser['WEB_TIER_DETAIL']['HOSTNAME'], parser['WEB_TIER_DETAIL']['USERNAME'], parser['WEB_TIER_DETAIL']['PASSWORD'])
    manage_services(InputCommand.start.name, parser['REPORT_TIER_DETAIL']['services'], parser['REPORT_TIER_DETAIL']['HOSTNAME'], parser['REPORT_TIER_DETAIL']['USERNAME'], parser['REPORT_TIER_DETAIL']['PASSWORD'])
    manage_services(InputCommand.start.name, parser['APP_TIER_DETAIL']['services'], parser['APP_TIER_DETAIL']['HOSTNAME'], parser['APP_TIER_DETAIL']['USERNAME'], parser['APP_TIER_DETAIL']['PASSWORD'])

if __name__ == "__main__":
    main(sys.argv)
