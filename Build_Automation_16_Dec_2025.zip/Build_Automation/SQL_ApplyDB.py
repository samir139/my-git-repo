import os, sys, datetime, time
from datetime import datetime
from configparser import ConfigParser

import configdetails
import jiradetails
import shareDriveMap
import fileHandling

def readKeyStorage(winPrivateKey):
    with open(winPrivateKey, 'r') as file:
        password = file.read()
    return password

def apply_DB(parser, app_edm_loc, edm_path, pkg_path, build_version, username, password):
    print('Map Application Tier Share Path.')
    shareDriveMap.mapDrive(parser['ShareDrive_Details']['win_app_share_drive'],
                           parser['APP_TIER_DETAIL']['stage_loc'],
                           username, password)

    try:
        os.chdir(os.path.join(app_edm_loc + '\\common'))
        app_edm_execute_sql_file = os.path.join(app_edm_loc + '\\common\\execute_sql.cmd')
        if os.path.isfile(app_edm_execute_sql_file):
            fileHandling.replace_string(app_edm_execute_sql_file, parser['APP_TIER_DETAIL']['executesqlLine'],
                                        parser['APP_TIER_DETAIL']['NexecutesqlLine'])
        else:
            print('Please manually copy or edit the execute_sql.cmd file in App Tier & re-apply EDM.')

        os.chdir(
            os.path.join(parser['ShareDrive_Details']['win_app_share_drive'] + '\\' + build_version + '\\' + edm_path))
        edm_setup_file = os.path.join(parser['ShareDrive_Details'][
                                          'win_app_share_drive'] + '\\' + build_version + '\\' + edm_path + '\\edm_setup.cmd')
        fileHandling.delete_lines(edm_setup_file, 3)
        time.sleep(300)
        print('Applying EDM & Package Scripts')
        start_time = datetime.now().time().strftime('%H:%M:%S')
        print('Applying EDM Started at', start_time)
        os.system(parser['APP_TIER_DETAIL']['edmsetupexec'])
        end_time = datetime.now().time().strftime('%H:%M:%S')
        total_time = (datetime.strptime(end_time, '%H:%M:%S') - datetime.strptime(start_time, '%H:%M:%S'))
        print('Applying EDM Completed at', end_time)
        print('Total time taken for Applying EDM', str(total_time))
        start_time = datetime.now().time().strftime('%H:%M:%S')
        print('Applying Package Started at', start_time)
        os.chdir(os.path.join(parser['ShareDrive_Details']['win_app_share_drive'] + '\\' + build_version + '\\' + pkg_path))
        os.system(parser['APP_TIER_DETAIL']['packageexec'])
        end_time = datetime.now().time().strftime('%H:%M:%S')
        total_time = (datetime.strptime(end_time, '%H:%M:%S') - datetime.strptime(start_time, '%H:%M:%S'))
        print('Applying Package Completed at', end_time)
        print('Total time taken for Applying Package', str(total_time))

    except OSError as error:
        print('Failed to execute erd and package')

    print('Un-Map Application Tier Share Path.')
    shareDriveMap.unmapDrive(parser['ShareDrive_Details']['win_app_share_drive'])

try:
    host = sys.argv[1]
except IndexError:
    print('Please provide the DB Hostname...')
    sys.exit(2)

build_version = os.environ.get('build_version')
build_ini_file = host[0:host.find('-', host.find('-')+1)] + '.ini'
if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
    print(build_ini_file, 'file present.')
else:
    print(build_ini_file, 'file missing.')
    sys.exit(2)

parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
build_details, build_version, build_number, build_status = jiradetails.get_jira_details()

build_version = build_version
build_trim_ver = build_version.replace(build_version[:7], '')
root_stage = os.path.join(os.environ.get('dailyBuild_path'), build_version)
#edm_path = os.path.join('DATABASE\\eagle_erd' + build_trim_ver + '\\mssql')
#pkg_path = os.path.join('DATABASE\\packages' + build_trim_ver + '\\mssql')
edm_path = os.path.join('DATABASE\\eagle_erd\\mssql')
pkg_path = os.path.join('DATABASE\\packages\\mssql')
root_stage_edm = os.path.join(root_stage, edm_path)
root_stage_pkg = os.path.join((root_stage), pkg_path)
app_edm_loc = os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version, edm_path)
app_pkg_loc = os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version, pkg_path)
print('SQL EDM Path :', app_edm_loc)
print('SQL PKG Path :', app_pkg_loc)

username = parser['REGION_DETAILS']['username']
winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
password = readKeyStorage(winPrivateKey)

apply_DB(parser, app_edm_loc, edm_path, pkg_path, build_version, username, password)