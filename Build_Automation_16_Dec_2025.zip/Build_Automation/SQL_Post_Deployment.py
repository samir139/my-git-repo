import os, sys
from datetime import datetime
from configparser import ConfigParser

import fileHandling


def post_upgrade(parser):
    print('Apply Post-upgrade Steps. START TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
    folder_name = host[0:host.find('-', host.find('-') + 1)]

    if parser['ENV_Details']['region'] == 'EARTH':
        db_cleanup_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup',
                                       'EARTH_SQL_' + folder_name, 'Utils', 'PostUpgradeSteps')
        db_cleanup_script = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup',
                                         'EARTH_SQL_' + folder_name, 'Utils', 'PostUpgradeSteps',
                                         'EARTH_SQL_Post_Upgrade_DB_Cleanup.bat')
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, db_cleanup_script)
        fileHandling.delete_msgcenterfiles(parser['APP_TIER_DETAIL']['msgcenterLoc_1'])
        fileHandling.delete_msgcenterfiles(parser['APP_TIER_DETAIL']['msgcenterLoc_2'])
        fileHandling.delete_msgcenterfiles(parser['APP_TIER_DETAIL']['msgcenterLoc_3'])
        fileHandling.delete_msgcenterfiles(parser['APP_TIER_DETAIL']['msgcenterLoc_4'])

    if parser['ENV_Details']['region'] == 'DMFARM':
        db_cleanup_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup',
                                       'DMFARM_SQL_' + folder_name, 'Utils', 'PostUpgradeSteps')
        db_cleanup_script = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup',
                                         'DMFARM_SQL_' + folder_name, 'Utils', 'PostUpgradeSteps',
                                         'DM_FARM_SQL_Post_Upgrade_DB_Cleanup.bat')
        reset_farm_cycle_copy = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup',
                                             'DMFARM_SQL_' + folder_name, 'Utils', 'PostUpgradeSteps',
                                             'DM_FARM_SQL_Reset_Farm_Cycle_Copy.bat')
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, db_cleanup_script)
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, reset_farm_cycle_copy)

    if parser['ENV_Details']['region'] == 'PERFFARM':
        db_cleanup_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup',
                                       'PERF_SQL_' + folder_name, 'Utils', 'PostUpgradeSteps')
        db_cleanup_script = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup',
                                         'PERF_SQL_' + folder_name, 'Utils', 'PostUpgradeSteps',
                                         'PERF_SQL_Post_Upgrade_DB_Cleanup.bat')
        adv_dll_register = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'Post_DB_Cleanup',
                                        'PERF_SQL_' + folder_name, 'Utils', 'PostUpgradeSteps',
                                        'PERF_SQL_Post_Upgrade_RegisterDLL.bat')
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, db_cleanup_script)
        fileHandling.execute_postUpgrade_Step(db_cleanup_path, adv_dll_register)
        fileHandling.deleteDepositDir(parser['APP_TIER_DETAIL']['depositFolder'])
    print('Apply Post-upgrade Steps. END TIME : ', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))

try:
    host = sys.argv[1]
except IndexError:
    print('Please provide the DB Hostname...')
    sys.exit(2)

build_ini_file = host[0:host.find('-', host.find('-')+1)] + '.ini'
if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
    print(build_ini_file, 'file present.')
else:
    print(build_ini_file, 'file missing.')
    sys.exit(2)

parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))

post_upgrade(parser)