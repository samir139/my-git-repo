import os,shutil,sys,subprocess
from datetime import datetime
from configparser import ConfigParser
from dotenv import load_dotenv
from multiprocessing.pool import ThreadPool
from multiprocessing import Process

load_dotenv('.env')

class MultithreadedCopier:
    def __init__(self, max_threads):
        self.pool = ThreadPool(max_threads)

    def copy(self, source, dest):
        self.pool.apply_async(shutil.copy2, args=(source, dest))

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.pool.close()
        self.pool.join()

def readKeyStorage(winPrivateKey):
    with open(winPrivateKey, 'r') as file:
        password = file.read()
    return password

def rename_existing_folder(share_path,username,password,oldname):
    create_time = os.path.getmtime(share_path)
    format_time = datetime.fromtimestamp(create_time).strftime('%m-%d-%Y-%H.%M.%S')
    newname=oldname+'_'+format_time
    oldpath=os.path.join(share_path,oldname)
    newpath=os.path.join(share_path,newname)
    try:
        shutil.move(oldpath,newpath)
        print("Renamed folder " + oldpath + " to " + newpath)
    except FileNotFoundError:
        print('Folder does not exist.')
    except FileExistsError:
        print('A folder with the the new name already exists.')

def StageFileCopy(source_loc, destination_loc):
    try:
        print('Staging files copying for  : ', destination_loc)
        with MultithreadedCopier(max_threads=100) as copier:
            shutil.copytree(source_loc, destination_loc, copy_function=copier.copy)
    except Exception as e:
        print('Check if the ' + destination_loc + ' is opened in any other location')

try:
    host = sys.argv[1]
    serverType = sys.argv[2]
except IndexError:
    print('Please provide Hostname...')
    sys.exit(2)

build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
    print(build_ini_file, 'file present.')
else:
    print(build_ini_file, 'file missing.')
    sys.exit(2)
parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
build_version = os.environ.get('build_version')
root_stage = os.path.join(os.environ.get('dailyBuild_path'))

root_stage_patch = os.path.join(root_stage, build_version, 'EAGLE_PATCH')

if serverType == 'APP':
    username= parser['APP_TIER_DETAIL']['username']
    winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
    password = readKeyStorage(winPrivateKey)
    staging_path = parser['APP_TIER_DETAIL']['stage_loc']
    build_trim_ver = build_version.replace(build_version[:7], '')
    #edm_path = os.path.join('DATABASE\\eagle_erd_' + build_trim_ver + '\\mssql')
    #pkg_path = os.path.join('DATABASE\\packages_' + build_trim_ver + '\\mssql')
    edm_path = os.path.join('DATABASE\\eagle_erd\\mssql')
    pkg_path = os.path.join('DATABASE\\packages\\mssql')
    app_edm_loc = os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version, edm_path)
    app_pkg_loc = os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version, pkg_path)
    app_patch_loc = os.path.join(parser['APP_TIER_DETAIL']['stage_loc'], build_version, 'EAGLE_PATCH')
    root_stage = os.path.join(os.environ.get('dailyBuild_path'), build_version)
    #edm_path = os.path.join('DATABASE\\eagle_erd_' + build_trim_ver + '\\mssql')
    #pkg_path = os.path.join('DATABASE\\packages_' + build_trim_ver + '\\mssql')
    edm_path = os.path.join('DATABASE\\eagle_erd\\mssql')
    pkg_path = os.path.join('DATABASE\\packages\\mssql')
    root_stage_edm = os.path.join(root_stage, edm_path)
    root_stage_pkg = os.path.join((root_stage), pkg_path)
    rename_existing_folder(staging_path, username, password, build_version)
    StageFileCopy(root_stage_edm, app_edm_loc)
    StageFileCopy(root_stage_pkg, app_pkg_loc)
    StageFileCopy(root_stage_patch, app_patch_loc)

if serverType == 'RPT':
    username= parser['REPORT_TIER_DETAIL']['username']
    winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
    password = readKeyStorage(winPrivateKey)
    staging_path = parser['REPORT_TIER_DETAIL']['stage_loc']
    rpt_patch_loc = os.path.join(parser['REPORT_TIER_DETAIL']['stage_loc'], build_version, 'EAGLE_PATCH')
    rename_existing_folder(staging_path, username, password, build_version)
    StageFileCopy(root_stage_patch, rpt_patch_loc)

if serverType == 'WEB':
    username= parser['WEB_TIER_DETAIL']['username']
    winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
    password = readKeyStorage(winPrivateKey)
    staging_path = parser['WEB_TIER_DETAIL']['stage_loc']
    web_patch_loc = os.path.join(parser['WEB_TIER_DETAIL']['stage_loc'], build_version, 'EAGLE_PATCH')
    rename_existing_folder(staging_path, username, password, build_version)
    StageFileCopy(root_stage_patch, web_patch_loc)



