import sys, os, glob, time
import winrm
from configparser import ConfigParser

def readKeyStorage(winPrivateKey):
    with open(winPrivateKey, 'r') as file:
        password = file.read()
    return password

def start_remote_service(services, remote_host, username, password):
    try:
        connection = winrm.Session(remote_host, auth=(username, password), transport='ntlm')
        print('Connection Established to the ', remote_host)
        for service_name in services.split(','):
            result = connection.run_cmd('sc start ' + service_name)
            output = result.std_out.decode()
            print(output)
            if result.status_code == 0:
                print('The ' + service_name + 'service is started in ' + remote_host)
            else:
                print('The ' + service_name + ' is already started in ' + remote_host)
    except Exception as e:
        print(str(e))

def get_service_status(session, service_name):
    result = session.run_cmd(f"sc query {service_name}")
    output = result.std_out.decode(errors='ignore').lower()
    if "running" in output:
        return "RUNNING"
    elif "stopped" in output:
        return "STOPPED"
    else:
        return "UNKNOWN"

def stop_remote_service(services, remote_host, username, password):
    try:
        connection = winrm.Session(remote_host, auth=(username, password), transport='ntlm')
        print('Connection Established to the ', remote_host)
        for service_name in services.split(','):
            result = connection.run_cmd('sc stop ' + service_name)
            output = result.std_out.decode()
            print(output)
            if result.status_code == 0:
                print('The ' + service_name + ' service has been stopped in ' + remote_host)
            else:
                print('The ' + service_name + ' is already stopped in ' + remote_host)
    except Exception as e:
        print(str(e))
def delete_log_files(hostname,username,password):
    pattern = r"\\\\" + hostname + "\\logs\\**\\*.log"
    file_count = 0
    for item in glob.iglob(pattern, recursive=True):
        try:
            file_count += len(item)
            os.remove(item)
        except:
            print("Error while deleting file", item)
    print(file_count, 'No of log files deleted in ', hostname)

def delete_bkp_files(hostname,username,password):
    pattern = r"\\\\" + hostname + r"\\Eagle Investment Systems\\bkp\\patch\\**\\*.res"
    res_file_count = 0
    for item in glob.iglob(pattern, recursive=True):
        try:
            res_file_count += len(item)
            os.remove(item)
        except:
            print("Error while deleting file", item)
    print(res_file_count, 'No. of res files deleted in ', hostname)

    pattern = r"\\\\" + hostname + r"\\Eagle Investment Systems\\bkp\\patch\\**\\*.rar"
    rar_file_count = 0
    for item in glob.iglob(pattern, recursive=True):
        try:
            rar_file_count += len(item)
            os.remove(item)
        except:
            print("Error while deleting file", item)
    print(rar_file_count, 'No. of rar files deleted in ', hostname)

try:
    hostname = sys.argv[1]
    serverType = sys.argv[2]
    serviceType = sys.argv[3]
except IndexError:
    print('No parameters passed for windows services...')
    sys.exit(2)

for host in hostname.split(','):
    build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
    if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
        print(build_ini_file, 'file present.')
    else:
        print(build_ini_file, 'file missing.')
        sys.exit(2)

    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))

    if serverType == 'APP':
        stopServices = str(parser['APP_TIER_DETAIL']['stop_services'])
        startServices = str(parser['APP_TIER_DETAIL']['start_services'])
        username = parser['APP_TIER_DETAIL']['USERNAME']
        winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
        password = readKeyStorage(winPrivateKey)

    if serverType == 'RPT':
        stopServices = str(parser['REPORT_TIER_DETAIL']['stop_services'])
        startServices = str(parser['REPORT_TIER_DETAIL']['start_services'])
        username = parser['REPORT_TIER_DETAIL']['USERNAME']
        winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
        password = readKeyStorage(winPrivateKey)

    if serverType == 'WEB':
        stopServices = str(parser['WEB_TIER_DETAIL']['stop_services'])
        startServices = str(parser['WEB_TIER_DETAIL']['start_services'])
        username = parser['WEB_TIER_DETAIL']['USERNAME']
        winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
        password = readKeyStorage(winPrivateKey)

    if serviceType == 'START':
        print(host, ' - STARTING WINDOWS EAGLE SERVICES...')
        start_remote_service(startServices, host, username, password)

    if serviceType == 'STOP':
        print(host, ' - STOPPING WINDOWS EAGLE SERVICES...')
        stop_remote_service(stopServices, host, username, password)
        time.sleep(300)
        delete_log_files(host,username,password)
        delete_bkp_files(host,username,password)