import sys, os, glob, subprocess
import winrm
from configparser import ConfigParser
import win32serviceutil


def stop_remote_service(services, remote_host, username, password):
    try:
        connection = winrm.Session(remote_host, auth=(username, password), transport='ntlm')
        print('connection established to the ', remote_host)
        for service_name in services.split(','):
            print("sc \\\\" + hostname + " stop", service_name)
            result = connection.run_cmd("sc \\" + hostname + " stop " + service_name + " /y")
            output = result.std_out.decode()
            print(output)
            print(result.status_code)
            if result.status_code == 0:
                print('the ', service_name, 'service has been stopped in ',remote_host)
            else:
                print(service_name, 'is already stopped in', remote_host)
        #stop_eventlog_service()
        service_manager('stop', remote_host, 'EventLog')
    except Exception as e:
        print(str(e))

def stop_eventlog_service():
    try:
        # Command to stop the Eventlog service
        #result = subprocess.run(["sc", "stop", "EventLog"], check=True, capture_output=True, text=True)
        result = subprocess.run('sc stop EventLog', check=True, capture_output=True, text=True)
        print("Eventlog service stopped successfully.")
    except subprocess.CalledProcessError as e:
        # Check if the error is due to the service already being stopped
        if "1051" in e.output:
            print("Eventlog service is already stopped.")
        else:
            print(f"Failed to stop Eventlog service: {e}")
    except Exception as ex:
        print(f"An error occurred: {ex}")

def service_manager(action, machine, service):
    if action == 'stop':
        win32serviceutil.StopService(service, machine)
    elif action == 'start':
        win32serviceutil.StartService(service, machine)
    elif action == 'restart':
        win32serviceutil.RestartService(service, machine)
    elif action == 'status':
        if win32serviceutil.QueryServiceStatus(service, machine)[1] == 4:
            print ("%s is happy" % service)
        else:
            print ("%s is being a PITA" % service)

try:
    hostname = sys.argv[1]
    services = sys.argv[2]
except IndexError:
    print('No Environment Variable passed for applying build. Please provide the Environment Name.')
    sys.exit(2)
for host in hostname.split(','):
    build_version = os.environ.get('build_version')
    build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
    if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
        print(build_ini_file, 'file present.')
    else:
        print(build_ini_file, 'file missing.')
        sys.exit(2)

    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    if 'WW' in hostname or 'ww' in hostname:
        username = parser['WEB_TIER_DETAIL']['USERNAME']
        password = parser['WEB_TIER_DETAIL']['PASSWORD']
    if 'WR' in hostname or 'wr' in hostname:
        username = parser['REPORT_TIER_DETAIL']['USERNAME']
        password = parser['REPORT_TIER_DETAIL']['PASSWORD']

    stop_remote_service(services, host, username, password)