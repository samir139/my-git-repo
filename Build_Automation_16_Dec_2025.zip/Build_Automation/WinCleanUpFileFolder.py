import os, sys
from pathlib import Path
from configparser import ConfigParser
import shutil
import jiradetails

def read_config_details():
    try:
        config_filename = 'CleanUpFileFolder.ini'
        path = Path(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', config_filename))
        if path.is_file():
            print(f'The Configuration file {config_filename} is present')
            print(path)
            parser = ConfigParser()
            parser.read(path)
        else:
            print(f'The Configuration file {config_filename} missing please verify')
        return parser
    except OSError as error:
        print(f'The Configuration file {config_filename} missing please verify')
        sys.exit(2)

def delete_folders_starting_with(path, start_string, buildVersion):
    if os.path.exists(path):
        for root, dirs, files in os.walk(path, topdown=True):
            for name in dirs:
                if name != buildVersion and (name.startswith(start_string) or os.path.exists(start_string)):
                    folder_path = os.path.join(root, name)
                    try:
                        shutil.rmtree(folder_path)
                        print(f"Deleted folder: {folder_path}")
                    except Exception as e:
                        print(f"Error deleting folder {folder_path}: {e}")
    else:
        print(f'Stage Path {path} does not exist')

def delete_files_with_extension(directory, extension):
    if os.path.exists(directory):
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.endswith(extension):
                    file_path = os.path.join(root, file)
                    try:
                        os.remove(file_path)
                        print(f"Deleted file: {file_path}")
                    except Exception as e:
                        print(f"Error deleting file {file_path}: {e}")
    else:
        print(f'Log Path {directory} does not exist')

hostname = sys.argv[1]
par = read_config_details()
buildDetails, buildVersion, buildNumber, buildStatus = jiradetails.get_jira_details()
directory_path = '\\\\' + hostname + '\\' + par['CleanUpDetails']['stagePath']

print(f'Looking for stage folders versions in {directory_path} and if present delete')
# delete all stage folders for current verison
string_to_match = buildVersion + '_'
print('String to Match:', string_to_match)
delete_folders_starting_with(directory_path, string_to_match, buildVersion)

# delete all stage folders for prior verison
prior_ver = int(buildVersion.partition('.')[2])
for i in range(prior_ver):
    old_ver = buildVersion.partition('.')[0] + '.' + str(i)
    delete_folders_starting_with(directory_path, old_ver, buildVersion)

# delete all log files
log_path = '\\\\' + hostname + '\\' + par['CleanUpDetails']['winLogPath']
print(f'Looking for .log files in {log_path} and delete')
logfile_extension = ".log"
#print(shared_path)
delete_files_with_extension(log_path, logfile_extension)

resfile_extension = ".res"
res_path = '\\\\' + hostname + '\\' + par['CleanUpDetails']['winBkpPath']
print(f'Looking for .res files in {res_path} and delete')
delete_files_with_extension(res_path, resfile_extension)

rarfile_extension = ".rar"
rar_path = '\\\\' + hostname + '\\' + par['CleanUpDetails']['winBkpPath']
print(f'Looking for .rar files in {rar_path} and delete')
delete_files_with_extension(rar_path, rarfile_extension)