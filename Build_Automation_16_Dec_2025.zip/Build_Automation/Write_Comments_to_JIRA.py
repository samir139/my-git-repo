from jira import JIRA
from configparser import ConfigParser
import os, sys


def get_jira_server_details():
    try:
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', 'jiradetails.ini'))
        jira_server = parser['GET_JIRA']['jira_server']
        jira_uid = parser['GET_JIRA']['jira_uid']
        jira_token = parser['GET_JIRA']['jira_token']
        return jira_server, jira_uid, jira_token
    except Exception as e:
        print(e)

def write_jira_comments(ticket_id, comment_text):
    try:
        jira_server, jira_uid, jira_token = get_jira_server_details()
        jira = JIRA(server=jira_server, basic_auth=(jira_uid, jira_token))
        jira.add_comment(ticket_id, comment_text)
        print("Comment added to " + ticket_id)
    except Exception as e:
        print(e)

jira_id = sys.argv[1]
jira_comment = sys.argv[2]

write_jira_comments(jira_id, jira_comment)