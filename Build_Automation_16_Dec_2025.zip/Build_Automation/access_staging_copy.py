import paramiko, sys, os, platform, time, subprocess
from configparser import ConfigParser
from datetime import datetime
import tarfile
from dotenv import load_dotenv

load_dotenv()


def execute_command(host, port, username, password, command):
    print('Hostname:', host)
    print('Username:', username)
    print('Command:', command)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=host, port=port, username=username, password=password)
    stdin, stdout, stderr = ssh.exec_command(command)
    for line in stdout:
        print(line.strip(), flush=True)
    print(stdout.read().decode(), flush=True)
    return ssh

def connectin_execution(host, port, username, private_key_path, command):
    print('HOSTNAME :', host)
    print('USERNAME :', username)
    print('COMMAND :', command)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    private_key=paramiko.RSAKey.from_private_key_file(private_key_path)
    ssh.connect(hostname=host,port=port,username=username, pkey=private_key)
    stdin, stdout, stderr = ssh.exec_command(command)
    for line in stdout:
        print(line.strip(), flush=True)
    print(stdout.read().decode(), flush=True)
    return ssh


def main(argv):
    now = datetime.now()
    try:
        host = sys.argv[1]
        hostnames=sys.argv[2]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)

    build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
    print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    directory_name = os.getenv('build_version')
    nfs_path = str(parser['BUILD_DIR']['nfsPath'])
    load_dotenv()
    startx_path = os.path.join(os.getenv('dailyBuild_path'), directory_name)

    port = parser['REGION_DETAILS']['port']
    username = parser['REGION_DETAILS']['username']
    #password = parser['REGION_DETAILS']['password']
    private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], host.split('.')[0])

    date_string = now.strftime("%d-%m-%Y")

    new_name = f"{directory_name}_{date_string}"
    print("***********************************************************")
    print('REMOVING EXISTING DIRECTORY NFS PATH')
    print("***********************************************************")
    exec_chg_user = 'sudo su - eagle'
    connectin_execution(host, port, username, private_key_path, exec_chg_user)
    exec_remove_directory = 'cd ' + nfs_path + ' && ' \
                                               'rm -rf ' + directory_name
    connectin_execution(host, port, username, private_key_path, exec_remove_directory)

    print("***********************************************************")
    print('REMOVING DIRECTORY COMPLETED NFS PATH')
    print("***********************************************************")

    tar_file_name = 'eagle_access' + '.tar'
    print('TAR FILE CREATED:', tar_file_name)

    tarf = tarfile.open(tar_file_name, 'w')
    for root, dirs, files in os.walk(startx_path):
        for file in files:
            file_path = os.path.join(root, file)
            tarf.add(file_path, arcname=os.path.relpath(file_path, startx_path))
    tarf.close()
    destination = nfs_path + directory_name + '/'
    print(destination)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    private_key = paramiko.RSAKey.from_private_key_file(private_key_path)
    ssh.connect(hostname=host, port=port, username=username, pkey=private_key)
    sftp = ssh.open_sftp()
    try:
        sftp.stat(destination)
    except FileNotFoundError:
        sftp.mkdir(destination)
    print("***********************************************************")
    print('COPYING TAR FILE STARTED TO NFS PATH')
    print("***********************************************************")
    sftp.put(tar_file_name, destination + tar_file_name)
    print("***********************************************************")
    print('COPYING TAR FILE COMPLETED IN NFS PATH')
    print("***********************************************************")
    exec_untar = 'cd ' + destination + ' && ' \
                                       'tar -xvf ' + tar_file_name
    connectin_execution(host, port, username, private_key_path, exec_untar)

    exec_fullpermission = 'cd ' + destination + ' && ' \
                                       'chmod -R 777 ' + tar_file_name
    connectin_execution(host, port, username, private_key_path, exec_fullpermission)
    print("***********************************************************")
    print('UN TAR IS COMPLETED')
    print("***********************************************************")
    exec_remove_tar = 'cd ' + destination + ' && ' \
                                            'rm -rf ' + tar_file_name + ' && ls -l'

    connectin_execution(host, port, username, private_key_path, exec_remove_tar)
    print("***********************************************************")
    print('BINARIES COPY COMPLETED TO NFS LOCATION')
    print("***********************************************************")
    print('STARTING THE FILE COPY FROM NFS PATH TO STAGE PATH OF EACH LINUX BOX')
    print("***********************************************************")
    for host in hostnames.split(','):
        build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
        print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    
        hostname = host.split('.')[0]
        stage_path = str(parser['BUILD_DIR']['stagingAppPath'])
        directory_name = os.getenv('build_version')
        nfs_path = str(parser['BUILD_DIR']['nfsPath'])
        destination = str(parser['BUILD_DIR']['stagingAppPath'])
        date_string = now.strftime("%d-%m-%Y")
        new_name = f"{directory_name}_{date_string}"
    
        port = parser['REGION_DETAILS']['port']
        username = parser['REGION_DETAILS']['username']
        private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], hostname)
    
        print("***********************************************************")
        print('RENAMING THE EXISTING DIRECTORY IN : ', host)
        print("***********************************************************")
        exec_chg_user = 'sudo su - eagle'
        connectin_execution(host, port, username, private_key_path, exec_chg_user)

        exec_rename_directory = 'cd ' + stage_path + ' && ' \
                                                     'mv ' + directory_name + ' ' + new_name + ' && ls -l'
        print('HOSTNAME :', hostname)
        print('USERNAME :', username)
        print('COMMAND :', exec_rename_directory)
        connectin_execution(host, port, username, private_key_path, exec_rename_directory)
    
        print("***********************************************************")
        print('RENAME DIRECTORY COMPLETED IN :', host)
        print("***********************************************************")
        print("***********************************************************")
        print('COPY FILES FROM NFS TO STAGING PATH:', host)
        print("***********************************************************")
        exec_copy_command = 'cp -r ' + nfs_path + directory_name + ' ' + destination
        print('COMMAND :', exec_copy_command)
        connectin_execution(host, port, username, private_key_path, exec_copy_command)

        exec_fullpermission = 'cd ' + destination + ' && ' \
                                                    'chmod -R 777 ' + directory_name
        print('CHANGE FOLDER PERMISSION FOR :', directory_name, 'IN', host)
        connectin_execution(host, port, username, private_key_path, exec_fullpermission)
        print("***********************************************************")
        print('COPY FILES FROM NFS TO STAGING PATH COMPLETED IN :', host)
        print("***********************************************************")
        print("***********************************************************")
        print('CHECK THE DIRECTORY FILES OR COPIED OR NOT IN :', host)
        print("***********************************************************")
        exec_check_command = 'cd ' + destination + directory_name + ' && ls -l'
        connectin_execution(host, port, username, private_key_path, exec_check_command)
        print("***********************************************************")
        print('CHECKING COMPLETED IN :', host)
        print("***********************************************************")

if __name__ == "__main__":
    main(sys.argv)
