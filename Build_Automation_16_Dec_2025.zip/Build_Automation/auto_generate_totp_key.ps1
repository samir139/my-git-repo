# Change working directory
Set-Location "E:\vault_1.20.3_windows_386"

# Start Vault server in a new process (run in background)
Start-Process -FilePath ".\vault.exe" -ArgumentList "server -config=E:\vault_1.20.3_windows_386\config.hcl" -WindowStyle Hidden

# Wait a few seconds for server to come up
Start-Sleep -Seconds 5

# Set Vault address environment variable
$env:VAULT_ADDR = "http://127.0.0.1:8200"

# ---- Unseal Keys (replace with your real keys) ----
$UnsealKeys = @(
    "iue872YVCf16cux8Aa+TDGyXaChKeGNbuZ7Zwzwq2/OA",
    "aHHoyMrVUZ3PIsN1CH3Kzb/Xdt7yx1X4thMUnoCvAt6D",
    "UJz5OC7UpEJj9izQmFHmZmA9RiGkDtnry9sbsljzu4o1"
)

# Unseal Vault (3 times with different keys)
foreach ($key in $UnsealKeys) {
    vault operator unseal $key | Out-Null
}

# ---- Login Token (replace with your real token) ----
$LoginToken = "hvs.p11ulDOWKD26canYR4EmG67Y"

# Login to Vault
vault login $LoginToken | Out-Null

# Read TOTP code for user
vault read totp/code/farm@eagleinvsys.com
