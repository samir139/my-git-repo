import sys, os, paramiko, re
import sys, os, paramiko, re
from jira import JIRA
from dotenv import load_dotenv
from configparser import ConfigParser

load_dotenv('.env')
build_id = os.environ.get('build_id')
parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)),'configurations','jiradetails.ini'))
jira_server = parser['GET_JIRA']['jira_server']
jira_uid = parser['GET_JIRA']['jira_uid']
jira_token = parser['GET_JIRA']['jira_token']
jiraOptions = {'server': jira_server}
jira = JIRA(options=jiraOptions, basic_auth=(jira_uid, jira_token))

def get_jira():
    build_status = str(jira.issue(build_id).fields.status)
    return build_status

def get_build_number():
    a=int(0)
    for i in jira.comments(build_id):
         if int(i.id)>a:
             a = int(i.id)

    build_details = jira.comment(build_id,a).body
    count = len(jira.comments(build_id))
    for i in range(count,0,-1):
        build_details = jira.comment(build_id,jira.comments(build_id)[i-1]).body
        if re.findall("Build:",build_details,re.MULTILINE):
            for line in build_details.splitlines():
               if "Build" in line:
                   build_number = line
                   text_file = open(os.path.join(os.path.abspath(os.path.dirname(__file__)), "buildCommitDetails.txt"), "w")
                   n = text_file.write(build_number)
                   text_file.close()
                   break
            return build_number
            break

def execute_command(host, port, username, password, command):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=host,port=port,username=username, password=password)
    stdin, stdout, stderr = ssh.exec_command(command)
    for line in stdout:
        print(line.strip(), flush=True)
    print(stdout.read().decode(), flush=True)

def main(argv):
    host = sys.argv[1]
    build_status = get_jira()
    build_number = get_build_number()
    #print(build_status)
    #print(build_number)

    f = open(os.path.join(os.path.abspath(os.path.dirname(__file__)), "buildCommitDetails.txt"), "r")
    print('Last Build Applied :', f.readline())

    if build_status == 'Deployed To QA' and build_number != f.readline():
        print('Ready to take backup, call the shell script.')
        #host = 'r17-a003-le03.eagleaccess.com'
        values = sys.argv[1].split(",")
        for host in values:
            port = '22'
            try:
               username = 'eagle'
               password = 'z1p.unc&'
            except Exception as error:
               username = 'farm'
               password = 'K2QXb5'
            stop_services = 'cd /apps/eagle/eaglemgr && ./stop ALL'
            take_backup = 'cd /apps/eagle/nfs/reg_scripts && ./reg_backup.sh'
            start_services = 'cd /apps/eagle/eaglemgr && ./start ALL'
            #print('Stopping Services in :', host)
            #execute_command(host, port, username, password, stop_services)
            print('Taking Backup in :', host)
            execute_command(host, port, username, password, take_backup)
            #print('Starting Services in :', host)
            #execute_command(host, port, username, password, start_services)
    else:
        print('Backup Already taken.')

if __name__ == "__main__":
    main(sys.argv)
