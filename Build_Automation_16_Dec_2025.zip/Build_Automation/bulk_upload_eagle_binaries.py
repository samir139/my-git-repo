import os
import sys
import shutil
import paramiko
#from common.read_vault_config import VaultKeyFetcher

sys.stdout.reconfigure(encoding='utf-8', line_buffering=True)

class EagleBulkUploadBinaries:
    def __init__(self, base_path, dest_base):
        self.base_path = base_path
        self.dest_base = dest_base
        self.versions = range(1, 18)  # 1–17 inclusive
        self.folders_to_copy = self.determine_copy_mode()
        self.hostname = self.extract_hostname()
        self.short_hostname = self.hostname.split(".")[0]
        self.use_sftp = "la" in self.short_hostname or "le" in self.short_hostname
        self.sftp = None
        self.transport = None
        #fetcher = VaultKeyFetcher(self.host)
        #self.private_key = fetcher.get_private_key()

    def extract_hostname(self):
        if self.dest_base.startswith("\\\\"):
            parts = self.dest_base.strip("\\").split("\\")
            return parts[0].lower()
        else:
            parts = self.dest_base.strip("/").split("/")
            return parts[0].lower() if parts else self.dest_base.lower()

    def determine_copy_mode(self):
        if self.dest_base.startswith("\\\\"):
            parts = self.dest_base.strip("\\").split("\\")
            hostname = parts[0].lower()
        else:
            hostname = self.dest_base.split("/")[1].lower() if len(self.dest_base.split("/")) > 1 else self.dest_base.lower()

        short_hostname = hostname.split(".")[0]
        print(f"Short hostname detected: {short_hostname}")

        if "ww" in short_hostname:
            print("Environment: WW → EAGLE_PATCH, MODULES")
            return ["EAGLE_PATCH", "MODULES"]
        elif "wr" in short_hostname:
            print("Environment: WR → EAGLE_PATCH")
            return ["EAGLE_PATCH"]
        elif "wa" in short_hostname:
            print("Environment: WA → DATABASE, EAGLE_PATCH")
            return ["DATABASE", "EAGLE_PATCH"]
        elif "la" in short_hostname or "le" in short_hostname:
            print("Environment: LA/LE → Upload DATABASE, EAGLE_PATCH via SFTP")
            return ["DATABASE", "EAGLE_PATCH"]
        else:
            print("Default: DATABASE, EAGLE_PATCH")
            return ["DATABASE", "EAGLE_PATCH"]

    @staticmethod
    def count_files_in_dir(path):
        if not os.path.exists(path):
            return 0
        return sum(len(files) for _, _, files in os.walk(path))

    def copy_folder(self, src, dest):
        dest = '\\\\' + self.hostname + dest.replace('/', '\\')
        if not os.path.exists(src):
            print(f"Source folder not found: {src}", flush=True)
            return 0
        os.makedirs(dest, exist_ok=True)
        file_count = 0
        for root, _, files in os.walk(src):
            rel_path = os.path.relpath(root, src)
            dest_dir = os.path.join(dest, rel_path)
            os.makedirs(dest_dir, exist_ok=True)
            for f in files:
                shutil.copy2(os.path.join(root, f), os.path.join(dest_dir, f))
                file_count += 1
        return file_count

    def sftp_connect(self):
        """Establish SFTP connection."""
        hostname = self.dest_base.split("\\")[2].split(".")[0]
        username = "eagle"
        private_key_path = os.path.expanduser(
            r"E:\Rundeck\var\storage\content\keys\EIS-LinuxAccount\o171-e001-la03"
        )
        #private_key_path = self.private_key
        print(f"Connecting to {hostname} via SFTP using private key", flush=True)
        key = paramiko.RSAKey.from_private_key_file(private_key_path)
        self.transport = paramiko.Transport((hostname, 22))
        self.transport.connect(username=username, pkey=key)
        self.sftp = paramiko.SFTPClient.from_transport(self.transport)
        print("Connected to remote Linux host.", flush=True)

    def sftp_mkdirs(self, remote_path):
        dirs = remote_path.strip("/").split("/")
        path = ""
        for d in dirs:
            path += "/" + d
            try:
                self.sftp.stat(path)
            except FileNotFoundError:
                self.sftp.mkdir(path)

    def sftp_upload_folder(self, local_path, remote_path):
        if not os.path.exists(local_path):
            print(f"Local path not found: {local_path}", flush=True)
            return 0
        file_count = 0
        for root, _, files in os.walk(local_path):
            rel_path = os.path.relpath(root, local_path)
            remote_dir = os.path.join(remote_path, rel_path).replace("\\", "/")
            self.sftp_mkdirs(remote_dir)
            for f in files:
                local_file = os.path.join(root, f)
                remote_file = f"{remote_dir}/{f}"
                self.sftp.put(local_file, remote_file)
                file_count += 1
        return file_count

    def process_windows_copy(self):
        for x in self.versions:
            version_tag = f"Eagle_2017R2.{x}"
            src_root = os.path.join(self.base_path, version_tag, "EAGLE_APPLICATIONS")
            parts = self.dest_base.strip("\\").split("\\")
            dest_relative = "\\".join(parts[1:])
            dest_root = os.path.join("/", dest_relative, version_tag).replace("\\", "/")

            print(f"\nProcessing version: {version_tag}", flush=True)
            os.makedirs(dest_root, exist_ok=True)
            total_src_files, total_dest_files = 0, 0

            for folder_name in self.folders_to_copy:
                src_path = os.path.join(src_root, folder_name)
                dest_path = os.path.join(dest_root, folder_name).replace("\\", "/")

                src_file_count = self.count_files_in_dir(src_path)
                total_src_files += src_file_count

                copied_count = self.copy_folder(src_path, dest_path)
                total_dest_files += copied_count
                print(f"Copied {copied_count}/{src_file_count} files → {folder_name}", flush=True)

            print(f"Version {version_tag}: Source={total_src_files}, Copied={total_dest_files}", flush=True)

    def process_linux_upload(self):
        self.sftp_connect()

        for x in self.versions:
            version_tag = f"Eagle_2017R2.{x}"
            src_root = os.path.join(self.base_path, version_tag, "EAGLE_APPLICATIONS")
            parts = self.dest_base.strip("\\").split("\\")
            dest_relative = "\\".join(parts[1:])
            dest_root = os.path.join("/", dest_relative, version_tag).replace("\\", "/")

            print(f"\nProcessing version: {version_tag}", flush=True)
            self.sftp_mkdirs(dest_root)
            total_src_files, total_dest_files = 0, 0

            for folder_name in self.folders_to_copy:
                src_path = os.path.join(src_root, folder_name)
                dest_path = os.path.join(dest_root, folder_name).replace("\\", "/")

                src_file_count = self.count_files_in_dir(src_path)
                total_src_files += src_file_count

                uploaded_count = self.sftp_upload_folder(src_path, dest_path)
                total_dest_files += uploaded_count
                print(f"Uploaded {uploaded_count}/{src_file_count} files → {folder_name}", flush=True)

            print(f"Version {version_tag}: Source={total_src_files}, Uploaded={total_dest_files}", flush=True)

        self.sftp.close()
        self.transport.close()
        print("\nSFTP connection closed.", flush=True)

    def run(self):
        if self.use_sftp:
            self.process_linux_upload()
        else:
            self.process_windows_copy()
        print("\nAll operations completed successfully!", flush=True)


if __name__ == "__main__":
    base_path = sys.argv[1]
    dest_base = sys.argv[2]
    #base_path = r'\\blackhawk\2017'
    #dest_base = r'\\o171-e001-ww03.eagleinvsys.com\Eagle_Install\Stage'
    uploadbinaries = EagleBulkUploadBinaries(base_path, dest_base)
    uploadbinaries.run()
