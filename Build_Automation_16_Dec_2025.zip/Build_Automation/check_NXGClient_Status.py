import os, sys
import emailNotification
from dotenv import load_dotenv

load_dotenv()

def check_NXGClient_log(hostname, sourcepath):
    if os.path.exists(sourcepath):
        list_of_files = os.listdir(sourcepath)
        for each_file in list_of_files:
            if each_file.endswith('.log') and len(each_file) > 15:
                each_file = sourcepath + '\\' + each_file
                print('Checking NXGClient build status in ' + each_file)
                fileName = open(each_file, 'r')
                readFile = fileName.read()
                if 'NxG Client -- Installation completed successfully' in readFile:
                    print('NxG Client -- Installation Successfully')
                if 'Product: NxG Client -- Installation failed' in readFile:
                    print('NxG Client -- Installation Failed')
                    emailNotification.send_mail('NxG Client -- Installation Failed - ' + hostname)
    else:
        print('Latest binary folder is missing in', hostname)
        emailNotification.send_mail('Latest NxG Client folder is missing in - ' + hostname)

def is_server_up(ip_addr):
    return os.system('ping -n 1 ' + ip_addr) == 0

build_version = os.environ.get('build_version')
hostname = sys.argv[1]
stagePath = sys.argv[2]
sourcepath = '\\\\' + hostname + '\\' + stagePath + '\\' + build_version + '\\EAGLE_PATCH\\Modules\\EagleUI'
print('Hostname :', hostname)
print('Build Version:', build_version)
print('Log Path :', sourcepath)

status = is_server_up(hostname)
if status == True:
    check_NXGClient_log(hostname, sourcepath)
else:
    print('Please check', hostname, 'is present in the network and try again.')