import os, sys
import emailNotification
from dotenv import load_dotenv

load_dotenv()

def check_EaglePatch_log(hostname, sourcepath):
    if os.path.exists(sourcepath):
        list_of_files = os.listdir(sourcepath)
        for each_file in list_of_files:
            if each_file.startswith('patchinstall_'):
                each_file = sourcepath + '\\' + each_file
                print('Checking patch status in ' + each_file)
                fileName = open(each_file, 'r')
                readFile = fileName.read()
                if 'Patch installation SUCCEEDED' in readFile:
                    print('Patch Applied Successfully')
                    #emailNotification.send_mail('Apply EaglePatch Success - ' + hostname)
                if 'Patch installation FAILED' in readFile:
                    print('Patch Applied Failed')
                    emailNotification.send_mail('Apply EaglePatch Failed - ' + hostname)
    else:
        print('Latest binary folder is missing in', hostname)
        emailNotification.send_mail('Latest EaglePatch folder is missing in - ' + hostname)

def is_server_up(ip_addr):
    return os.system('ping -n 1 ' + ip_addr) == 0

build_version = os.environ.get('build_version')
hostname = sys.argv[1]
stagePath = sys.argv[2]
sourcepath = '\\\\' + hostname + '\\' + stagePath + '\\' + build_version + '\\EAGLE_PATCH'
print('Hostname :', hostname)
print('Build Version:', build_version)
print('Log Path :', sourcepath)

status = is_server_up(hostname)
if status == True:
    check_EaglePatch_log(hostname, sourcepath)
else:
    print('Please check', hostname, 'is present in the network and try again.')