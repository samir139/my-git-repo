import winrm

session = winrm.Session('o171-i003-wr01.eagleinvsys.com', auth=('eagleinvsys\\farm', 'Welc@me20242024!'))
script = """
Get-WmiObject Win32_Service -Filter "Name='eventlog'" |
Select-Object Name, State, ProcessId, StartMode
"""
output = session.run_ps(script)
print(output.std_out.decode())