from pathlib import Path
import configparser, sys


def read_config_details(environment):
    try:
        config_filename = 'RunDeck_config_file_' + environment + '.ini'
        path = Path(config_filename)
        if path.is_file():
            print(f'The Configuration file {config_filename} is present.')
        else:
            print(f'The Configuration file {config_filename} missing please verify and re-apply the build')
    except OSError as error:
        print(f'The Configuration file {config_filename} missing please verify and re-apply the build')
        sys.exit(2)

    try:
        config = configparser.ConfigParser()
        config.read(config_filename)
        return config
    except IndexError:
        print('Unable to read the config file.')
        sys.exit(2)
