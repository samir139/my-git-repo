import paramiko, sys, os, platform, time, subprocess
from configparser import ConfigParser
from datetime import datetime
import tarfile
from dotenv import load_dotenv

load_dotenv()


def connection_execution(host, port, username, private_key_path, password, command):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        private_key = paramiko.RSAKey.from_private_key_file(private_key_path)
        ssh.connect(hostname=host, port=port, username=username, pkey=private_key)
        stdin, stdout, stderr = ssh.exec_command(command)
        for line in stdout:
            print(line.strip(), flush=True)
        print(stdout.read().decode(), flush=True)
        return ssh
    except:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(hostname=host, port=port, username=username, password=password)
        stdin, stdout, stderr = ssh.exec_command(command)
        for line in stdout:
            print(line.strip(), flush=True)
        print(stdout.read().decode(), flush=True)

def main(argv):
    now = datetime.now()
    try:
        host = sys.argv[1]
        command = sys.argv[2]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)
    #hostname = host.split('.')[0]
    for hostname in host.split(','):
        host = hostname.split('.')[0]
        print(host)
        build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
        print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        services_path = str(parser['BUILD_DIR']['servicesPath'])
        port = parser['REGION_DETAILS']['port']
        username = parser['REGION_DETAILS']['username']
        password = parser['REGION_DETAILS']['password']
        private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], host)
        #exec_command = 'cd /apps/eagle/eaglemgr' + ' && ' + cmd
        #connection_execution(hostname, port, username, private_key_path, password, exec_command)
        if command == 'STOP':
            exec_command = 'cd ' + services_path + ' && ' + './stop ALL'
            connection_execution(hostname, port, username, private_key_path, password, exec_command)
            print('Deleting log files.')
            log_path = str(parser['BUILD_DIR']['logPath'])
            exec_command = 'cd ' + log_path + ' && ' + "find /apps/eagle/logs -type f \( -name '*.log' -or -name '*.LOG' \) -exec rm -rf {} \;"
            connection_execution(hostname, port, username, private_key_path, password, exec_command)
            print('Deleting bkp files.')
            bkp_path = str(parser['BUILD_DIR']['bkpPath'])
            exec_command = 'cd ' + bkp_path + ' && ' + "find /apps/eagle/bkp/patch -type f \( -name '*.res' -or -name '*.rar' \) -mtime +1 -exec rm -rf {} \;"
            connection_execution(hostname, port, username, private_key_path, password, exec_command)
            exec_command = 'cd ' + log_path + ' && ' + "find /apps/eagle/data/msgcenter -type f -print | egrep '(processing|incoming)' | xargs rm -rf;"
            connection_execution(hostname, port, username, private_key_path, password, exec_command)
            exec_command = 'cd ' + log_path + ' && ' + "find /apps/eagle/data/msgcenter/out/XML/eagle_ml-2-0_default_cm_task_reporter/ini -type f -name '*.trigger' -exec rm -f {} \;"
            connection_execution(hostname, port, username, private_key_path, password, exec_command)
        if command == 'START':
            exec_command = 'cd ' + services_path + ' && ' + './start ALL'
            connection_execution(hostname, port, username, private_key_path, password, exec_command)
            time.sleep(60)
        if command == 'STATUS':
            exec_command = 'cd ' + services_path + ' && ' + './status ALL'
            connection_execution(hostname, port, username, private_key_path, password, exec_command)
        if command == 'RESTART':
            exec_command = 'cd ' + services_path + ' && ' + './restart ALL'
            connection_execution(hostname, port, username, private_key_path, password, exec_command)


if __name__ == "__main__":
    main(sys.argv)
