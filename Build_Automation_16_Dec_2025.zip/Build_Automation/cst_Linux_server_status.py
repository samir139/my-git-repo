import subprocess, sys

def ping_host(host):
    try:
        output = subprocess.run(["ping", "-n", "4", host], capture_output=True, text=True, timeout=5)
        if "Received = 4" in output.stdout:
            return host + " - Connected"
        else:
            return "Failed"
    except Exception as e:
        return "Error: " + {e}

host = sys.argv[1]
status = ping_host(host)
print(status)