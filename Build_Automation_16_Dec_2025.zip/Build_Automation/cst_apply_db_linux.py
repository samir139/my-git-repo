import paramiko, sys, os, platform, time, subprocess
from configparser import ConfigParser
from datetime import datetime
from dotenv import load_dotenv
import cst_get_jira_details

load_dotenv('.env')

def kill_sessions(host, port, username, password, sql_connect_cmd, PATH, LD_LIBRARY_PATH, ORACLE_HOME):
    kill_session_file = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'SQL_Scripts', 'KillSessions.sql')
    command = 'export PATH=' + PATH + '&& ' \
              'export LD_LIBRARY_PATH=' + LD_LIBRARY_PATH + ' && ' \
              'export ORACLE_HOME=' + ORACLE_HOME + ' && ' \
              'cd /apps/eagle/scripts/upgrade && ' \
              'sqlplus ' + sql_connect_cmd + ' @KillSessions.sql </dev/null'
    print(command)
    execute_command(host, port, username, password, command)

def run_sqlplus(sqlplus_script):
    print('Executing the DB user kill session.')
    p = subprocess.Popen(['sqlplus','/nolog'],stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (stdout,stderr) = p.communicate(sqlplus_script.encode('utf-8'))
    stdout_lines = stdout.decode('utf-8').split("\n")
    return stdout_lines

def execute_command(host, port, username, private_key_path, command):
    print('HOSTNAME :', host)
    print('USERNAME :', username)
    print('COMMAND :', command)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    private_key=paramiko.RSAKey.from_private_key_file(private_key_path)
    ssh.connect(hostname=host,port=port,username=username, pkey=private_key)
    stdin, stdout, stderr = ssh.exec_command(command)
    for line in stdout:
        print(line.strip(), flush=True)
    print(stdout.read().decode(), flush=True)
    return ssh

def check_path_status(host, port, username, private_key_path, remote_path):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        private_key = paramiko.RSAKey.from_private_key_file(private_key_path)
        ssh.connect(hostname=host, port=port, username=username, pkey=private_key)
        command = f'if [ -e "{remote_path}" ]; then echo "exists"; else echo "not exists"; fi'
        stdin, stdout, stderr = ssh.exec_command(command)
        output = stdout.read().decode().strip()
        return output
    except Exception as e:
        print('Error: ', e)

now = datetime.now()
try:
    host = sys.argv[1]
except IndexError:
    print('No Environment Variable passed for applying build. Please provide the Environment Name.')
    sys.exit(2)

apply_edm = os.environ.get('apply_edm')
apply_pkg = os.environ.get('apply_pkg')
build_details, build_version, build_number, build_status, startx_path = cst_get_jira_details.get_jira_details(host)
#build_version = os.path.basename(startx_path)
release_dir = host[0:host.find('-', host.find('-') + 1)] + '_release_dir'
build_version = os.environ.get(release_dir)
print('BUILD GOING TO BE APPLIED IN', host, 'IS', build_version)

build_ini_file = host[0:host.find('-', host.find('-')+1)] + '.ini'
print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))

port = parser['REGION_DETAILS']['port']
username = parser['REGION_DETAILS']['username']
password = os.path.join(parser['REGION_DETAILS']['privatekey'], host.split('.')[0])

upgrade_path = parser['BUILD_DIR']['stagingAppPath']
print('Upgrade Path is', upgrade_path)

sql_connect_cmd = 'sys' + '/' + parser['DB_PRE_CHECK']['syspwd'] + '@' + parser['DB_PRE_CHECK']['db_name'] + ' as sysdba'

edm_path = os.path.join(str(parser['BUILD_DIR']['stagingAppPath']) +
                        str(build_version) +
                        '/DATABASE/eagle_erd_' +
                        str(build_version)[7:None] + '/oracle')

if check_path_status(host, port, username, password, edm_path) == 'exists':
    print('Applying EDM Started')
    #copy_edm_files_cmd = 'cd ' + parser['BUILD_DIR']['stagingAppPath'] + ' && cp -r edm* ' + edm_path
    #print('Copying EDM Control Files :', copy_edm_files_cmd)
    #execute_command(host, port, username, password, copy_edm_files_cmd)
    
    move_to_edm_loc = 'cd ' + edm_path
    print('Move to EDM Stage Location :', move_to_edm_loc)
    execute_command(host, port, username, password, move_to_edm_loc)
    
    exec_dos2unix = move_to_edm_loc + ' && dos2unix *.sh *.txt'
    print('Changing mode to Dos2Unix :', exec_dos2unix)
    execute_command(host, port, username, password, exec_dos2unix)
    
    exec_chmod = move_to_edm_loc + ' && chmod +x *.sh *.txt'
    print('Change permission of control files :', exec_chmod)
    execute_command(host, port, username, password, exec_chmod)
    
    execute_command(host, port, username, password, move_to_edm_loc + '&& ls -l *.sh *.txt')
    
    kill_sessions(host, port, username, password, sql_connect_cmd,
                  str(parser['EXPORT_ORACLE']['PATH']),
                  str(parser['EXPORT_ORACLE']['LD_LIBRARY_PATH']),
                  str(parser['EXPORT_ORACLE']['ORACLE_HOME']))
    
    exec_edm_schemas = 'export PATH=' + parser['EXPORT_ORACLE']['PATH'] + '&& ' \
                                                                          'export LD_LIBRARY_PATH=' + parser['EXPORT_ORACLE']['LD_LIBRARY_PATH'] + ' && ' \
                                                                          'export ORACLE_HOME=' + parser['EXPORT_ORACLE']['ORACLE_HOME'] + ' && ' \
                                                                          'cd '+ edm_path +' && ./edm_schemas.sh'
    print("EDM SCHEMAS START TIME:", datetime.now().strftime(("%d/%m/%Y %H:%M:%S")))
    execute_command(host, port, username, password, exec_edm_schemas)
    print("EDM SCHEMAS END TIME:", datetime.now().strftime(("%d/%m/%Y %H:%M:%S")))
    
    kill_sessions(host, port, username, password, sql_connect_cmd,
                  str(parser['EXPORT_ORACLE']['PATH']),
                  str(parser['EXPORT_ORACLE']['LD_LIBRARY_PATH']),
                  str(parser['EXPORT_ORACLE']['ORACLE_HOME']))
    
    exec_edm_setup = 'export PATH=' + parser['EXPORT_ORACLE']['PATH'] + '&& ' \
                     'export LD_LIBRARY_PATH=' + parser['EXPORT_ORACLE']['LD_LIBRARY_PATH'] + ' && ' \
                     'export ORACLE_HOME=' + parser['EXPORT_ORACLE']['ORACLE_HOME'] + ' && ' \
                     'cd '+ edm_path +' && ./edm_setup.sh'
    print("EDM SETUP START TIME:", datetime.now().strftime(("%d/%m/%Y %H:%M:%S")))
    execute_command(host, port, username, password, exec_edm_setup)
    print("EDM SETUP END TIME:", datetime.now().strftime(("%d/%m/%Y %H:%M:%S")))

pkg_path = os.path.join(str(parser['BUILD_DIR']['stagingAppPath']) +
                        str(build_version) +
                        '/DATABASE/packages_' +
                        str(build_version)[7:None] + '/oracle')

if check_path_status(host, port, username, password, pkg_path) == 'exists':
    print('Applying Package Started.')
    #copy_pkg_files_cmd = 'cd ' + parser['BUILD_DIR']['stagingAppPath'] + ' && cp -r packages_input_control_file.txt ' + pkg_path
    #print('Copying PKG Control Files :', copy_pkg_files_cmd)
    #execute_command(host, port, username, password, copy_pkg_files_cmd)
    
    move_to_pkg_loc = 'cd ' + pkg_path
    print('Move to PKG Stage Location :', move_to_pkg_loc)
    execute_command(host, port, username, password, move_to_pkg_loc)
    
    exec_dos2unix = move_to_pkg_loc + ' && dos2unix *.sh *.txt'
    print('Changing mode to Dos2Unix :', exec_dos2unix)
    execute_command(host, port, username, password, exec_dos2unix)
    
    exec_chmod = move_to_pkg_loc + ' && chmod +x *.sh *.txt'
    print('Change permission of control files :', exec_chmod)
    execute_command(host, port, username, password, exec_chmod)
    
    execute_command(host, port, username, password, move_to_pkg_loc + '&& ls -l *.sh *.txt')
    
    kill_sessions(host, port, username, password, sql_connect_cmd,
                  str(parser['EXPORT_ORACLE']['PATH']),
                  str(parser['EXPORT_ORACLE']['LD_LIBRARY_PATH']),
                  str(parser['EXPORT_ORACLE']['ORACLE_HOME']))
    
    exec_compile_all_packages = 'export PATH=' + parser['EXPORT_ORACLE']['PATH'] + '&& ' \
                                'export LD_LIBRARY_PATH=' + parser['EXPORT_ORACLE']['LD_LIBRARY_PATH'] + ' && ' \
                                'export ORACLE_HOME=' + parser['EXPORT_ORACLE']['ORACLE_HOME'] + ' && ' \
                                'cd '+ pkg_path +' && ./install_application_db_ora.sh'
    
    print("COMPILE PACKAGE START TIME:", datetime.now().strftime(("%d/%m/%Y %H:%M:%S")))
    execute_command(host, port, username, password, exec_compile_all_packages)
    print("COMPILE PACKAGE END TIME:", datetime.now().strftime(("%d/%m/%Y %H:%M:%S")))
