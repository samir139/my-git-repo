import paramiko, sys, os, platform, time, subprocess
from configparser import ConfigParser
from datetime import datetime
import tarfile
import cst_get_jira_details
from dotenv import load_dotenv

load_dotenv()


def connection_execution(host, port, username, private_key_path, command):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        private_key = paramiko.RSAKey.from_private_key_file(private_key_path)
        ssh.connect(hostname=host, port=port, username=username, pkey=private_key)
        stdin, stdout, stderr = ssh.exec_command(command)
        for line in stdout:
            print(line.strip(), flush=True)
        print(stdout.read().decode(), flush=True)
        return ssh
    except Exception as e:
            print(e)


now = datetime.now()
try:
    host = sys.argv[1]
except IndexError:
    print('No Environment Variable passed for applying build. Please provide the Environment Name.')
    sys.exit(2)

hostname = host.split('.')[0]
build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
build_details, build_version, build_number, build_status, startx_path = cst_get_jira_details.get_jira_details(host)
release_dir = host[0:host.find('-', host.find('-') + 1)] + '_release_dir'
build_version = os.environ.get(release_dir)
# stagingAppPath = os.path.join(parser['BUILD_DIR']['stagingAppPath'], os.path.basename(startx_path) + '/EAGLE_PATCH/')
stagingAppPath = os.path.join(parser['BUILD_DIR']['stagingAppPath'], build_version + '/EAGLE_PATCH/')
print('Stage Path for ', host, ' is ', stagingAppPath)
port = parser['REGION_DETAILS']['port']
username = parser['REGION_DETAILS']['username']
private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], hostname)
list_files_exec_command = 'cd ' + stagingAppPath + ' && ls -l'
connection_execution(host, port, username, private_key_path, list_files_exec_command)
permission_2_exec_command = 'chmod -R 777 ' + stagingAppPath
connection_execution(host, port, username, private_key_path, permission_2_exec_command)
dos2unix_exec_command = 'cd ' + stagingAppPath + ' && ' + 'dos2unix *.sh *.ini'
connection_execution(host, port, username, private_key_path, dos2unix_exec_command)
chmod_exec_command = 'cd ' + stagingAppPath + ' && ' + 'chmod +x *.sh *.ini'
connection_execution(host, port, username, private_key_path, chmod_exec_command)
exec_command_patch = 'cd ' + stagingAppPath + ' && ' + './setup.sh'
connection_execution(host, port, username, private_key_path, exec_command_patch)
