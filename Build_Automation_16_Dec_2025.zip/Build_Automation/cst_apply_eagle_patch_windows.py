import os, sys, winrm, glob
from configparser import ConfigParser
from datetime import datetime
import fileHandling
import emailNotification
import cst_get_jira_details
from dotenv import load_dotenv

load_dotenv()


def readKeyStorage(winPrivateKey):
    with open(winPrivateKey, 'r') as file:
        password = file.read()
    return password

def Apply_EaglePatch(conn, patch_loc, stage_loc, hostname, StaticConfig, INSTDIR_EMShell):
    print('Apply Eagle Patch')
    if os.path.exists(patch_loc):
        path_ini = os.path.join(patch_loc + '\\eaglepatch.ini')
        path_exe = os.path.join(stage_loc + '\\eaglepatch.exe')
        if os.path.isfile(path_ini):
            try:
                start_time = datetime.now().time().strftime('%H:%M:%S')
                fileHandling.replace_string(path_ini, "SilentMode=0", "SilentMode=1")
                fileHandling.replace_string(path_ini, "Delta=1", "Delta=0")
                fileHandling.replace_string(path_ini, "SkipBackup=0", "SkipBackup=1")
                fileHandling.replace_string(path_ini, "ServiceShutdown=1", "ServiceShutdown=0")
                fileHandling.replace_string(path_ini, "~/eagle/eaglemgr/config/eaglepatch.ini", StaticConfig)
                fileHandling.replace_string(path_ini, "~/eagle/", INSTDIR_EMShell)
                print('Started applying Eagle Patch', hostname, start_time)
                result = conn.run_ps(path_exe)
                output = result.std_out.decode()
                print(output)
                end_time = datetime.now().time().strftime('%H:%M:%S')
                if result.status_code == 0:
                    print('Completed applying Eagle Patch', hostname, end_time)
                else:
                    print("failed to run eaglepatch.exe File ")
                total_time = (datetime.strptime(end_time, '%H:%M:%S') - datetime.strptime(start_time, '%H:%M:%S'))
                print('Total time taken to apply Eagle Patch', hostname, str(total_time))
            except OSError as error:
                print('Failed to apply Eagle Patch', hostname)
                print(str(error))
        else:
            print('Failed to apply Eagle Patch, as file not found in', hostname)
        fileHandling.check_patching_status(patch_loc, hostname)
    else:
        print(hostname, ' : EAGLEPATCH Folder Missing.')

def check_EaglePatch_log(hostname, sourcepath):
    if os.path.exists(sourcepath):
        list_of_files = os.listdir(sourcepath)
        for each_file in list_of_files:
            if each_file.startswith('patchinstall_'):
                each_file = sourcepath + '\\' + each_file
                print('Checking patch status in ' + each_file)
                fileName = open(each_file, 'r')
                readFile = fileName.read()
                if 'Patch installation SUCCEEDED' in readFile:
                    print('Patch Applied Successfully')
                    #emailNotification.send_mail('Apply EaglePatch Success - ' + hostname)
                if 'Patch installation FAILED' in readFile:
                    print('Patch Applied Failed')
                    emailNotification.send_mail('Apply EaglePatch Failed - ' + hostname)
    else:
        print('Latest binary folder is missing in', hostname)
        emailNotification.send_mail('Latest EaglePatch folder is missing in - ' + hostname)


type = sys.argv[1]
host = sys.argv[2]
build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
print(build_ini_file)
print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
build_details, build_version, build_number, build_status, startx_path =  cst_get_jira_details.get_jira_details(host)
#build_version = os.path.basename(startx_path)
release_dir = host[0:host.find('-', host.find('-') + 1)] + '_release_dir'
build_version = os.environ.get(release_dir)

if type == 'APP':
    username = parser['APP_TIER_DETAIL']['username']
    winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
    password = readKeyStorage(winPrivateKey)
    try:
        conn = winrm.Session(host,auth=(username,password),transport='ntlm')
        print('Connection Established to', host)
    except Exception as error:
        print('Failed to Establish Connection to', host)
    StaticConfig = parser['APP_TIER_DETAIL']['StaticConfig']
    INSTDIR_EMShell = parser['APP_TIER_DETAIL']['INSTDIR_EMShell']
    stage_loc = os.path.join(parser['APP_TIER_DETAIL']['stagePath'],os.path.basename(startx_path), 'EAGLE_PATCH')
    patch_loc = os.path.join('\\\\', host, 'Eagle_Install\\Stage', os.path.basename(startx_path), 'EAGLE_PATCH')
    print(patch_loc)
    Apply_EaglePatch(conn, patch_loc, stage_loc, host, StaticConfig, INSTDIR_EMShell)
    check_EaglePatch_log(host, patch_loc)

if type == 'RPT':
    username = parser['REPORT_TIER_DETAIL']['username']
    winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
    password = readKeyStorage(winPrivateKey)
    try:
        conn = winrm.Session(host,auth=(username,password),transport='ntlm')
        print('Connection Established to', host)
    except Exception as error:
        print('Failed to Establish Connection to', host)
    StaticConfig = parser['REPORT_TIER_DETAIL']['StaticConfig']
    INSTDIR_EMShell = parser['REPORT_TIER_DETAIL']['INSTDIR_EMShell']
    stage_loc = os.path.join(parser['REPORT_TIER_DETAIL']['stagePath'],os.path.basename(startx_path), 'EAGLE_PATCH')
    patch_loc = os.path.join('\\\\', host, 'Eagle_Install\\Stage', os.path.basename(startx_path), 'EAGLE_PATCH')
    print(patch_loc)
    Apply_EaglePatch(conn, patch_loc, stage_loc, host, StaticConfig, INSTDIR_EMShell)
    check_EaglePatch_log(host, patch_loc)

if type == 'WEB':
    username = parser['WEB_TIER_DETAIL']['username']
    winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
    password = readKeyStorage(winPrivateKey)
    try:
        conn = winrm.Session(host,auth=(username,password),transport='ntlm')
        print('Connection Established to', host)
    except Exception as error:
        print('Failed to Establish Connection to', host)
    StaticConfig = parser['WEB_TIER_DETAIL']['StaticConfig']
    INSTDIR_EMShell = parser['WEB_TIER_DETAIL']['INSTDIR_EMShell']
    stage_loc = os.path.join(parser['WEB_TIER_DETAIL']['stagePath'],os.path.basename(startx_path), 'EAGLE_PATCH')
    patch_loc = os.path.join('\\\\', host, 'Eagle_Install\\Stage', os.path.basename(startx_path), 'EAGLE_PATCH')
    print(patch_loc)
    Apply_EaglePatch(conn, patch_loc, stage_loc, host, StaticConfig, INSTDIR_EMShell)
    check_EaglePatch_log(host, patch_loc)
