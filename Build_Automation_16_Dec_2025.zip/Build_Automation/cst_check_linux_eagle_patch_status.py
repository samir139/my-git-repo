import paramiko, sys, os, platform, time, subprocess
from configparser import ConfigParser
from datetime import datetime
import tarfile
from cst_get_jira_details import get_jira_details
import emailNotification
from dotenv import load_dotenv

load_dotenv()

def validate_log(hostname, log_status):
    print('Validating Eagle Patch Status in ' + log_status + ' for : ', hostname)
    if 'PATCH INSTALLATION SUCCEEDED' in log_status or 'Installation SUCCEEDED' in log_status:
        print('Patch Applied Successfully')
    #    emailNotification.send_mail('Apply EaglePatch Success - ' + hostname)
    if 'Patch installation FAILED' in log_status or 'PATCH INSTALLATION FAILED' in log_status:
        print('Patch Applied Failed')
        emailNotification.send_mail('Apply EaglePatch Failed - ' + hostname)

def connection_execution(host, port, username, private_key_path, command):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        private_key = paramiko.RSAKey.from_private_key_file(private_key_path)
        ssh.connect(hostname=host, port=port, username=username, pkey=private_key)
        stdin, stdout, stderr = ssh.exec_command(command)
        output = stdout.read().decode('utf-8')
        print(output)
        validate_log(host, output.strip())
    except:
        print('Error.')

try:
    host = sys.argv[1]
except IndexError:
    print('Please provide the server name as a parameter')
    sys.exit(2)

hostname = host.split('.')[0]
build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
build_details, build_version, build_number, build_status, startx_path =  get_jira_details(hostname)
build_version = os.path.basename(startx_path)
stagingAppPath = os.path.join(parser['BUILD_DIR']['stagingAppPath'], os.environ.get('build_version') + '/EAGLE_PATCH/')
port = parser['REGION_DETAILS']['port']
username = parser['REGION_DETAILS']['username']
private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], hostname)
if 'eagleinvsys' in host:
    success_exec_log = 'cd ' + stagingAppPath + ' && ' + "find . -name 'patchinstall_*' -exec grep -i 'PATCH INSTALLATION SUCCEEDED' {} \\;"
    connection_execution(host, port, username, private_key_path, success_exec_log)
if 'eagleinvsys' in host:
    failed_exec_log = 'cd ' + stagingAppPath + ' && ' + "find . -name 'patchinstall_*' -exec grep -i 'PATCH INSTALLATION FAILED' {} \\;"
    connection_execution(host, port, username, private_key_path, failed_exec_log)
if 'eagleaccess' in host:
    success_exec_log = 'cd ' + stagingAppPath + ' && ' + "find . -name 'patchinstall_*' -exec grep -i 'Installation SUCCEEDED' {} \\;"
    connection_execution(host, port, username, private_key_path, success_exec_log)
if 'eagleaccess' in host:
    failed_exec_log = 'cd ' + stagingAppPath + ' && ' + "find . -name 'patchinstall_*' -exec grep -i 'Patch installation FAILED' {} \\;"
    connection_execution(host, port, username, private_key_path, failed_exec_log)
