import os, sys

def check_share_access(share_path):
    if os.path.exists(share_path):
        return "Win Share Path : " + share_path + " - is Accessible"
    else:
        return "Not Accessible"

hostname = sys.argv[1]
win_path = sys.argv[2]
share_path = '\\\\' + hostname + '\\' + win_path
status = check_share_access(share_path)
print(status)