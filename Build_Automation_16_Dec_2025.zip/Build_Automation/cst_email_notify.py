import os, smtplib,sys
import cst_get_jira_details
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from configparser import ConfigParser
from dotenv import load_dotenv
load_dotenv()

parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)),'configurations','emailnotification.ini'))

def send_mail(subject, body):
    msg = MIMEMultipart()
    sender = parser['Email_Alert']['deploy_sender']
    recipients = parser['Email_Alert']['recipients']
    smtpServer = parser['Email_Alert']['smtpServer']
    more_recipients = parser['Email_Alert']['more_recipients']
    msg['Subject'] = subject
    msg['From'] = sender
    msg['To'] = recipients
    msg['cc'] = more_recipients
    msg.attach(MIMEText(body, "plain"))
    s = smtplib.SMTP(smtpServer)
    try:
        s.sendmail(sender, msg["To"].split(","), msg.as_string())
        print('Message Sent Succesfully to', recipients)
    except:
        print('There Was An Error Sending The Message')
    s.quit()

build_details, build_version, build_number, build_status = cst_get_jira_details.get_jira_details()
print('Build Version :', build_version)
print('Build Number :', build_number)

regionname = 'EA-SMART 2017R2.x'
mail_type  = 'Down'

if mail_type == 'Down':
    mail_subject = regionname + ' environment will go down for upgrade'
    body = 'Hi Team, \r\n\r\n The region ' + regionname + ' is going down to apply the latest build. \r\n\r\n Thanks,\r\n Regression Operations Team'
if mail_type == 'Online':
    mail_subject = regionname + ' environment is UP and RUNNING'
    body = 'Hi Team, \r\n\r\n The region ' + regionname + ' is back online after applying the latest build. \r\n\r\n Thanks,\r\n Regression Operations Team'

send_mail(mail_subject, body)