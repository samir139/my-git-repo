from jira import JIRA, JIRAError
import re, os, sys
from configparser import ConfigParser
from dotenv import load_dotenv
load_dotenv()


def get_jira_details(host):
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)),'configurations','jiradetails.ini'))
    jira_server = parser['GET_JIRA']['jira_server']
    jira_uid = parser['GET_JIRA']['jira_uid']
    jira_token = parser['GET_JIRA']['jira_token']
    jiraOptions = {'server': jira_server}
    try:
        jira = JIRA(options=jiraOptions, basic_auth=(jira_uid, jira_token))
        print("Authentication successful to Atlassian Website")
        build_region = host[0:host.find('-', host.find('-') + 1)] + '_build_id'
        build_id = os.environ.get(build_region)
        print('Build Region    :', build_region)
        print('Build ID        :', build_id)
        try:
            build_version = str('Eagle_V' + jira.issue(build_id).fields.summary.replace(" ", ""))
            build_status = str(jira.issue(build_id).fields.status)
        except:
            print('No Build ID with ' + build_id + ' found in JIRA Board.')
        a=int(0)
        try:
            for i in jira.comments(build_id):
                if int(i.id)>a:
                    a = int(i.id)

            build_details = jira.comment(build_id,a).body
            for line in build_details.splitlines():
                if "Dailybuilds" in line:
                    startx_path = line
                    #print('Daily Build Loc :', line)
                    match = re.search(r'([^\\]+)$', line)
                    if match:
                        print('Build Version   :', match.group(1))
                        break
            count = len(jira.comments(build_id))
            for i in range(count,0,-1):
                build_details = jira.comment(build_id,jira.comments(build_id)[i-1]).body
                if re.findall("Build:",build_details,re.MULTILINE):
                    for line in build_details.splitlines():
                        if "Build" in line:
                            build_number = line
                            print("Build Number :", build_number)
                            break
                    return build_details.replace('*',''), build_version, build_number, build_status, startx_path
                    break
        except Exception as e:
            print('No Comments found for the ' + build_id + ' in the JIRA ticket.')
    except JIRAError as e:
        print("Auth failed: Site temporarily unavailable")
    except Exception as e:
        print("Auth failed: Site temporarily unavailable")


#host = sys.argv[1]
#try:
#    build_details, build_version, build_number, build_status, startx_path = get_jira_details(host)
#    print('Build Number    :', build_number)
#    print('Build Version   :', build_version)
#    print('Build Status    :', build_status)
#    print('Daily Build Loc :', startx_path)
#    print('Build Details   : \n', build_details)
#except:
#    print('There is an issue connecting to Confluence/Altassian Page.')
