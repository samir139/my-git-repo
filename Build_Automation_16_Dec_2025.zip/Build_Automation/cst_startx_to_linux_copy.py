import paramiko, sys, os, platform, time, subprocess
from configparser import ConfigParser
from datetime import datetime
import tarfile
import cst_get_jira_details
from dotenv import load_dotenv

load_dotenv()


def connection_execution(host, port, username, private_key_path, command):
    print('HOSTNAME :', host)
    print('USERNAME :', username)
    print('COMMAND :', command)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    private_key=paramiko.RSAKey.from_private_key_file(private_key_path)
    ssh.connect(hostname=host,port=port,username=username, pkey=private_key)
    stdin, stdout, stderr = ssh.exec_command(command)
    for line in stdout:
        print(line.strip(), flush=True)
    print(stdout.read().decode(), flush=True)
    return ssh


now = datetime.now()
try:
    host = sys.argv[1]
    hostnames=sys.argv[2]
except IndexError:
    print('No Environment Variable passed for applying build. Please provide the Environment Name.')
    sys.exit(2)

build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
nfs_path = str(parser['BUILD_DIR']['nfsPath'])
load_dotenv()
build_details, build_version, build_number, build_status, startx_path =  cst_get_jira_details.get_jira_details(host)
#build_version = os.path.basename(startx_path)
release_dir = host[0:host.find('-', host.find('-') + 1)] + '_release_dir'
build_version = os.environ.get(release_dir)
port = parser['REGION_DETAILS']['port']
username = parser['REGION_DETAILS']['username']
private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], host.split('.')[0])
date_string = now.strftime("%d-%m-%Y")
new_name = build_version + '_' + date_string
print(new_name)
print("***********************************************************")
print('REMOVING EXISTING DIRECTORY NFS PATH')
print("***********************************************************")
exec_chg_user = 'sudo su - eagle'
connection_execution(host, port, username, private_key_path, exec_chg_user)
exec_remove_directory = 'cd ' + nfs_path + ' && rm -rf ' + build_version
connection_execution(host, port, username, private_key_path, exec_remove_directory)

print("***********************************************************")
print('REMOVING DIRECTORY COMPLETED NFS PATH')
print("***********************************************************")

tar_file_name = 'eagle_access' + '.tar'
print('TAR FILE CREATED:', tar_file_name)
tarf = tarfile.open(tar_file_name, 'w')
for root, dirs, files in os.walk(startx_path):
    for file in files:
        file_path = os.path.join(root, file)
        tarf.add(file_path, arcname=os.path.relpath(file_path, startx_path))
tarf.close()
destination = nfs_path + build_version + '/'
print(destination)
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
private_key = paramiko.RSAKey.from_private_key_file(private_key_path)
ssh.connect(hostname=host, port=port, username=username, pkey=private_key)
sftp = ssh.open_sftp()
try:
    sftp.stat(destination)
except FileNotFoundError:
    sftp.mkdir(destination)
print("***********************************************************")
print('COPYING TAR FILE STARTED TO NFS PATH')
print("***********************************************************")
sftp.put(tar_file_name, destination + tar_file_name)
print("***********************************************************")
print('COPYING TAR FILE COMPLETED IN NFS PATH')
print("***********************************************************")
exec_untar = 'cd ' + destination + ' && tar -xvf ' + tar_file_name
connection_execution(host, port, username, private_key_path, exec_untar)

exec_fullpermission = 'cd ' + destination + ' && chmod -R 777 ' + tar_file_name
connection_execution(host, port, username, private_key_path, exec_fullpermission)
print("***********************************************************")
print('UNTAR IS COMPLETED')
print("***********************************************************")
exec_remove_tar = 'cd ' + destination + ' && rm -rf ' + tar_file_name + ' && ls -l'
connection_execution(host, port, username, private_key_path, exec_remove_tar)
print("***********************************************************")
print('BINARIES COPY COMPLETED TO NFS LOCATION')
print("***********************************************************")
print('STARTING THE FILE COPY FROM NFS PATH TO STAGE PATH OF EACH LINUX BOX')
print("***********************************************************")
for host in hostnames.split(','):
    build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
    print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    hostname = host.split('.')[0]
    stage_path = str(parser['BUILD_DIR']['stagingAppPath'])
    nfs_path = str(parser['BUILD_DIR']['nfsPath'])
    destination = str(parser['BUILD_DIR']['stagingAppPath'])
    date_string = now.strftime("%d-%m-%Y")
    new_name = build_version + '_' + date_string
    port = parser['REGION_DETAILS']['port']
    username = parser['REGION_DETAILS']['username']
    private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], hostname)
    print("***********************************************************")
    print('RENAMING THE EXISTING DIRECTORY IN : ', host)
    print("***********************************************************")
    exec_chg_user = 'sudo su - eagle'
    connection_execution(host, port, username, private_key_path, exec_chg_user)
    exec_rename_directory = 'cd ' + stage_path + ' && mv ' + build_version + ' ' + new_name + ' && ls -l'
    connection_execution(host, port, username, private_key_path, exec_rename_directory)
    print("***********************************************************")
    print('RENAME DIRECTORY COMPLETED IN :', host)
    print("***********************************************************")
    print("***********************************************************")
    print('COPY FILES FROM NFS TO STAGING PATH:', host)
    print("***********************************************************")
    exec_copy_command = 'cp -r ' + nfs_path + build_version + ' ' + destination
    connection_execution(host, port, username, private_key_path, exec_copy_command)
    print('CHANGE FOLDER PERMISSION FOR :', build_version, 'IN', host)
    print("***********************************************************")
    exec_fullpermission = 'cd ' + destination + ' && chmod -R 777 ' + build_version
    connection_execution(host, port, username, private_key_path, exec_fullpermission)
    print("***********************************************************")
    print('COPY FILES FROM NFS TO STAGING PATH COMPLETED IN :', host)
    print("***********************************************************")
    print("***********************************************************")
    print('CHECK THE DIRECTORY FILES OR COPIED OR NOT IN :', host)
    print("***********************************************************")
    exec_check_command = 'cd ' + destination + build_version + ' && ls -l'
    connection_execution(host, port, username, private_key_path, exec_check_command)
    print("***********************************************************")
    print('CHECKING COMPLETED IN :', host)
    print("***********************************************************")