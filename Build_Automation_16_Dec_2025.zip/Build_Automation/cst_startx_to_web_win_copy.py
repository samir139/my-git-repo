import os, shutil, sys, subprocess, re
from datetime import datetime
from configparser import ConfigParser
from dotenv import load_dotenv
load_dotenv('.env')
import cst_get_jira_details


def readKeyStorage(winPrivateKey):
    with open(winPrivateKey, 'r') as file:
        password = file.read()
    return password


def rename_existing_folder(share_path, username, password, oldname):
    create_time = os.path.getmtime(share_path)
    format_time = datetime.fromtimestamp(create_time).strftime('%m-%d-%Y-%H.%M.%S')
    newname = oldname + '_' + format_time
    oldpath = os.path.join(share_path, oldname)
    newpath = os.path.join(share_path, newname)
    try:
        shutil.move(oldpath, newpath)
        print("Renamed folder " + oldpath + " to " + newpath)
    except FileNotFoundError:
        print('the specified folder does not exist.')
    except FileExistsError:
        print('A folder with the the new name already exists')


now = datetime.now()
try:
    host = sys.argv[1]
    match = re.match(r"([\w-]+)\.", host)
    if match: host = match.group(1)
except IndexError:
    print('No Environment Variable passed for applying build. Please provide the Environment Name.')
    sys.exit(2)

build_details, build_version, build_number, build_status, startx_path =  cst_get_jira_details.get_jira_details(host)
#build_version = os.path.basename(startx_path)
release_dir = host[0:host.find('-', host.find('-') + 1)] + '_release_dir'
build_version = os.environ.get(release_dir)
print("Build Version : ", build_version)
build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
    print(build_ini_file, 'file present.')
else:
    print(build_ini_file, 'file missing.')
    sys.exit(2)
parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
root_stage_patch = os.path.join(startx_path, 'EAGLE_PATCH')
username = parser['WEB_TIER_DETAIL']['username']
winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
password = readKeyStorage(winPrivateKey)

section_name = 'WEB_TIER_PATH'
if section_name in parser.sections():
    for option in parser.options(section_name):
        staging_path = parser.get(section_name, option)

        try:
            print('Changing Staging Folders in  server START TIME :',
                  datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
            print(staging_path)
            rename_existing_folder(staging_path, username, password, build_version)
            print('Changing Staging Folders in server END TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
            print('Creating Staging Folders in server START TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
            destination = os.path.join(staging_path, build_version, 'EAGLE_PATCH')
            print('Copying Staging files from DailyBuilds location to Staging Location START TIME :', destination,
                  datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
            shutil.copytree(root_stage_patch, destination)
            print('Copying Staging files from DailyBuilds location to Staging Location END TIME :', destination,
                  datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
        except Exception as e:
            print('There is exception while copying to :', e)
else:
    print("section name name not present in ini file")