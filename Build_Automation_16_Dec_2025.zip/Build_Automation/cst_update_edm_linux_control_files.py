import sys, os, paramiko, re, time
from configparser import ConfigParser
import passwordUtility
import cst_get_jira_details
from dotenv import load_dotenv
load_dotenv()


def connection_execution(host, port, username, private_key_path, command):
    print('Command running in ' + host + ' is ' + command)
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        private_key = paramiko.RSAKey.from_private_key_file(private_key_path)
        ssh.connect(hostname=host, port=port, username=username, pkey=private_key)
        stdin, stdout, stderr = ssh.exec_command(command)
        for line in stdout:
            print(line.strip(), flush=True)
        print(stdout.read().decode(), flush=True)
        return ssh
    except:
        print('No file found to be updated')


def updatecontolfile(ctrlfilepath, search_string, replace_string, controlfile, hostname, port, username, private_key_path):
    exec_script = "cd " + ctrlfilepath + ";sed -i '/^" + search_string + "/s/|.*/|" + replace_string + "/' " + controlfile
    #print('Executing script : ' + exec_script + ' in ' + hostname)
    connection_execution(hostname, port, username, private_key_path, exec_script)
    print('Line starting with ' + search_string + ' is updated successfully at ' + ctrlfilepath + '/' + controlfile + ' in ' + hostname)
    time.sleep(5)


src_edm_schema_file = 'sample_edm_input_control_file_schemas.txt'
src_edm_setup_file = 'sample_edm_input_control_file_setup.txt'
src_edm_slice_file = 'sample_edm_slice_control_file.txt'
src_pkg_file = 'sample_packages_input_control_file.txt'

hostname = sys.argv[1]
build_ini_file = hostname[0:hostname.find('-', hostname.find('-') + 1)] + '.ini'
print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
username = parser['REGION_DETAILS']['username']
port = parser['REGION_DETAILS']['port']
private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], hostname.split('.')[0])
print("Updating the eaglepatch.ini file for", hostname)
print("Username:", username)
build_details, build_version, build_number, build_status, startx_path =  cst_get_jira_details.get_jira_details(hostname)
#build_version = os.path.basename(startx_path)
release_dir = hostname[0:hostname.find('-', hostname.find('-') + 1)] + '_release_dir'
build_version = os.environ.get(release_dir)
version = build_version.removeprefix('Eagle_V')
print('Build Version : ', build_version)
edm_path = '/apps/eagle/software/stage/' + build_version + '/DATABASE/eagle_erd_' + version + '/oracle'
pkg_path = '/apps/eagle/software/stage/' + build_version + '/DATABASE/packages_' + version + '/oracle'

# Create control files from sample files
upd_schema_file = 'cd ' + edm_path + ';cp -f ' + src_edm_schema_file + ' ' + src_edm_schema_file.removeprefix('sample_')
print('Executing command', upd_schema_file, 'and update edm_input_control_file_schemas txt file in ' + hostname)
connection_execution(hostname, port, username, private_key_path, upd_schema_file)

upd_setup_file = 'cd ' + edm_path + ';cp -f ' + src_edm_setup_file + ' ' + src_edm_setup_file.removeprefix('sample_')
print('Executing command', upd_setup_file, 'and update edm_input_control_file_setup txt file in ' + hostname)
connection_execution(hostname, port, username, private_key_path, upd_setup_file)

upd_slice_file = 'cd ' + edm_path + ';cp -f ' + src_edm_slice_file + ' ' + src_edm_slice_file.removeprefix('sample_')
print('Executing command', upd_slice_file, 'and update edm_slice_control_file txt file in ' + hostname)
connection_execution(hostname, port, username, private_key_path, upd_slice_file)

upd_pkg_file = 'cd ' + pkg_path + ';cp -f ' + src_pkg_file + ' ' + src_pkg_file.removeprefix('sample_')
print('Executing command', upd_pkg_file, 'and update packages_input_control_file txt file in ' + hostname)
connection_execution(hostname, port, username, private_key_path, upd_pkg_file)

# Change Permission for EDM control files
edm_dos2unix = 'cd ' + edm_path + ';dos2unix *.sh *.txt'
edm_chmod = 'cd ' + edm_path + ';chmod -R 777 *.sh *.txt'
connection_execution(hostname, port, username, private_key_path, edm_dos2unix)
connection_execution(hostname, port, username, private_key_path, edm_chmod)
connection_execution(hostname, port, username, private_key_path, 'cd ' + edm_path + ';ls -l')

# Change Permission for Package control files
pkg_dos2unix = 'cd ' + pkg_path + ';dos2unix *.sh *.txt'
pkg_chmod = 'cd ' + pkg_path + ';chmod -R 777 *.sh *.txt'
connection_execution(hostname, port, username, private_key_path, pkg_dos2unix)
connection_execution(hostname, port, username, private_key_path, pkg_chmod)
connection_execution(hostname, port, username, private_key_path, 'cd ' + pkg_path + ';ls -l')

# Get values for control files
emailID = parser['CONTROL_FILES']['EMAIL']
db_instance = parser['CONTROL_FILES']['DATABASE_INSTANCE']
sys_user = parser['CONTROL_FILES']['SYS_USER_NAME']
sys_user_pwd = passwordUtility.get_password(db_instance.lower(), 'sys_user')
sys_pwd = passwordUtility.get_password(db_instance.lower(), 'sys')
application_partition_flag = parser['CONTROL_FILES']['APPLICATION_PARTITIONING']
edm_setup_mode = parser['CONTROL_FILES']['EDM_SETUP_MODE']
common_pwd = passwordUtility.get_password(db_instance.lower(), 'common')
pace_masterdbo_pwd = passwordUtility.get_password(db_instance.lower(), 'pace_masterdbo')
estar_pwd = passwordUtility.get_password(db_instance.lower(), 'estar')
slice_list = parser['CONTROL_FILES']['SLICE']

print('db name', db_instance.lower())
print('sys user pwd :', sys_user_pwd)
print('sys pwd :', sys_pwd)
print('sys common pwd :', common_pwd)
print('sys pace_masterdbo pwd :', pace_masterdbo_pwd)
print('sys estar pwd :', estar_pwd)


# Update edm_slice_control_file.txt file
edm_slice_file = 'edm_slice_control_file.txt'
updatecontolfile(edm_path, 'slice', slice_list,edm_slice_file, hostname, port, username, private_key_path)

# Update edm_input_control_file_schemas.txt file
edm_schema_file = 'edm_input_control_file_schemas.txt'
updatecontolfile(edm_path, 'DATABASE_INSTANCE', db_instance, edm_schema_file, hostname, port, username, private_key_path)
updatecontolfile(edm_path, 'SYS', sys_pwd, edm_schema_file, hostname, port, username, private_key_path)
updatecontolfile(edm_path, 'SYS_USER_NAME', sys_user, edm_schema_file, hostname, port, username, private_key_path)
updatecontolfile(edm_path, 'SYS_USER_PASSWORD', sys_user_pwd, edm_schema_file, hostname, port, username, private_key_path)
updatecontolfile(edm_path, 'APPLICATION_PARTITIONING', application_partition_flag, edm_schema_file, hostname, port, username, private_key_path)
updatecontolfile(edm_path, 'EMAIL', emailID, edm_schema_file, hostname, port, username, private_key_path)

# Update edm_input_control_file_setup.txt file
edm_setup_file = 'edm_input_control_file_setup.txt'
updatecontolfile(edm_path, 'DATABASE_INSTANCE', db_instance, edm_setup_file, hostname, port, username, private_key_path)
updatecontolfile(edm_path, 'EDM_SETUP_MODE', edm_setup_mode, edm_setup_file, hostname, port, username, private_key_path)
updatecontolfile(edm_path, 'COMMON_PASSWORD', common_pwd, edm_setup_file, hostname, port, username, private_key_path)
updatecontolfile(edm_path, 'PACE_MASTERDBO', pace_masterdbo_pwd, edm_setup_file, hostname, port, username, private_key_path)
updatecontolfile(edm_path, 'ESTAR', estar_pwd, edm_setup_file, hostname, port, username, private_key_path)
updatecontolfile(edm_path, 'APPLICATION_PARTITIONING', application_partition_flag, edm_setup_file, hostname, port, username, private_key_path)
updatecontolfile(edm_path, 'EMAIL', emailID, edm_setup_file, hostname, port, username, private_key_path)

# Update packages_input_control_file.txt file
pkg_ctl_file = 'packages_input_control_file.txt'
updatecontolfile(pkg_path, 'DATABASE_INSTANCE', db_instance, pkg_ctl_file, hostname, port, username, private_key_path)
updatecontolfile(pkg_path, 'COMMON_PASSWORD', common_pwd, pkg_ctl_file, hostname, port, username, private_key_path)
updatecontolfile(pkg_path, 'EMAIL', emailID, pkg_ctl_file, hostname, port, username, private_key_path)