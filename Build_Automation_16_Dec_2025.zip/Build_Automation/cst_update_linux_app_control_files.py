import sys, os
import paramiko
from configparser import ConfigParser
from dotenv import load_dotenv
import cst_get_jira_details

load_dotenv()


def connection_execution(host, port, username, private_key_path, password, command):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        private_key = paramiko.RSAKey.from_private_key_file(private_key_path)
        ssh.connect(hostname=host, port=port, username=username, pkey=private_key)
        stdin, stdout, stderr = ssh.exec_command(command)
        for line in stdout:
            print(line.strip(), flush=True)
        print(stdout.read().decode(), flush=True)
        return ssh
    except Exception as e:
        print(e)

hostname = sys.argv[1]
build_ini_file = hostname[0:hostname.find('-', hostname.find('-') + 1)] + '.ini'
print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
username = parser['REGION_DETAILS']['username']
private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], hostname.split('.')[0])
print("Updating the eaglepatch.ini file for", hostname)
print("Username:", username)

build_details, build_version, build_number, build_status, startx_path =  cst_get_jira_details.get_jira_details(hostname)
#build_version = os.path.basename(startx_path)
release_dir = hostname[0:hostname.find('-', hostname.find('-') + 1)] + '_release_dir'
build_version = os.environ.get(release_dir)

print("Build Version :", build_version)

stagePath = parser["BUILD_DIR"]["stagingAppPath"] + build_version
print("Stage Path :", stagePath)

eaglepatchfile = stagePath + "/" + "EAGLE_PATCH" + "/" + "eaglepatch.ini"
print("Eagle Patch ini File :", eaglepatchfile)

old_path = "~/eagle"
new_path = "/apps/eagle"
update_rootPath = ("find " + eaglepatchfile + " -type f -exec sed -i 's|" + old_path + "|"
                   + new_path + "|g' {} \\;")
print("Update Root Path :", update_rootPath)
connection_execution(hostname, '22', username, private_key_path, '', update_rootPath)

old_SilentMode = "SilentMode=0"
new_SilentMode = "SilentMode=1"
update_SilentMode = ("find " + eaglepatchfile + " -type f -exec sed -i 's|" + old_SilentMode + "|"
                    + new_SilentMode + "|g' {} \\;")
print("Update Silent Mode Flag :", update_SilentMode)
connection_execution(hostname, '22', username, private_key_path, '', update_SilentMode)

old_deltaFlag = "Delta=1"
new_deltaFlag = "Delta=0"
update_deltaFlag = ("find " + eaglepatchfile + " -type f -exec sed -i 's|" + old_deltaFlag + "|"
                    + new_deltaFlag + "|g' {} \\;")
print("Update Delta Flag :", update_deltaFlag)
connection_execution(hostname, '22', username, private_key_path, '', update_deltaFlag)

old_skipbkpFlag = "SkipBackup=0"
new_skipbkpFlag = "SkipBackup=1"
update_skipbkpFlag = ("find " + eaglepatchfile + " -type f -exec sed -i 's|" + old_skipbkpFlag + "|"
                      + new_skipbkpFlag + "|g' {} \\;")
print("Update Skip Backup Flag :", update_skipbkpFlag)
connection_execution(hostname, '22', username, private_key_path, '', update_skipbkpFlag)

old_shutdownSvc = "ServiceShutdown=1"
new_shutdownSvc = "ServiceShutdown=0"
update_shutdownSvc = ("find " + eaglepatchfile + " -type f -exec sed -i 's|" + old_shutdownSvc + "|" + new_shutdownSvc
                      + "|g' {} \\;")
print("Update Shutdown Services Flag :", update_shutdownSvc)
connection_execution(hostname, '22', username, private_key_path, '', update_shutdownSvc)
