from configparser import ConfigParser
import sys, os, winrm, paramiko

class EagleServices():
    @staticmethod
    def __execute_script(host, ssh, command):
        stdin, stdout, stderr = ssh.exec_command(command)
        for line in stdout:
            print(line.strip(), flush=True)
        print(stdout.read().decode(), flush=True)
        print('Command executed for :', host, 'is', command)

    @staticmethod
    def runLinuxService(host, port, username, password, private_key_path, command):
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            private_key=paramiko.RSAKey.from_private_key_file(private_key_path)
            ssh.connect(hostname=host,port=port,username=username, pkey=private_key)
            EagleServices.__execute_script(host, ssh, command)
        except:
            ssh.connect(hostname=host, port=port, username=username, password=password)
            EagleServices.__execute_script(host, ssh, command)
        return ssh

    @staticmethod
    def deleteLinuxFiles(hostname, port, username, password, private_key_path):
        try:
            deleteLogFiles = "find /apps/eagle/logs -type f \( -name '*.log' -or -name '*.LOG' \) -mtime +1 -exec rm -rf {} \;"
            EagleServices.runLinuxService(hostname, port, username, password, private_key_path, deleteLogFiles)

            deleteResRarFiles = "find /apps/eagle/bkp/patch -type f \( -name '*.res' -or -name '*.rar' \) -mtime +1 -exec rm -rf {} \;"
            EagleServices.runLinuxService(hostname, port, username, password, private_key_path, deleteResRarFiles)

            deleteStageFiles = "find /apps/eagle/software/stage -type d -name '*Eagle_V2017R2.*' -exec rm -rf {} \;"
            EagleServices.runLinuxService(hostname, port, username, password, private_key_path, deleteStageFiles)

            deleteNFSFiles = "find /apps/eagle/nfs/dailybuild -type d -name '*Eagle_V2017R2.*' -exec rm -rf {} \;"
            EagleServices.runLinuxService(hostname, port, username, password, private_key_path, deleteNFSFiles)
        except Exception as e:
            print(f"An error occurred: {e}")
        #Exception Err:
        #    print('Unable to delete files or folder in', hostname)

    @staticmethod
    def windowsConnection(hostname, username, password):
        try:
            conn = winrm.Session(hostname,auth=(username,password),transport='ntlm')
            print('Connection Established to', hostname)
        except Exception as error:
            print('Failed to Establish Connection to', hostname)
        return conn

    @staticmethod
    def deleteFiles(hostname, username, password):
        conn = EagleServices.windowsConnection(hostname, username, password)
        #powershellcmd = "Get-ChildItem '\\\\10.80.103.21\logs' -Recurse -Include *.log, *.LOG -force | Remove-Item -force"
        #print(powershellcmd)
        #result = conn.run_ps(powershellcmd)
        #output = result.std_out.decode()
        #print(output)

        #cmdprompt = 'DEL /q /f /s /a \\10.80.104.30\logs\..\*.log'
        #print(cmdprompt)
        #result = conn.run_cmd(cmdprompt)
        #output = result.std_out.decode()
        #print(output)

    @staticmethod
    def getpwdFile(hostname, keyPath):
        pwdFile = keyPath + '\\' + hostname.split('.')[0]
        #print(pwdFile)
        return pwdFile

server_listFile = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'ServerList.txt')
if os.path.exists(server_listFile):
    print(server_listFile, 'file present.')
else:
    print(server_listFile, 'file missing.')
    sys.exit(2)

server_name = sys.argv[1]

parser = ConfigParser()
parser.read(server_listFile)

print('Deleting files for', server_name)
if server_name == 'EA-SMART_2017R2x':
    pwdFile_le01 = EagleServices.getpwdFile(parser['EA-SMART_2017R2x']['APP_Tier_le01'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le02 = EagleServices.getpwdFile(parser['EA-SMART_2017R2x']['APP_Tier_le02'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le03 = EagleServices.getpwdFile(parser['EA-SMART_2017R2x']['APP_Tier_le03'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le04 = EagleServices.getpwdFile(parser['EA-SMART_2017R2x']['APP_Tier_le04'], parser['COMMON_PASSWORD']['EA_privatekey'])
    EagleServices.deleteLinuxFiles(parser['EA-SMART_2017R2.x']['APP_Tier_le01'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le01)
    EagleServices.deleteLinuxFiles(parser['EA-SMART_2017R2.x']['APP_Tier_le02'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le02)
    EagleServices.deleteLinuxFiles(parser['EA-SMART_2017R2.x']['APP_Tier_le03'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le03)
    EagleServices.deleteLinuxFiles(parser['EA-SMART_2017R2.x']['APP_Tier_le04'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le04)

if server_name == 'EA-SMART_WASHSALES':
    pwdFile_le01 = EagleServices.getpwdFile(parser['EA-SMART_WASHSALES']['APP_Tier_le01'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le02 = EagleServices.getpwdFile(parser['EA-SMART_WASHSALES']['APP_Tier_le02'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le03 = EagleServices.getpwdFile(parser['EA-SMART_WASHSALES']['APP_Tier_le03'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le04 = EagleServices.getpwdFile(parser['EA-SMART_WASHSALES']['APP_Tier_le04'], parser['COMMON_PASSWORD']['EA_privatekey'])
    EagleServices.deleteLinuxFiles(parser['EA-SMART_WASHSALES']['APP_Tier_le01'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le01)
    EagleServices.deleteLinuxFiles(parser['EA-SMART_WASHSALES']['APP_Tier_le01'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le02)
    EagleServices.deleteLinuxFiles(parser['EA-SMART_WASHSALES']['APP_Tier_le03'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le03)
    EagleServices.deleteLinuxFiles(parser['EA-SMART_WASHSALES']['APP_Tier_le04'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le04)

if server_name == 'EA-SMART_HUB':
    pwdFile_le01 = EagleServices.getpwdFile(parser['EA-SMART_HUB']['APP_Tier_le01'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le02 = EagleServices.getpwdFile(parser['EA-SMART_HUB']['APP_Tier_le02'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le03 = EagleServices.getpwdFile(parser['EA-SMART_HUB']['APP_Tier_le03'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le04 = EagleServices.getpwdFile(parser['EA-SMART_HUB']['APP_Tier_le04'], parser['COMMON_PASSWORD']['EA_privatekey'])
    EagleServices.deleteLinuxFiles(parser['EA-SMART_HUB']['APP_Tier_le01'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le01)
    EagleServices.deleteLinuxFiles(parser['EA-SMART_HUB']['APP_Tier_le02'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le02)
    EagleServices.deleteLinuxFiles(parser['EA-SMART_HUB']['APP_Tier_le03'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], 'z1p.unc&', '')
    EagleServices.deleteLinuxFiles(parser['EA-SMART_HUB']['APP_Tier_le04'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], 'z1p.unc&', '')

if server_name == 'EA-EARTH_ORACLE':
    pwdFile_le01 = EagleServices.getpwdFile(parser['EA-EARTH_ORACLE']['APP_Tier_le01'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le02 = EagleServices.getpwdFile(parser['EA-EARTH_ORACLE']['APP_Tier_le02'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le03 = EagleServices.getpwdFile(parser['EA-EARTH_ORACLE']['APP_Tier_le03'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le04 = EagleServices.getpwdFile(parser['EA-EARTH_ORACLE']['APP_Tier_le04'], parser['COMMON_PASSWORD']['EA_privatekey'])
    EagleServices.deleteLinuxFiles(parser['EA-EARTH_ORACLE']['APP_Tier_le01'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le01)
    EagleServices.deleteLinuxFiles(parser['EA-EARTH_ORACLE']['APP_Tier_le02'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le02)
    EagleServices.deleteLinuxFiles(parser['EA-EARTH_ORACLE']['APP_Tier_le03'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le03)
    EagleServices.deleteLinuxFiles(parser['EA-EARTH_ORACLE']['APP_Tier_le04'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le03)

if server_name == 'EA-DMFARM_ORACLE':
    pwdFile_le01 = EagleServices.getpwdFile(parser['EA-DMFARM_ORACLE']['APP_Tier_le01'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le02 = EagleServices.getpwdFile(parser['EA-DMFARM_ORACLE']['APP_Tier_le02'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le03 = EagleServices.getpwdFile(parser['EA-DMFARM_ORACLE']['APP_Tier_le03'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le04 = EagleServices.getpwdFile(parser['EA-DMFARM_ORACLE']['APP_Tier_le04'], parser['COMMON_PASSWORD']['EA_privatekey'])
    EagleServices.deleteLinuxFiles(parser['EA-DMFARM_ORACLE']['APP_Tier_le01'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le01)
    EagleServices.deleteLinuxFiles(parser['EA-DMFARM_ORACLE']['APP_Tier_le02'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le02)
    EagleServices.deleteLinuxFiles(parser['EA-DMFARM_ORACLE']['APP_Tier_le03'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le03)
    EagleServices.deleteLinuxFiles(parser['EA-DMFARM_ORACLE']['APP_Tier_le04'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le04)

if server_name == 'EA-PERFFARM_ORACLE':
    pwdFile_le01 = EagleServices.getpwdFile(parser['EA-PERFFARM_ORACLE']['APP_Tier_le01'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le02 = EagleServices.getpwdFile(parser['EA-PERFFARM_ORACLE']['APP_Tier_le02'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le03 = EagleServices.getpwdFile(parser['EA-PERFFARM_ORACLE']['APP_Tier_le03'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le04 = EagleServices.getpwdFile(parser['EA-PERFFARM_ORACLE']['APP_Tier_le04'], parser['COMMON_PASSWORD']['EA_privatekey'])
    EagleServices.deleteLinuxFiles(parser['EA-PERFFARM_ORACLE']['APP_Tier_le01'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le01)
    EagleServices.deleteLinuxFiles(parser['EA-PERFFARM_ORACLE']['APP_Tier_le01'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le02)
    EagleServices.deleteLinuxFiles(parser['EA-PERFFARM_ORACLE']['APP_Tier_le03'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le03)
    EagleServices.deleteLinuxFiles(parser['EA-PERFFARM_ORACLE']['APP_Tier_le04'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le04)

if server_name == 'EA-UI_AUTOMATION':
    pwdFile_le01 = EagleServices.getpwdFile(parser['EA-UI_AUTOMATION']['APP_Tier_le01'], parser['COMMON_PASSWORD']['EA_privatekey'])
    pwdFile_le02 = EagleServices.getpwdFile(parser['EA-UI_AUTOMATION']['APP_Tier_le02'], parser['COMMON_PASSWORD']['EA_privatekey'])
    EagleServices.deleteLinuxFiles(parser['EA-UI_AUTOMATION']['APP_Tier_le01'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le01)
    EagleServices.deleteLinuxFiles(parser['EA-UI_AUTOMATION']['APP_Tier_le02'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_le02)

if server_name == 'RnD-FRESH_INSTALL':
    pwdFile_la03 = EagleServices.getpwdFile(parser['RnD-FRESH_INSTALL']['APP_Tier_la03'], parser['COMMON_PASSWORD']['EIS_privatekey'])
    EagleServices.deleteLinuxFiles(parser['RnD-FRESH_INSTALL']['APP_Tier_la03'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_la03)

if server_name == 'RnD-EARTH_ORACLE':
    pwdFile_la01 = EagleServices.getpwdFile(parser['RnD-EARTH_ORACLE']['APP_Tier_la01'], parser['COMMON_PASSWORD']['EIS_privatekey'])
    pwdFile_la03 = EagleServices.getpwdFile(parser['RnD-EARTH_ORACLE']['APP_Tier_la03'], parser['COMMON_PASSWORD']['EIS_privatekey'])
    pwdFile_la04 = EagleServices.getpwdFile(parser['RnD-EARTH_ORACLE']['APP_Tier_la04'], parser['COMMON_PASSWORD']['EIS_privatekey'])
    EagleServices.deleteLinuxFiles(parser['RnD-EARTH_ORACLE']['APP_Tier_la01'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], 'z1p.unc&', '')
    EagleServices.deleteLinuxFiles(parser['RnD-EARTH_ORACLE']['APP_Tier_la03'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_la03)
    EagleServices.deleteLinuxFiles(parser['RnD-EARTH_ORACLE']['APP_Tier_la04'], parser['DEFAULT_PORT']['linux_default_port'], parser['COMMON_USERNAME']['linuxEagle_user_2'], '', pwdFile_la04)
