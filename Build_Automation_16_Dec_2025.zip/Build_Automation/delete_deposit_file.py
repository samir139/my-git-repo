import os, sys, shutil, winrm

def deleteDir(newsetPath):
    try:
        for fname in os.listdir(newsetPath):
            if fname.startswith('Deposit'):
                if os.path.isdir(os.path.join(newsetPath, fname)):
                    shutil.rmtree(os.path.join(newsetPath, fname))
                if os.path.isfile(os.path.join(newsetPath, fname)):
                    os.remove(os.path.join(newsetPath, fname))
                print(os.path.join(newsetPath, fname), 'deleted successfully.')
            else:
                print('Deposit file/folder missing.')
    except OSError as error:
        print(error)


host = sys.argv[1]
username = sys.argv[2]
password = sys.argv[3]
try:
    conn = winrm.Session(host,auth=(username,password),transport='ntlm')
    print('Connection Established to', host)
    newsetPath = '\\\\' + host + '\\working\\newset\\nt_data'
    print('Path to validate :', newsetPath)
    if os.path.exists(newsetPath):
        print('Path Exists')
        deleteDir(newsetPath)
    else:
        print('No path found.')
except Exception as error:
    print('Failed to Establish Connection to', host)

