import paramiko
import re
import smtplib
from email.mime.text import MIMEText
from configparser import ConfigParser
import os
import time

SERVER_LIST_FILE = r"configurations/linux_servers"
MAX_DURATION_SECONDS = 15 * 60  # 15 minutes time limit

def read_config_ini_file(host):
    build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    return parser

exec_commands = [
    "cd /apps/eagle && df -h /apps",
    r"cd /apps/eagle && find /apps/eagle/logs -type f \( -name '*.log' -or -name '*.LOG' \) -exec rm -rf {} \;",
    r"cd /apps/eagle && find /apps/eagle/bkp/patch -type f \( -name '*.res' -or -name '*.rar' \) -exec rm -rf {} \;",
    "cd /apps/eagle && df -h /apps"
]

with open(SERVER_LIST_FILE, "r") as f:
    servers = [line.strip() for line in f if line.strip()]

# Start timer
start_time = time.time()

# Table Header
html_report = """
<h3>Filesystem Disk Check Report</h3>
<table border="1" cellspacing="0" cellpadding="5">
<tr>
<th>Server</th><th>Size</th><th>Used</th><th>Available</th><th>Use%</th><th>Mount</th>
</tr>
"""

for server in servers:

    # Check time limit
    elapsed = time.time() - start_time
    if elapsed > MAX_DURATION_SECONDS:
        html_report += "</table><br><b>Script stopped due to time limit exceeded.</b>"
        break

    try:
        parser = read_config_ini_file(server)
        username = parser['REGION_DETAILS']['username']
        id_rsa_key = os.path.join(parser['REGION_DETAILS']['privatekey'], server.split('.')[0])

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(server, username=username, key_filename=id_rsa_key, timeout=10)

        # Run df command before/after cleanup
        stdin, stdout, stderr = client.exec_command("df -h /apps")
        output = stdout.read().decode()

        # Parse df output into table rows
        #for line in output.splitlines():
        #    if line.startswith("/"):
        #        parts = re.split(r"\s+", line)
        #        filesystem, size, used, avail, use_percent, mount = parts[0], parts[1], parts[2], parts[3], parts[4], \
        #                                                            parts[5]

        #        numeric_use = int(use_percent.replace("%", ""))

                # Color coding
        #        color_style = "background-color:#FF7F7F;" if numeric_use >= 80 else ""

        #        html_report += (
        #            f"<tr style='{color_style}'>"
        #            f"<td>{server}</td><td>{size}</td><td>{used}</td><td>{avail}</td>"
        #            f"<td>{use_percent}</td><td>{mount}</td>"
        #            f"</tr>"
        #        )

        # Execute cleanup commands
        for cmds in exec_commands[1:3]:
            print('Executing command on :', server, 'is', cmds)
            client.exec_command(cmds)

        # Run df again after cleanup
        stdin, stdout, stderr = client.exec_command("df -h /apps")
        output = stdout.read().decode()

        # Parse final df
        for line in output.splitlines():
            if line.startswith("/"):
                parts = re.split(r"\s+", line)
                filesystem, size, used, avail, use_percent, mount = parts[0], parts[1], parts[2], parts[3], parts[4], \
                                                                    parts[5]

                numeric_use = int(use_percent.replace("%", ""))

                # Color coding
                color_style = "background-color:#FF7F7F;" if numeric_use >= 80 else ""

                html_report += (
                    f"<tr style='{color_style}'>"
                    f"<td>{server}</td><td>{size}</td><td>{used}</td><td>{avail}</td>"
                    f"<td>{use_percent}</td><td>{mount}</td>"
                    f"</tr>"
                )

        client.close()

    except Exception as e:
        html_report += f"<tr><td colspan='7'>Error on {server}: {e}</td></tr>"

html_report += "</table>"

# Email settings
smtp_server = "smtpvip-p-use2.eagleaccess.com"
from_email = "regops_support@eagleinvsys.com"
to_email = ["samir.ransingh@bny.com","marimuthu.mannathan@bny.com"]
subject = "Linux - /apps : Drive Utilization Alert"

msg = MIMEText(html_report, "html")
msg['Subject'] = subject
msg['From'] = from_email
msg['To'] = ", ".join(to_email)

try:
    with smtplib.SMTP(smtp_server) as server:
        server.starttls()
        server.send_message(msg)
    print("Email sent successfully.")
except Exception as e:
    print(f"Failed to send email: {e}")
