import paramiko
import re
import smtplib
from email.message import EmailMessage
from email.mime.text import MIMEText
from configparser import ConfigParser
import os
from datetime import time

SERVER_LIST_FILE = r"configurations/linux_servers"

def read_config_ini_file(host):
    build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    return parser

exec_commands = [
    "cd /apps/eagle && df -h /apps",
    r"cd /apps/eagle && find /apps/eagle/logs -type f \( -name '*.log' -or -name '*.LOG' \) -mtime +1 -exec rm -rf {} \;",
    r"cd /apps/eagle && find /apps/eagle/bkp/patch -type f \( -name '*.res' -or -name '*.rar' \) -mtime +1 -exec rm -rf {} \;",
    "cd /apps/eagle && df -h /apps"
]

with open(SERVER_LIST_FILE, "r") as f:
    servers = [line.strip() for line in f if line.strip()]

# Collect output
report = ""

for server in servers:
    try:
        report += f"\n----- {server} -----\n"
        parser = read_config_ini_file(server)
        username = parser['REGION_DETAILS']['username']
        id_rsa_key = os.path.join(parser['REGION_DETAILS']['privatekey'], server.split('.')[0])
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(server, username=username, key_filename=id_rsa_key, timeout=10)
        for cmds in exec_commands:
            try:
                print('Executing command on', server, '-', cmds)
                stdin, stdout, stderr = client.exec_command(cmds)
                output = stdout.read().decode()
                report += output
            except Exception as e:
                report += f"Error executing command in {server}: {e}\n"

        client.close()
    except Exception as e:
        report += f"Error connecting to {server}: {e}\n"

smtp_server = "smtpvip-p-use2.eagleaccess.com"
from_email = "regops_support@eagleinvsys.com"
to_email = ["samir.ransingh@bny.com","marimuthu.mannathan@bny.com"]
subject = "Report of deleting log bkp files in Linux (App Tiers)"

# Compose email
msg = MIMEText(report)
msg['Subject'] = subject
msg['From'] = from_email
msg['To'] = ", ".join(to_email)

# Send email
try:
    with smtplib.SMTP(smtp_server) as server:
        server.starttls()
        server.send_message(msg)
    print("Email sent successfully.")
except Exception as e:
    print(f"Failed to send email: {e}")



