import paramiko
import re
import smtplib
from email.message import EmailMessage
from configparser import ConfigParser
import configparser
import os

USERNAME = "eagle"
REMOTE_PATH = "/apps/eagle/software/stage"
PATTERN = re.compile(r".*_(\d{2}-\d{2}-\d{4}|\d{2}-\d{2}-\d{2})$|.*-\d{2}-\d{2}-\d{2}$")

parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)),'configurations','emailnotification.ini'))
SMTP_SERVER = parser['Email_Alert']['smtpServer']
EMAIL_FROM = parser['Email_Alert']['sender']
EMAIL_TO = parser['Email_Alert']['recipients']
EMAIL_SUBJECT = "Report of deleted staging directories in Linux (App Tiers)"

def read_id_rsa_key(host):
    build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    return parser

linux_server_list = 'configurations/linux_host_list.ini'
config = configparser.ConfigParser()
config.read(linux_server_list)
servers = [s.strip() for s in config.get("LinuxHosts", "servers").split(",") if s.strip()]

deleted_folders = []

for host in servers:
    print('List of directories in - ', host)
    print('---------------------------------------------------------------------')
    deleted_folders.append('List of directories in - ' + host)
    deleted_folders.append('-------------------------------------------------------------------------------------------')
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        parser = read_id_rsa_key(host)
        id_rsa_key = os.path.join(parser['REGION_DETAILS']['privatekey'], host.split('.')[0])
        ssh.connect(hostname=host, username=USERNAME, key_filename=id_rsa_key)
        list_cmd = "cd /apps/eagle && ls -d " + REMOTE_PATH + "/Eagle_V* 2>/dev/null"
        stdin, stdout, stderr = ssh.exec_command(list_cmd)
        dirs = stdout.read().decode().splitlines()
        for full_path in dirs:
            print("Folders Available - ", full_path)
            deleted_folders.append("Folders Available - " + full_path)
            folder_name = full_path.split("/")[-1]
            if PATTERN.fullmatch(folder_name):
                deleted_folders.append("Folders to be Deleted - " + full_path)
                delete_cmd = "rm -rf " + full_path
                ssh.exec_command(delete_cmd)
                deleted_folders.append(folder_name)
                print("Deleted: ", full_path)

        old_dir_list = r"cd /apps/eagle && find " + REMOTE_PATH + " -mindepth 1 -maxdepth 1 -type d -name 'Eagle_V*' -daystart -mtime +15 -printf '%f\n'"
        stdin, stdout, stderr = ssh.exec_command(old_dir_list)
        old_dirs = stdout.read().decode().splitlines()
        for x in old_dirs:
            ssh.exec_command('rm -rf ' + REMOTE_PATH + '/' + x)
            deleted_folders.append(x)
            print("Deleted: ", REMOTE_PATH + '/' + x)
        ssh.close()
        print("\n")
    except Exception as e:
        print("Error with server ", host, " : ", e)
    deleted_folders.append('\n')

# === Send Email Notification ===
if deleted_folders:
    msg = EmailMessage()
    msg["From"] = EMAIL_FROM
    msg["To"] = EMAIL_TO.split(",")
    msg["Subject"] = EMAIL_SUBJECT
    body = "The following folders were deleted:\n\n" + "\n".join(deleted_folders)
    msg.set_content(body)
    try:
        with smtplib.SMTP(SMTP_SERVER) as server:
            server.starttls()
            server.send_message(msg)
            print("Email sent successfully.")
    except Exception as e:
        print("Failed to send email: ", e)
else:
    print("No folders matched the deletion pattern.")
