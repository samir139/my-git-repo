import os
import shutil
import smtplib
import re
from email.message import EmailMessage
from configparser import ConfigParser
import configparser
from datetime import datetime, timedelta

SHARE_PATH_FILE = r"e:\Build_Automation\configurations\share_paths"
pattern = re.compile(r"^(Eagle_V.*)_(\d{2}-\d{2}-\d{4}-\d{2}\.\d{2}\.\d{2})$")

# Email Config
parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)),'configurations','emailnotification.ini'))
SMTP_SERVER = parser['Email_Alert']['smtpServer']
EMAIL_FROM = parser['Email_Alert']['sender']
EMAIL_TO = parser['Email_Alert']['recipients']
EMAIL_SUBJECT = "Report of deleted staging folders in Windows (Report and Web Tiers)"

# === Read Share Paths from File ===
windows_server_list = 'configurations/Windows_host_list.ini'
config = configparser.ConfigParser()
config.read(windows_server_list)
servers = [s.strip() for s in config.get("WindowsHosts", "servers").split(",") if s.strip()]

# === Find and Delete Matching Folders ===
deleted_folders = []

#for path in share_paths:
for host in servers:
    stage_path = '\\\\' + host + '\\Eagle_Install\\Stage'
    if not os.path.exists(stage_path):
        print("Path not found: ", stage_path)
        continue
    print('List of folders in -', stage_path)
    print('---------------------------------------------------------------------')
    deleted_folders.append('List of directories in -' + stage_path)
    deleted_folders.append(
        '-------------------------------------------------------------------------------------------')
    try:
        # Cutoff date
        cutoff = datetime.now() - timedelta(days=5)
        for item in os.listdir(stage_path):
            full_path = os.path.join(stage_path, item)
            if os.path.isdir(full_path):
                print("Folder Available - ", full_path)
                deleted_folders.append("Folder Available - " + full_path)
                match = pattern.fullmatch(item)
                if match:
                    timestamp_str = match.group(2)
                    try:
                        folder_date = datetime.strptime(timestamp_str, "%m-%d-%Y-%H.%M.%S")
                    except ValueError as e:
                        #print(f"Skipping {item}, timestamp parse failed: {e}")
                        continue
                    if folder_date < cutoff:
                        print("Deleted : " + full_path)
                        deleted_folders.append("Deleting : " +full_path)
                        shutil.rmtree(full_path)

                else:
                    mtime = datetime.fromtimestamp(os.path.getmtime(full_path))
                    if mtime < cutoff:
                        print("Deleted : " +full_path)
                        deleted_folders.append("Deleting : " + full_path)
                        shutil.rmtree(full_path)

    except Exception as list_error:
        print("Error accessing ", stage_path, ": ", list_error)
    deleted_folders.append('\n')
    print("\n")

# === Send Email Notification ===
if deleted_folders:
    msg = EmailMessage()
    msg["From"] = EMAIL_FROM
    msg["To"] = EMAIL_TO.split(",")
    msg["Subject"] = EMAIL_SUBJECT
    body = "The following folders were deleted:\n\n" + "\n".join(deleted_folders)
    msg.set_content(body)
    try:
        with smtplib.SMTP(SMTP_SERVER) as server:
            server.starttls()
            server.send_message(msg)
            print("Email sent successfully.")
    except Exception as e:
        print("Failed to send email: ", e)
else:
    print("No folders matched the deletion pattern.")
