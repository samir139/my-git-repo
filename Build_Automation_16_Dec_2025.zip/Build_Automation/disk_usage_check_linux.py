import paramiko
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from configparser import ConfigParser
import os
import socket


def read_id_rsa_key(host):
    build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    return parser

def read_ini():
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations/emailnotification.ini'))
    return parser

def check_disk_usage_linux():
    email_parser = read_ini()
    smtp_server = email_parser['Email_Alert']['smtpServer']
    sender_email = email_parser['Email_Alert']['sender']
    recipient_email = email_parser['Email_Alert']['recipients'].split(',')

    # Read server list
    with open(r"configurations/linux_servers") as f:
        servers = [line.strip() for line in f if line.strip()]

    # Prepare list to collect alerts
    alerts = []
    alerts_html = []

    for server in servers:
        username = "eagle"
        parser = read_id_rsa_key(server)
        id_rsa_key = os.path.join(parser['REGION_DETAILS']['privatekey'], server.split('.')[0])
        try:
            print(f"Connecting to {server}")
            print('----------------------------------------------------------')
            #ssh = paramiko.SSHClient()
            #ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            #key = paramiko.RSAKey.from_private_key_file(id_rsa_key)
            #ssh.connect(server, username=username, pkey=key, timeout=10)
            #stdin, stdout, stderr = ssh.exec_command("df -h")
            #output = stdout.read().decode().strip()
            #ssh.close()

            MAX_EXECUTION_TIME = 15  # seconds (adjust as needed)

            try:
                ssh = paramiko.SSHClient()
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                key = paramiko.RSAKey.from_private_key_file(id_rsa_key)

                # connection timeout controls SSH handshake time
                ssh.connect(server, username=username, pkey=key, timeout=10)

                # Run df -h with max command timeout
                stdin, stdout, stderr = ssh.exec_command("df -h", timeout=MAX_EXECUTION_TIME)

                # Set timeout on channel to stop long-running output
                stdout.channel.settimeout(MAX_EXECUTION_TIME)

                try:
                    output = stdout.read().decode().strip()
                except socket.timeout:
                    output = f"[SKIPPED] Command exceeded {MAX_EXECUTION_TIME}s timeout."
                except Exception as e:
                    output = f"[ERROR] Failed to read output: {e}"

                ssh.close()

            except socket.timeout:
                output = f"[SKIPPED] SSH connection to {server} timed out."
            except Exception as e:
                output = f"[ERROR] SSH failure on {server}: {e}"

            print(output)

            found_apps = False

            for line in output.splitlines():
                parts = line.split()
                if len(parts) >= 6 and parts[-1] == "/apps":
                    found_apps = True
                    usage_percent = parts[4]
                    usage_value = int(usage_percent.strip('%'))
                    print(f"{server} /apps usage: {usage_percent}")
                    if usage_value > 70:
                        alerts_html.append(
                            f"<tr><td>{server}</td><td><font color='red'>{usage_percent}</font></td></tr>")
                    else:
                        alerts_html.append(f"<tr><td>{server}</td><td>{usage_percent}</td></tr>")

            if not found_apps:
                print(f"{server}: /apps mount not found!")
                alerts_html.append(f"<tr><td>{server}</td><td>Not Found</td></tr>")

        except Exception as e:
            print(f"Error connecting to {server}: {e}")
            alerts_html.append(f"<tr><td>{server}</td><td>Connection Error</td></tr>")

        # Send email if any results found
        if alerts_html:
            html_body = f"""
                <html>
                <body>
                <p>Disk Space Report for /apps:</p>
                <table border="1" cellpadding="5" cellspacing="0">
                    <tr><th>Server</th><th>/apps Usage</th></tr>
                    {''.join(alerts_html)}
                </table>
                </body>
                </html>
                """

            msg = MIMEMultipart("alternative")
            #msg['Subject'] = "Disk Space Report: /apps usage"
            msg['Subject'] = 'Linux - /apps : Drive Utilization Alert'
            msg['From'] = sender_email
            #msg['To'] = ", ".join(recipient_email)
            msg['To'] = ', '.join(recipient_email)

            part = MIMEText(html_body, "html")
            msg.attach(part)

    try:
        with smtplib.SMTP(smtp_server) as server:
            server.starttls()
            server.send_message(msg)
            #server.sendmail(sender_email, [recipient_email], msg.as_string())
        print("Report email sent successfully.")
    except Exception as e:
        print(f"Failed to send email: {e}")

check_disk_usage_linux()