import winrm
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from configparser import ConfigParser
import os


def read_id_rsa_key(host):
    build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    return parser

def read_ini():
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations/emailnotification.ini'))
    return parser

def check_disk_usage_windows():
    # Email config
    email_parser = read_ini()
    smtp_server = email_parser['Email_Alert']['smtpServer']
    sender_email = email_parser['Email_Alert']['sender']
    #recipient_email = email_parser['Email_Alert']['recipients'].split(',')
    #SMTP_SERVER = "smtpvip-p-use2.eagleaccess.com"
    #FROM_EMAIL = "regops_support@eagleinvsys.com"
    recipient_email = ["samir.ransingh@bny.com","chinmay.swain@bny.com"]

    # Drives to check
    DRIVES = ["C:", "E:"]

    # Read server list
    with open("configurations/windows_servers") as f:
        servers = [line.strip() for line in f if line.strip()]
    
    # Store results
    report_rows = []
    
    for server in servers:
        try:
            print(f"Connecting to {server}...")
            parser = read_id_rsa_key(server)
            user = parser['REPORT_TIER_DETAIL']['username']
            id_rsa_key = os.path.join(parser['REGION_DETAILS']['winPrivateKey'], user)
            with open(id_rsa_key, 'rb') as file:
                key_content = file.read().decode('utf-8')
    
            session = winrm.Session(server, auth=(user, key_content), transport='ntlm')

            for drive in DRIVES:
                ps_script = f"""
                        $disk = Get-WmiObject Win32_LogicalDisk -Filter "DeviceID='{drive}'"
                        if ($disk) {{
                            $used = $disk.Size - $disk.FreeSpace
                            $total = $disk.Size
                            $free = $disk.FreeSpace
                            $util = ($used / $total) * 100
                            Write-Output "$('{drive}');$($total);$($used);$($free);$([math]::Round($util, 2))"
                        }} else {{
                            Write-Output "$('{drive}');0;0;0;0"
                        }}
                        """
    
                result = session.run_ps(ps_script)
    
                if result.status_code != 0:
                    raise Exception(result.std_err.decode())
    
                output = result.std_out.decode().strip()
                for line in output.splitlines():
                    parts = line.split(";")
                    if len(parts) != 5:
                        continue
                    drive_letter, total, used, free, utilization = parts
                    total_gb = int(total) / (1024 ** 3) if int(total) != 0 else 0
                    used_gb = int(used) / (1024 ** 3) if int(used) != 0 else 0
                    free_gb = int(free) / (1024 ** 3) if int(free) != 0 else 0
                    utilization = float(utilization)
                    report_rows.append({
                        "server": server,
                        "drive": drive_letter,
                        "total": total_gb,
                        "used": used_gb,
                        "free": free_gb,
                        "utilization": utilization
                    })
    
        except Exception as e:
            print(f"Failed to connect to {server}: {str(e)}")
            for drive in DRIVES:
                report_rows.append({
                    "server": server,
                    "drive": drive,
                    "total": 0,
                    "used": 0,
                    "free": 0,
                    "utilization": 0,
                    "error": str(e)
                })
    # Build email content
    html = """
    <html><body>
    <h2>Disk Utilization Report</h2>
    <table border="1" cellpadding="5" cellspacing="0">
    <tr><th>Server</th><th>Drive</th><th>Total (GB)</th><th>Used (GB)</th><th>Free (GB)</th><th>Utilization (%)</th><th>Status</th></tr>
    """
    
    alert = False

    for row in report_rows:
        if 'error' in row:
            html += f"<tr><td>{row['server']}</td><td>{row['drive']}</td><td colspan='4'>Connection Failed: {row['error']}</td><td><font color='red'>Failed</font></td></tr>"
            continue

        color = "red" if row['utilization'] > 80 else "black"
        if row['utilization'] > 80:
            alert = True

        html += (
            f"<tr><td>{row['server']}</td>"
            f"<td>{row['drive']}</td>"
            f"<td>{row['total']:.2f}</td>"
            f"<td>{row['used']:.2f}</td>"
            f"<td>{row['free']:.2f}</td>"
            f"<td><font color='{color}'>{row['utilization']:.2f}</font></td>"
            f"<td>Success</td></tr>"
        )
    
    html += "</table></body></html>"
    
    # Send email
    #if alert:
    msg = MIMEMultipart('alternative')
    #msg['Subject'] = "E: Drive Utilization Alert"
    msg['Subject'] = "Windows - C: & E: Drive Utilization Alert"
    msg['From'] = sender_email
    msg['To'] = ", ".join(recipient_email)
    msg.attach(MIMEText(html, 'html'))
    
    try:
        with smtplib.SMTP(smtp_server) as server:
            #server.sendmail(msg['From'], msg['To'], msg.as_string())
            server.send_message(msg)
        print("Alert email sent successfully.")
    except Exception as e:
        print(f"Failed to send email: {str(e)}")
    #else:
    #    print("No servers exceeded threshold. No email sent.")

check_disk_usage_windows()