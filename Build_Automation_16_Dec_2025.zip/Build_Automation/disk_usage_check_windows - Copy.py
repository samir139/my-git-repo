import wmi
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from configparser import ConfigParser
import os

def read_id_rsa_key(host):
    build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    return parser

def check_disk_usage_windows():
    SMTP_SERVER = "smtpvip-p-use2.eagleaccess.com"
    FROM_EMAIL = "regops_support@eagleinvsys.com"
    #TO_EMAILS = ["samir.ransingh@bny.com","marimuthu.mannathan@bny.com","chinmay.swain@bny.com"]
    TO_EMAILS = ["samir.ransingh@bny.com"]
    
    USERNAME = "eagleaccess\\farm"
    PASSWORD = "9:{pzFW6x`C4Z|3["
    
    with open("configurations/windows_servers") as f:
        servers = [line.strip() for line in f if line.strip()]
    
    report_rows = []
    
    for server in servers:
        try:
            parser = read_id_rsa_key(server)
            #username = parser['REGION_DETAILS']['username']
            #key_file_path = os.path.join(parser['REGION_DETAILS']['winPrivateKey'], USERNAME)
            #with open(key_file_path, 'r') as file:
            #    passwd = file.read()
            print(f"Connecting to {server}...")
            print('User :', USERNAME)
            print('Password :', PASSWORD)
            print('Server :', server)
            connection = wmi.WMI(computer=server, user=USERNAME, password=PASSWORD)
            for disk in connection.Win32_LogicalDisk(DriveType=3):
                if disk.DeviceID == 'E:':
                    total_gb = int(disk.Size) / (1024 ** 3)
                    free_gb = int(disk.FreeSpace) / (1024 ** 3)
                    used_gb = total_gb - free_gb
                    utilization = (used_gb / total_gb) * 100

                    row = {
                        "server": server,
                        "total": total_gb,
                        "free": free_gb,
                        "used": used_gb,
                        "utilization": utilization
                    }
                    report_rows.append(row)
        except Exception as e:
            print(f"Failed to connect to {server}: {str(e)}")
    
    # Build HTML email
    html = """
    <html><body>
    <h2>E: Drive Utilization Report</h2>
    <table border="1" cellpadding="5" cellspacing="0">
    <tr><th>Server</th><th>Total (GB)</th><th>Used (GB)</th><th>Free (GB)</th><th>Utilization (%)</th></tr>
    """
    
    alert = False
    
    for row in report_rows:
        color = "red" if row['utilization'] > 80 else "black"
        #if row['utilization'] > 30:
        #    alert = True
        html += f"<tr><td>{row['server']}</td><td>{row['total']:.2f}</td><td>{row['used']:.2f}</td><td>{row['free']:.2f}</td><td><font color='{color}'>{row['utilization']:.2f}%</font></td></tr>"
    
    html += "</table></body></html>"
    
    # Send email only if any utilization > 80%
    #if alert:
    msg = MIMEMultipart('alternative')
    msg['Subject'] = "E: Drive Utilization Alert"
    msg['From'] = FROM_EMAIL
    msg['To'] = ", ".join(TO_EMAILS)
    msg.attach(MIMEText(html, 'html'))
    
    try:
        with smtplib.SMTP(SMTP_SERVER) as server:
            server.sendmail(FROM_EMAIL, TO_EMAILS, msg.as_string())
        print("Alert email sent successfully.")
    except Exception as e:
        print(f"Failed to send email: {str(e)}")
    #else:
    #    print("No utilization above threshold. No email sent.")

check_disk_usage_windows()