import os,shutil,sys,subprocess
#import win32wnet
from datetime import datetime
from configparser import ConfigParser
from dotenv import load_dotenv
load_dotenv('.env')


def readKeyStorage(winPrivateKey):
    with open(winPrivateKey, 'r') as file:
        password = file.read()
    return password

def rename_existing_folder(share_path,username,password,oldname):
    #try:
    #    win32wnet.WNetAddConnection2(0,None,share_path,None,username,password)
    #    print('connection sucessful')
    #except Exception as error:
    #    print(str(error))
    create_time = os.path.getmtime(share_path)
    format_time = datetime.fromtimestamp(create_time).strftime('%m-%d-%Y-%H.%M.%S')
    newname=oldname+'_'+format_time
    oldpath=os.path.join(share_path,oldname)
    newpath=os.path.join(share_path,newname)
    try:
        shutil.move(oldpath,newpath)
        print("Renamed folder " + oldpath + " to " + newpath)
    except FileNotFoundError:
        print(f'the specified folder {oldpath} does not exist.')
    except FileExistsError:
        print(f'A folder {oldpath} with the the new name already exists')


def main(argv):
    now = datetime.now()
    try:

        host = sys.argv[1]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)

    build_ini_file = host + '.ini'
    if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
        print(build_ini_file, 'file present.')
    else:
        print(build_ini_file, 'file missing.')
        sys.exit(2)
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    build_version = os.environ.get('build_version')
    root_stage = os.path.join(os.environ.get('dailyBuild_path'))

    root_stage_patch = os.path.join(root_stage, build_version, 'EAGLE_PATCH')
    
    username= parser['REPORT_TIER_DETAIL']['username']
    #password= parser['REPORT_TIER_DETAIL']['password']

    winPrivateKey = parser['REGION_DETAILS']['winPrivateKey'] + '\\' + username
    password = readKeyStorage(winPrivateKey)

    section_name = 'REPORT_TIER_PATH'
    if section_name in parser.sections():
        for option in parser.options(section_name):
            staging_path = parser.get(section_name, option)

            try:
                print('Changing Staging Folders in  server START TIME :',
                      datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
                print(staging_path)

                rename_existing_folder(staging_path,username,password,build_version)

                print('Changing Staging Folders in server END TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))

                print('Creating Staging Folders in server START TIME :', datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
                destination=os.path.join(staging_path,build_version,'EAGLE_PATCH')


                print('Copying Staging files from DailyBuilds location to Staging Location START TIME :',destination ,datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))

                shutil.copytree(root_stage_patch, destination)

                print('Copying Staging files from DailyBuilds location to Staging Location END TIME :', destination,datetime.now().strftime(("%m/%d/%Y %H:%M:%S")))
            except Exception as e:
                print('There is exception while copying to :',e)
    else:
        print("section name name not present in ini file")


if __name__ == "__main__":
    main(sys.argv)




