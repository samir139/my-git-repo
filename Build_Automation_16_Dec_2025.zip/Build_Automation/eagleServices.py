
def win_stop_services(conn, ip, svc):
    for svc_name in svc:
        try:
            conn.Win32_Service(Name=svc_name)[0].StopService()
            print(svc_name, ip, 'Stopped Successfully')
        except OSError as error:
            print(svc_name, ip, 'Failed to Stop Successfully')

def win_start_services(conn, ip, svc):
    for svc_name in svc:
        try:
            conn.Win32_Service(Name=svc_name)[0].StartService()
            print(svc_name, ip, 'Started Successfully')
        except OSError as error:
            print(svc_name, ip, 'Failed to Start Successfully')
