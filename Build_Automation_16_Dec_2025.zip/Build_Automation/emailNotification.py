import os, smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from configparser import ConfigParser

def read_ini():
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations/emailnotification.ini'))
    return parser

def send_mail(subject):
    msg = MIMEMultipart()
    email_parser = read_ini()
    smtp_server = email_parser['Email_Alert']['smtpServer']
    sender_email = email_parser['Email_Alert']['sender']
    recipient_email = email_parser['Email_Alert']['more_recipients']
    body = "Thanks, \n Regression Team."

    recipient_list = [email.strip() for email in recipient_email.split(',') if email.strip()]

    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = ', '.join(recipient_list)
    msg.attach(MIMEText(body, 'plain'))

    try:
        with smtplib.SMTP(smtp_server) as server:
            server.send_message(msg)
        print("Email sent successfully.")
    except Exception as e:
        print("Failed to send email:", e)

#send_mail('Test Message')