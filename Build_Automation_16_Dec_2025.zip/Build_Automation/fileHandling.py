import os, shutil, collections, fileinput, glob, psutil
from datetime import datetime, timezone
from multiprocessing.pool import ThreadPool
from multiprocessing import Process
from subprocess import Popen

class MultithreadedCopier:
    def __init__(self, max_threads):
        self.pool = ThreadPool(max_threads)

    def copy(self, source, dest):
        self.pool.apply_async(shutil.copy2, args=(source, dest))

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.pool.close()
        self.pool.join()

def check_disk_space(host):
    BytesPerGB = 1024 * 1024 * 1024
    (total, used, free) = shutil.disk_usage(host)
    total = int(round(float(total)/BytesPerGB))
    used = int(round(float(used)/BytesPerGB))
    free = int(round(float(free)/BytesPerGB))
    if free > 5:
        print('Disk Space Available in : ' + host)
        print('Total Space in GB :', total, ', Used Space in GB :', used, ', Free Space in GB :', free)
    else:
        print('Disk Space not Available in : ' + host)
        print('Total Space in GB :', total, ', Used Space in GB :', used, ', Free Space in GB :', free)
    return total, used, free


def deleteDir(newsetPath):
    try:
        if os.path.isdir(newsetPath):
            shutil.rmtree(newsetPath)
            print('Directory ' + newsetPath + ' Deleted Successfully')
        else:
            print('Folder does not exist in the given path')
    except OSError as error:
        print(error)

def deleteDepositDir(newsetPath):
    try:
        for fname in os.listdir(newsetPath):
            if fname.startswith('Deposit'):
                if os.path.isdir(os.path.join(newsetPath, fname)):
                    print(os.path.join(newsetPath, fname))
                    shutil.rmtree(os.path.join(newsetPath, fname))
                if os.path.isfile(os.path.join(newsetPath, fname)):
                    print(os.path.join(newsetPath, fname))
                    os.remove(os.path.join(newsetPath, fname))
    except OSError as error:
        print(error)

def createStageDir(stagingPath):
    try:
        if not os.path.isdir(stagingPath):
            os.makedirs(stagingPath, 0o777)
            print('Staging Directory ' + stagingPath + ' Created Successfully')
        else:
            shutil.rmtree(stagingPath)
            os.makedirs(stagingPath, 0o777)
            print('Staging Directory ' + stagingPath + ' Created Successfully')
    except OSError as error:
        print(error)

def rename_directory_1(StagePath):
    if os.path.exists(StagePath):
        create_time = os.path.getmtime(StagePath)
        format_time = datetime.fromtimestamp(create_time).strftime('%m-%d-%Y-%H.%M.%S')
        updStagepath = StagePath+ '_' + format_time
        os.rename(StagePath, updStagepath)
        print('Staging Directory Changed to : ', StagePath+ '_' + format_time)
    else:
        print('No Staging Directory to be renamed.')

def rename_directory(StagePath):
    if os.path.exists(StagePath):
        create_time = os.path.getmtime(StagePath)
        format_time = datetime.fromtimestamp(create_time).strftime('%m-%d-%Y-%H.%M.%S')
        updStagepath = StagePath+ '_' + format_time
        #print(f"...Searching for active processes matching path: '{StagePath}'")
        #for proc in psutil.process_iter(['name', 'open_files']):
        #    for file in proc.info['open_files'] or []:
        #        if StagePath in file.path:
        #            print(f"Found process potentiall process potentially locking path. Killing: '{proc.info['name']}'")
        #            print("%-5s %-10s %s" % (proc.pid, proc.info['name'][:10], file.path))
        #            proc.kill()
        os.rename(StagePath, updStagepath)
        
        print('Staging Directory Changed to : ', StagePath+ '_' + format_time)
    else:
        print('No Staging Directory to be renamed.')

def StageFileCopy(source_loc, destination_loc):
    print('Staging files copying for  : ', destination_loc)
    with MultithreadedCopier(max_threads=100) as copier:
        shutil.copytree(source_loc, destination_loc, copy_function=copier.copy)

def replace_string(filename, from_string, to_string):
    if os.path.isfile(filename):
        f = open(filename,'r')
        filedata = f.read()
        f.close()
        newdata = filedata.replace(from_string, to_string)
        f = open(filename,'w')
        f.write(newdata)
        f.close()

def delete_lines(filename, lines_to_delete):
    if os.path.isfile(filename):
        queue = collections.deque()
        lines_to_delete = max(0, lines_to_delete)
        for line in fileinput.input(filename, inplace=True, backup='.bak'):
            queue.append(line)
            if lines_to_delete == 0:
                print(queue.popleft())
            else:
                lines_to_delete -= 1
        queue.clear()

def delete_log_files(hostname):
    pattern = r"\\" + hostname + "\Eagle Investment Systems\logs\**\*.log"
    #print('Deleting log files from : ', hostname)
    file_count = 0
    for item in glob.iglob(pattern, recursive=True):
        try:
            #print("Deleting:", item)
            file_count += len(item)
            os.remove(item)
        except:
            print("Error while deleting file", item)
    print(file_count, 'No of log files deleted in ', hostname)

def delete_bkp_files(hostname):
    pattern = r"\\" + hostname + r"\Eagle Investment Systems\bkp\patch\**\*.res"
    #print('Deleting files from : ', hostname)
    res_file_count = 0
    for item in glob.iglob(pattern, recursive=True):
        try:
            #print("Deleting: ", item)
            res_file_count += len(item)
            os.remove(item)
        except:
            print("Error while deleting file", item)
    print(res_file_count, 'No. of res files deleted in ', hostname)

    pattern = r"\\" + hostname + r"\Eagle Investment Systems\bkp\patch\**\*.rar"
    #print('Deleting files from : ', hostname)
    rar_file_count = 0
    for item in glob.iglob(pattern, recursive=True):
        try:
            #print("Deleting:", item)
            rar_file_count += len(item)
            os.remove(item)
        except:
            print("Error while deleting file", item)
    print(rar_file_count, 'No. of rar files deleted in ', hostname)

def execute_postUpgrade_Step(db_cleanup_path, db_cleanup_script):
    if os.path.exists(db_cleanup_path):
        os.chdir(db_cleanup_path)
        p = Popen(db_cleanup_script, cwd=db_cleanup_path)
        stdout, stderr = p.communicate()
    else:
        print('File post cleanup file missing. Please execute manually.')

def check_patching_status(patch_loc, hostname):
    list_of_files = os.listdir(patch_loc)
    for each_file in list_of_files:
        if each_file.startswith('patchinstall_'):
            each_file = os.path.join(patch_loc, each_file)
            with open(each_file, 'r') as file:
                content = file.read()
                if 'Patch installation SUCCEEDED' in content:
                    print('Eagle Patch Installed Successfully for : ' + hostname + ', Log file is : ' + each_file)
                else:
                    print('Eagle Patch Installation Failed for : ' + hostname + ', Log file is : ' + each_file, '. Please re-apply the EAGLEPATCH manually.')


def writeBuildAppliedNumber(buildNumber, textfile):
    filename = os.path.join(os.path.abspath(os.path.dirname(__file__)), textfile)
    os.chmod(filename, 0o755)
    f = open(filename,"w+")
    f.write(buildNumber)
    f.close()
    os.chmod(filename, 0o444)
    print(buildNumber, 'is applied and been published in the flag file for future reference.')


def readBuildAppliedNumber(buildNumber, textfile):
    print('New Build to be applied is :', buildNumber)
    filename = os.path.join(os.path.abspath(os.path.dirname(__file__)), textfile)
    with open(filename) as f:
        for line in f:
            print('Old Build already applied is :', line)
            if line == buildNumber:
                f.close()
                return True
            print(buildNumber, 'is ready to be applied in Regression Regions.')
    return False

#path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'SQLbuildAppliedNumber.txt')
#print(path)

def delete_msgcenterfiles(folder_path):
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                os.remove(file_path)
                print(f"Deleted: {file_path}")
            except Exception as e:
                print(f"Error deleting {file_path}: {e}")