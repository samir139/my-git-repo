import hvac

VAULT_ADDR = "https://vault.engops.az.eagleinvsys.com"
VAULT_TOKEN = "hvs.CAESIJoB7lvsY7ZNQV64UDVSUI2XkmH38nAdSrm__Hd8dFXZGiQKHGh2cy5Fd3FTWE9wV1J6SFl0bko1UHRvU0k5ZVUQ4JfBlgU"

MOUNT_POINT = "infra"
SECRET_PATH = "vms/dev/esx-wellesley/r17-a00x-star"
#SECRET_PATH = "vms/dev/esx-wellesley/r17-e001-ld01"
SECRET_VERSION = 4   # optional


def read_vault_json():
    client = hvac.Client(
        url=VAULT_ADDR,
        token=VAULT_TOKEN
    )

    if not client.is_authenticated():
        raise Exception("Vault authentication failed")

    result = client.secrets.kv.v2.read_secret_version(
        mount_point=MOUNT_POINT,
        path=SECRET_PATH,
        #version=SECRET_VERSION,
        raise_on_deleted_version=True
    )

    return result["data"]["data"]

def get_vault_value(key_name):
    data = read_vault_json()
    return data.get(key_name)

eis_value = get_vault_value("eis.win.key")
print("eis.win.key =", eis_value)

ea_value = get_vault_value("ea.win.key")
print("eis.win.key =", ea_value)

AppPW = get_vault_value("AppPW")
print(AppPW)
