import requests, sys, json, time
from requests.auth import HTTPBasicAuth

def post_to_slack(webhook_url, channel, message, retries=3):
    payload = {
        "channel": channel,
        "text": message
    }
    for attempt in range(retries):
        try:
            response = requests.post(webhook_url, json=payload, timeout=10)
            response.raise_for_status()
            print("Message posted successfully!")
        except requests.exceptions.RequestException as e:
            print("Error posting message:", e)
            print("Attempt " + attempt + 1 + " failed: " + e)
            time.sleep(2 ** attempt)
    raise Exception("Failed to send message after retries.")

if len(sys.argv) != 2:
    print("Usage: python trigger_jenkins.py <job-name>")
    sys.exit(1)

job_name = sys.argv[1]

with open(r"E:\\Build_Automation\\configurations\\jenkins_params.json", "r") as f:
    config = json.load(f)

common = config.get("COMMON-INFO", {})
username = common.get("username")
api_token = common.get("api_token")

job_config = config.get(job_name)
if not job_config:
    print("No configuration found for job: ", job_name)
    sys.exit(1)

jenkins_url = job_config.get("jenkins_url")
params = {k: v for k, v in job_config.items() if k != "jenkins_url"}

build_url = jenkins_url + '/job/' + job_name + '/buildWithParameters'
response = requests.post(build_url, params=params, auth=HTTPBasicAuth(username, api_token))

if response.status_code == 201:
    print("Build triggered successfully.")
else:
    print("Failed to trigger build. Status: ", response.status_code, ", Response: ", response.text)

time.sleep(10)

job_api_url = jenkins_url + '/job/' + job_name + '/api/json?tree=builds[number,url,building]'
response = requests.get(job_api_url, auth=HTTPBasicAuth(username, api_token))
data = response.json()

running_build = next((b for b in data["builds"] if b["building"]), None)

if running_build:
    message_to_post = job_name + " API cycle initiated " + running_build['url']
    print(message_to_post)
    slack_webhook_url = "https://hooks.slack.com/services/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"
    slack_channel = "#sd_regression_upgrades"
    post_to_slack(slack_webhook_url, slack_channel, message_to_post)
else:
    print("No running build for this job.")
