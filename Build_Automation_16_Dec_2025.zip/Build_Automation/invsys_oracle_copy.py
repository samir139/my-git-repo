import paramiko, sys, os, platform, time, subprocess
from configparser import ConfigParser
from datetime import datetime
import tarfile
from dotenv import load_dotenv
load_dotenv()

def execute_command(host, port, username, private_key_path, command):
    print('HOSTNAME :', host)
    print('USERNAME :', username)
    print('COMMAND :', command)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    private_key=paramiko.RSAKey.from_private_key_file(private_key_path)
    ssh.connect(hostname=host,port=port,username=username, pkey=private_key)
    stdin, stdout, stderr = ssh.exec_command(command)
    for line in stdout:
        print(line.strip(), flush=True)
    print(stdout.read().decode(), flush=True)
    return ssh
    

def main(argv):
    now = datetime.now()
    try:
        hostname = sys.argv[1]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)
    for host in hostname.split(','):
        build_ini_file = host[0:host.find('-', host.find('-')+1)] + '.ini'
        print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        directory_name=os.getenv('build_version')
        staging_path=str(parser['BUILD_DIR']['stagingAppPath'])
        load_dotenv()
        startx_path=os.path.join(os.getenv('dailyBuild_path'),directory_name)

        port = parser['REGION_DETAILS']['port']
        username = parser['REGION_DETAILS']['username']
        #password = parser['REGION_DETAILS']['password']
        password = os.path.join(parser['REGION_DETAILS']['privatekey'], hostname.split('.')[0])

        date_string=now.strftime("%d-%m-%Y")
        new_name=f"{directory_name}_{date_string}"
        print("***********************************************************")
        print('RENAMING THE EXISTING DIRECTORY IN : ',host)
        print("***********************************************************" )
        exec_rename_directory ='cd '+ staging_path +' && ' \
                                'mv '+ directory_name + ' ' + new_name +' && ls -l'
    
        execute_command(host, port, username, password, exec_rename_directory)
#   
        print("***********************************************************")
        print('RENAME DIRECTORY COMPLETED IN :',host)
        print("***********************************************************")
        
        tar_file_name='eagle_invsys'+'.tar'
        
        tarf=tarfile.open(tar_file_name,'w')
        for root,dirs,files in os.walk(startx_path):
            for file in files:
                file_path=os.path.join(root,file)
                tarf.add(file_path,arcname=os.path.relpath(file_path,startx_path))
        tarf.close()
        destination = staging_path + '/' + directory_name+'/'
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        private_key = paramiko.RSAKey.from_private_key_file(password)
        ssh.connect(hostname=host, port=port, username=username, pkey=private_key)
        sftp=ssh.open_sftp()
        try:
            sftp.stat(destination)
        except FileNotFoundError:
            sftp.mkdir(destination)
        print("***********************************************************")
        print('COPY TAR FILE STARTED')
        print("***********************************************************")
        sftp.put(tar_file_name,destination+tar_file_name)
        print("***********************************************************")
        print('COPY TAR FILE COMPLETED')
        print("***********************************************************")
        exec_untar='cd '+ destination + ' && ' \
                    'tar -xvf ' + tar_file_name
        execute_command(host, port, username, password, exec_untar)
        print("***********************************************************")
        print('UN TAR IS COMPLETED')
        print("***********************************************************")    
        exec_remove_tar='cd '+ destination +' && ' \
                        'rm -rf ' + tar_file_name + ' && ls -l'
        execute_command(host, port, username, password, exec_remove_tar)

        exec_fullpermission = 'cd ' + staging_path + ' && ' \
                                                    'chmod -R 777 ' + directory_name + ' && ls -l'
        execute_command(host, port, username, password, exec_fullpermission)
        print("***********************************************************")
        print('BINARIES COPY COMPLETED')
        print("***********************************************************")


if __name__ == "__main__":
    main(sys.argv)   
    