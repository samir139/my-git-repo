import os, sys, paramiko
from configparser import ConfigParser
from dotenv import load_dotenv

import jiradetails
load_dotenv()


def search_and_replace(file_path, old_text, new_text):
    with open(file_path, 'r') as file:
        content = file.read()

    new_content = content.replace(old_text, new_text)
    with open(file_path, 'w') as file:
        file.write(new_content)
    print('Replaced ' + old_text + ' with ' + new_text + ' in ' + file_path)

def connection_execution(host, port, username, private_key_path, command):
    print('HOSTNAME :', host)
    print('USERNAME :', username)
    print('COMMAND :', command)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    private_key=paramiko.RSAKey.from_private_key_file(private_key_path)
    ssh.connect(hostname=host,port=port,username=username, pkey=private_key)
    stdin, stdout, stderr = ssh.exec_command(command)
    for line in stdout:
        print(line.strip(), flush=True)
    print(stdout.read().decode(), flush=True)
    return ssh

def replaceStringInControlFile(hostname, filePath, fileName, string_to_find, string_to_replace):
    findInFiles = 'find ' + filePath + ' -type f -name ' + fileName + ' -exec grep -l ' + string_to_find + ' {} \\;'
    replaceInFiles = ' -exec sed -i "s/' + string_to_find + '/' + string_to_replace + '/g" {} \\;'
    exec_replaceString = findInFiles + replaceInFiles
    connection_execution(host, port, username, private_key_path, exec_replaceString)

try:
    host = sys.argv[1]
except IndexError:
    print('Provide the Server Name as parameter')
    sys.exit(2)

hostname = host.split('.')[0]
build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))

build_details, buildVersion, build_number, build_status = jiradetails.get_jira_details()
print('BUILD VERSION :', buildVersion)
version = buildVersion[7:]

port = parser['REGION_DETAILS']['port']
username = parser['REGION_DETAILS']['username']
private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], hostname)

stagePath = '/apps/eagle/software/test_automate/' #str(parser['BUILD_DIR']['stagingAppPath'])
print('STAGE PATH :', stagePath)
erdLoc = stagePath + buildVersion + '/DATABASE/eagle_erd_' + version + '/oracle'
pkgLoc = stagePath + buildVersion + '/DATABASE/packages_' + version + '/oracle'
patchLoc = stagePath + buildVersion + '/EAGLE_PATCH'
print('EDM PATH :', erdLoc)
print('PACKAGE PATH :', pkgLoc)
print('EAGLE PATCH PATH :', patchLoc)

renameEDMSchemaCmd = 'mv sample_edm_input_control_file_schemas.txt edm_input_control_file_schemas.txt'
renameEDMSetupCmd = 'mv sample_edm_input_control_file_setup.txt edm_input_control_file_setup.txt'
renameEDMSliceCmd = 'mv sample_edm_slice_control_file.txt edm_slice_control_file.txt'
renamePkgCmd = 'mv sample_packages_input_control_file.txt packages_input_control_file.txt'

exec_fullpermission = 'cd ' + stagePath + ' && chmod -R 777 ' + buildVersion
#connection_execution(host, port, username, private_key_path, exec_fullpermission)

exec_rem_edmschemas = 'cd ' + erdLoc + ' && ' + renameEDMSchemaCmd
#connection_execution(host, port, username, private_key_path, exec_rem_edmschemas)
exec_rem_edmsetup = 'cd ' + erdLoc + ' && ' + renameEDMSetupCmd
#connection_execution(host, port, username, private_key_path, exec_rem_edmsetup)
exec_rem_edmslice = 'cd ' + erdLoc + ' && ' + renameEDMSliceCmd + ' && ls -l'
#connection_execution(host, port, username, private_key_path, exec_rem_edmslice)
exec_rem_package = 'cd ' + pkgLoc + ' && ' + renamePkgCmd + ' && ls -l'
#connection_execution(host, port, username, private_key_path, exec_rem_package)

#old_silentMode = parser['CONTROL_FILES']['from_silentmode'].replace("'", "")
#print('SILENT MODE GOING TO BE REPLACED FROM :', old_silentMode)
#new_silentMode = parser['CONTROL_FILES']['to_silentmode'].replace("'", "")
#print('SILENT MODE GOING TO BE REPLACED TO :', new_silentMode)
#replaceStringInControlFile(hostname, patchLoc, 'eaglepatch.ini', old_silentMode, new_silentMode)

old_staticconfig = parser['CONTROL_FILES']['from_staticconfig']
print('STATIC CONFIG GOING TO BE REPLACED FROM :', old_staticconfig)
new_staticconfig = parser['CONTROL_FILES']['to_staticconfig']
print('STATIC CONFIG GOING TO BE REPLACED TO :', new_staticconfig)
replaceStringInControlFile(hostname, patchLoc, 'eaglepatch.ini', '~/eagle', '/apps/eagle')

old_instdir_emshell = parser['CONTROL_FILES']['from_instdir_emshell']
print('INSTDIR EMSHELL MODE GOING TO BE REPLACED FROM :', old_instdir_emshell)
new_instdir_emshell = parser['CONTROL_FILES']['to_instdir_emshell']
print('INSTDIR EMSHELL MODE GOING TO BE REPLACED TO :', new_instdir_emshell)
replaceStringInControlFile(hostname, patchLoc, 'eaglepatch.ini', old_instdir_emshell, new_instdir_emshell)

#old_delta = parser['CONTROL_FILES']['from_delta'].replace("'", "")
#print('DELTA MODE GOING TO BE REPLACED FROM :', old_delta)
#new_delta = parser['CONTROL_FILES']['to_delta'].replace("'", "")
#print('DELTA MODE GOING TO BE REPLACED TO :', new_delta)
#replaceStringInControlFile(hostname, patchLoc, 'eaglepatch.ini', old_delta, new_delta)

#old_emailto = parser['CONTROL_FILES']['from_emailto']
#print('EMAIL TO GOING TO BE REPLACED FROM :', old_emailto)
#new_emailto = parser['CONTROL_FILES']['to_emailto']
#print('EMAIL TO GOING TO BE REPLACED TO :', new_emailto)
#replaceStringInControlFile(hostname, patchLoc, 'eaglepatch.ini', old_emailto, new_emailto)