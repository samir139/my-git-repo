import paramiko, sys, os, platform, time, subprocess
from configparser import ConfigParser
from datetime import datetime
import tarfile
from dotenv import load_dotenv

load_dotenv()

class eagle_services():

    def run_linux_service(self, host, port, username, private_key_path, command):
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        private_key=paramiko.RSAKey.from_private_key_file(private_key_path)
        ssh.connect(hostname=host,port=port,username=username, pkey=private_key)
        stdin, stdout, stderr = ssh.exec_command(command)
        for line in stdout:
            print(line.strip(), flush=True)
        print(stdout.read().decode(), flush=True)
        return ssh

now = datetime.now()
try:
    host = sys.argv[1]
    service = sys.argv[2]
except IndexError:
    print('No Environment Variable passed for applying build. Please provide the Environment Name.')
    sys.exit(2)
hostname = host.split('.')[0]
build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
parser = ConfigParser()
parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
services_path = str(parser['BUILD_DIR']['servicesPath'])
port = parser['REGION_DETAILS']['port']
username = parser['REGION_DETAILS']['username']
private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], hostname)
exec_start_command = parser['EXPORT_ORACLE']['export_path'] + '; cd ' + parser['BUILD_DIR']['servicesPath'] + '; ./start ALL; exit;'
exec_stop_command = parser['EXPORT_ORACLE']['export_path'] + '; cd ' + parser['BUILD_DIR']['servicesPath'] + '; ./stop ALL; exit;'
exec_status_command = parser['EXPORT_ORACLE']['export_path'] + '; cd ' + parser['BUILD_DIR']['servicesPath'] + '; ./status ALL; exit;'
exec_restart_command = parser['EXPORT_ORACLE']['export_path'] + '; cd ' + parser['BUILD_DIR']['servicesPath'] + '; ./restart ALL; exit;'
exec_service = eagle_services()
if service == 'START':
    exec_service.run_linux_service(host, port, username, private_key_path, exec_start_command)
if service == 'STOP':
    exec_service.run_linux_service(host, port, username, private_key_path, exec_stop_command)
if service == 'STATUS':
    exec_service.run_linux_service(host, port, username, private_key_path, exec_status_command)
if service == 'RESTART':
    exec_service.run_linux_service(host, port, username, private_key_path, exec_restart_command)
