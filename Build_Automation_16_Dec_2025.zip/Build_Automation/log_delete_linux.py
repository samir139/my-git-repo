
import paramiko, sys,os
from configparser import ConfigParser
from datetime import datetime





def execute_command(host, port, username, password, command):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=host,port=port,username=username, password=password)
    stdin, stdout, stderr = ssh.exec_command(command)
    for line in stdout:
        print(line.strip() )
    print(stdout.read().decode() )
    return ssh



def main(argv):
    now = datetime.now()
    try:
        host = sys.argv[1]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)

    build_ini_file = host[0:host.find('-', host.find('-')+1)] + '.ini'
    print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))

    port = parser['REGION_DETAILS']['port']
    username = parser['REGION_DETAILS']['username']
    password = parser['REGION_DETAILS']['password']
    print("stoping services in :",host)

    exec_stop_services='cd /apps/eagle/eaglemgr && ./stop ALL'
    execute_command(host, port, username, password, exec_stop_services)
    start=datetime.now()
    print("log files deleting started in :",host,'at',start.strftime('%d-%m-%Y - %H:%M:%S'))

    exec_log_delete='cd /apps/eagle/logs && find . -type f -name "*.log" -exec rm -f {} \;'
    execute_command(host, port, username, password, exec_log_delete)
    end=datetime.now()
    print("log files deleting completed in :",host,"at",end.strftime('%d-%m-%Y - %H:%M:%S'))
    print("starting services in :",host)

    exec_start_services='cd /apps/eagle/eaglemgr && ./start ALL'
    execute_command(host, port, username, password, exec_start_services)
if __name__ == "__main__":
    main(sys.argv)
