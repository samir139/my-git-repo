import sys, subprocess, os
from pathlib import Path
import multiprocessing
from multiprocessing import Pool, Lock, process, Pipe, Process
from configparser import ConfigParser

processes = []

def main(argv):
    host = sys.argv[1]
    for env_name in host.split (','):
        build_ini_file = host[0:host.find('-', host.find('-')+1)] + '.ini'
        print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        config_filename = build_ini_file
        path = Path(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        try:
            if path.is_file():
                print(f'The Configuration file {config_filename} is present.')
                print('python ApplyBuild.py ' + env_name)
                #process = subprocess.Popen('python ApplyBuild.py ' + env_name, shell=True)
                process = subprocess.Popen(["start", "cmd", "/k", 'python ApplyBuild.py ' + env_name], shell = True)
                processes.append(process)
                process.wait()
            else:
                print(f'The Configuration file {config_filename} missing please verify and re-apply the build')
        except OSError as error:
            print(error)


if __name__ == "__main__":
   main(sys.argv)
