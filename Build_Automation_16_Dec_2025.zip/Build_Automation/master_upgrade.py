import sys, subprocess, os
from pathlib import Path
from multiprocessing import Pool, Lock

processes = []

def main(argv):
    environment = sys.argv[1]
    build_type = sys.argv[2]
    for env_name in environment.split (','):
        config_filename = 'RunDeck_config_file_' + env_name + '.ini'
        path = Path(config_filename)
        try:
            if path.is_file():
                print(f'The Configuration file {config_filename} is present.')
                print('python windows_sql_region_upgrade.py ' + env_name + ' ' + build_type)
                code = 'python windows_sql_region_upgrade.py ' + env_name + ' ' + build_type
                #subprocess.call(code, shell=True)
                process = subprocess.Popen(code, shell=True)
                processes.append(process)
                process.wait()
            else:
                print(f'The Configuration file {config_filename} missing please verify and re-apply the build')
        except OSError as error:
            print(error)


if __name__ == "__main__":
   main(sys.argv)
