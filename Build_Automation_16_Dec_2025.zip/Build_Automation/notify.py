import requests

def send_slack_notification(token, channel, message):
    url = "https://slack.com/api/chat.postMessage"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-type": "application/json"
    }
    payload = {
        "channel": channel,
        "text": message
    }

    response = requests.post(url, json=payload, headers=headers)
    if response.status_code == 200 and response.json().get("ok"):
        print("Message sent successfully.")
    else:
        print(f"Failed to send message: {response.text}")

# Example usage:
slack_token = "raTYHK2fMmK8G6la3T6yRUht"
channel_id = "#sd-regression-support"  # or channel ID like "C1234567890"
message = "🚨 Alert: Test Message"

send_slack_notification(slack_token, channel_id, message)


#import requests, sys

#def post_to_slack(webhook_url, channel, message):
#    payload = {
#        "channel": channel,
#        "text": message
#    }

#    try:
#        response = requests.post(webhook_url, json=payload)
#        response.raise_for_status()
#        print("Message posted successfully!")
#    except requests.exceptions.RequestException as e:
#        print("Error posting message:", e)

#l_msg = sys.argv[1]
#message_to_post = 'Test Message by Samir'

#slack_webhook_url = "https://hooks.slack.com/services/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"
#slack_channel = "#regression-bbsr"
#print(message_to_post)
#post_to_slack(slack_webhook_url, slack_channel, message_to_post)
