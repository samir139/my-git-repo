import sys

import paramiko
import os
import time
import socket, subprocess
from configparser import ConfigParser
from scp import SCPClient
import read_vault


def read_config_ini_file(host):
    build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
    parser = ConfigParser()
    parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    return parser


def get_ssh_client(host):
    parser = read_config_ini_file(host)
    username = parser['REGION_DETAILS']['username']
    port = int(parser['REGION_DETAILS']['port'])
    private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], host.split('.')[0])
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    rsa_key = paramiko.RSAKey.from_private_key_file(private_key_path)
    ssh.connect(hostname=host, port=port, username=username, pkey=rsa_key)
    return ssh, parser


def execute_shell_script(ssh, command):
    try:
        stdin, stdout, stderr = ssh.exec_command(command)
        for line in stdout:
            print(line.strip(), flush=True)
        err = stderr.read().decode()
        if err:
            print("Error:", err)
    except Exception as e:
        print(e)


def copy_binaries(ssh, local_path, remote_path):
    try:
        with SCPClient(ssh.get_transport()) as scp:
            scp.put(local_path, remote_path)
        print(f"File copied to {remote_path}")
    except Exception as e:
        print(e)


def get_dns_ip_format(hostnames):
    parts = []
    for host in hostnames:
        try:
            result = subprocess.run(
                ["nslookup", host],
                capture_output=True,
                text=True
            )
            ip = "NOT_FOUND"
            address_lines_seen = 0
            for line in result.stdout.splitlines():
                if line.strip().startswith("Address:"):
                    address_lines_seen += 1
                    if address_lines_seen == 2:  # second "Address:" is the host IP
                        ip = line.split(":", 1)[1].strip()
                        break
            parts.append(f"DNS:{host},IP:{ip}")
        except Exception:
            parts.append(f"DNS:{host},IP:ERROR")
    return ",".join(parts)


def update_servers_section(ssh, xml_path, servers_to_add):
    sftp = ssh.open_sftp()
    try:
        with sftp.file(xml_path, 'r') as f:
            xml_content = f.read().decode()
        lines = xml_content.splitlines()
        start_index = next((i for i, line in enumerate(lines) if "<servers" in line), None)
        end_index = next((i for i, line in enumerate(lines) if "</servers>" in line), None)
        if start_index is None or end_index is None:
            print(f"ERROR: Could not find <servers> section in {xml_path}")
            return False
        existing_types = [line.split('type="')[1].split('"')[0] for line in lines[start_index:end_index] if
                          '<server' in line and 'type="' in line]
        insert_lines = ["    " + srv for srv in servers_to_add if
                        srv.split('type="')[1].split('"')[0] not in existing_types]
        if insert_lines:
            lines = lines[:end_index] + insert_lines + lines[end_index:]
            new_content = "\n".join(lines) + "\n"
            with sftp.file(xml_path, 'w') as f:
                f.write(new_content.encode())
            print(f"Updated {xml_path}. Added servers:")
            for l in insert_lines:
                print(l.strip())
        else:
            print("No new servers to add. File unchanged.")
        return True
    finally:
        sftp.close()


def main():
    home_dir = '/apps/eagle'
    install_dir = 'Eagle_Install'
    startx_dir = '\\\\startx\\Dailybuilds\\EagleMC2\\'
    mc2ZipFile = 'mc2-2022.09.20.1.zip'
    mc2installer = 'mc2installer-2021.3.17.zip'
    host = sys.argv[1] # ex. 'o171-e001-la03.eagleinvsys.com'
    mc2_extractservice_nodes = sys.argv[2] #ex. 'o171-e001-la03.eagleinvsys.com,o171-e001-la04.eagleinvsys.com'

    dns_ip_value = get_dns_ip_format(mc2_extractservice_nodes.split(","))
    domain_name = f"DNS:{'.'.join(host.split('.')[-2:])}"
    dns_val = domain_name + ',' + dns_ip_value

    ssh, parser = get_ssh_client(host)
    # read vault details
    storekeypass = read_vault.read_secret_from_vault("configurations/vault_config.ini", "r17-a00x-star", "storepass")
    #print("Fetched storepass:", storekeypass)

    print(f'TASK : Stop eagle Services...')
    cmd = f'cd {home_dir}/eaglemgr && ./stop ALL'
    print('Executing command :', cmd)
    execute_shell_script(ssh, cmd)

    if sys.argv[3] == 'SERVER_SVC':

        print('Master TASK : Kafka Server installation started.')

        print(f'TASK : Taking backup of existing kafka dirs...')
        #cmd = f'cd {home_dir} && rm -rf estar/tpe/{{cfg,servers}}/kafkaservice/{{kafka,zookeeper}}'
        cmd = (f'mv {home_dir}/estar/tpe/cfg/kafkaservice/kafka {home_dir}/estar/tpe/cfg/kafkaservice/kafka_bkp && ' +
               f'mv {home_dir}/estar/tpe/cfg/kafkaservice/zookeeper {home_dir}/estar/tpe/cfg/kafkaservice/zookeeper_bkp && ' +
               f'mv {home_dir}/estar/tpe/servers/kafkaservice/kafka {home_dir}/estar/tpe/servers/kafkaservice/kafka_bkp && ' +
               f'mv {home_dir}/estar/tpe/servers/kafkaservice/zookeeper {home_dir}/estar/tpe/servers/kafkaservice/zookeeper_bkp ')
        print('Executing command :', cmd)
        execute_shell_script(ssh, cmd)

        print(f'TASK : Create Eagle_Install Directory...')
        cmd = f'cd {home_dir} && mkdir -p {home_dir}/{install_dir} && cd {home_dir}/{install_dir} && rm -rf mc2* && chmod -R 777 {home_dir}/{install_dir} && ls -d {home_dir}/{install_dir}'
        print('Executing command :', cmd)
        execute_shell_script(ssh, cmd)

        local_path = startx_dir + mc2ZipFile
        remote_path = f'{home_dir}/{install_dir}/{mc2ZipFile}'
        print(f'TASK : Copy EagleMC2 zip file...')
        print(f'Coping files from {local_path} to {remote_path}')
        copy_binaries(ssh, local_path, remote_path)

        print(f'TASK : Execute permission to EagleMC2 zip file...')
        cmd = f'cd {home_dir}/{install_dir} && chmod -R 777 *.zip && ls -l'
        print('Executing command :', cmd)
        execute_shell_script(ssh, cmd)

        print(f'TASK : Unzip and give execute permission to EagleMC2 zip file...')
        cmd = f'cd {home_dir}/{install_dir} && unzip {mc2ZipFile} -d {mc2ZipFile.removesuffix(".zip")} && cd {mc2ZipFile.removesuffix(".zip")} && unzip {mc2installer} -d {mc2installer.removesuffix(".zip")} && cd {mc2installer.removesuffix(".zip")} && chmod -R 777 install_mc2.sh mc2configurator.jar'
        print('Executing command :', cmd)
        execute_shell_script(ssh, cmd)

        print(f'TASK : Copy mc2 dir into cmw_staging_folder...')
        cmd = f'cd {home_dir} && rm -rf {home_dir}/estar/tpe/data/msgcenter/cmw_staging_folder/*.zip && cp -r {home_dir}/{install_dir}/{mc2ZipFile} {home_dir}/estar/tpe/data/msgcenter/cmw_staging_folder/ && chmod -R 777 {home_dir}/estar/tpe/data/msgcenter/cmw_staging_folder/*.zip'
        print('Executing command :', cmd)
        execute_shell_script(ssh, cmd)

        create_mc2_dir = (
            f'cd {home_dir}/estar/tpe/dynamic && mkdir -p mc2 && chmod -R 777 mc2 && cd mc2 && mkdir -p private && cd private && mkdir -p kafkaservice'
        )
        print('TASK : Create mc2 dir...')
        print('Executing command :', create_mc2_dir)
        execute_shell_script(ssh, create_mc2_dir)

        ld_library_path = parser['EXPORT_ORACLE']['export_path']
        oracle_home = parser['EXPORT_ORACLE']['ORACLE_HOME']
        export_oracle_home_path = f'cd {home_dir} && export EAGLE_PATH_TO_ROOT={home_dir}'
        export_ld_library_path = f'&& export LD_LIBRARY_PATH={ld_library_path}'
        export_mc2_extractservice_nodes = f'cd {home_dir} && export MC2_EXTRACTSERVICE_NODES={mc2_extractservice_nodes}'

        exec_mc2installer = (
            f'cd {home_dir} && export EAGLE_PATH_TO_ROOT={home_dir} '
            f'&& export LD_LIBRARY_PATH={ld_library_path}; export ORACLE_HOME={oracle_home} '
            f'&& export MC2_EXTRACTSERVICE_NODES={mc2_extractservice_nodes} '
            f'&& cd {home_dir}/{install_dir}/{mc2ZipFile.removesuffix(".zip")}/{mc2installer.removesuffix(".zip")} '
            f'&& ./install_mc2.sh {home_dir}/estar/tpe/data/msgcenter/cmw_staging_folder/{mc2ZipFile}'
        )
        print('TASK : Execute mc2installer...')
        print('Executing command :', exec_mc2installer)
        execute_shell_script(ssh, exec_mc2installer)
        
        openssl_generate_script = (
            f'cd {home_dir}/estar/tpe/dynamic/mc2/private/kafkaservice && rm -rf *.pem *.jks *.pkcs12'
            f' && openssl req -x509 -newkey rsa:4096 -extensions SAN -reqexts SAN -subj "/C=US/CN=.{domain_name}" -config <(echo "[req]"; echo "distinguished_name=req"; echo "[SAN]"; echo "subjectAltName={dns_val}") -keyout kafka-server-key.pem -out kafka-server-cert.pem -days 365 -nodes '
            ' && cat kafka-server-key.pem kafka-server-cert.pem > kafka-server-keycert.pem'
            f' && openssl pkcs12 -export -in kafka-server-keycert.pem -out server.keystore.pkcs12 -name kafkasrv -noiter -nomaciter -passout pass:{storekeypass}'
            f' && keytool -import -v -trustcacerts -alias kafkaserver -file kafka-server-cert.pem -keystore server.truststore.jks -storepass {storekeypass} -noprompt '
            f' && keytool -v -importkeystore -srckeystore server.keystore.pkcs12 -srcstoretype PKCS12 -srcstorepass {storekeypass} -destkeystore server.keystore.jks -deststoretype JKS -deststorepass {storekeypass} '
        )
        print('TASK : Generate SSL keys...')
        print('Executing command :', openssl_generate_script)
        execute_shell_script(ssh, openssl_generate_script)

        create_epasswd_file = (
            f'cd {home_dir}/eaglemgr'
            f' && ./cmdmgr.bin credentials --type=aes --action=add --credtype=Oracle --name=kafkaservice_key --user=kafkaservice_key --pass={storekeypass} --file=../estar/tpe/dynamic/mc2/private/kafkaservice/epasswd'
            f' && ./cmdmgr.bin credentials --type=aes --action=add --credtype=Oracle --name=kafkaservice_keystore --user=kafkaservice_keystore --pass={storekeypass} --file=../estar/tpe/dynamic/mc2/private/kafkaservice/epasswd'
            f' && ./cmdmgr.bin credentials --type=aes --action=add --credtype=Oracle --name=kafkaservice_truststore --user=kafkaservice_truststore --pass={storekeypass} --file=../estar/tpe/dynamic/mc2/private/kafkaservice/epasswd'
            ' && ./cmdmgr.bin credentials --action=list --type=aes --file=../estar/tpe/dynamic/mc2/private/kafkaservice/epasswd'
        )
        print('TASK : Create epasswd file...')
        print('Executing command :', create_epasswd_file)
        execute_shell_script(ssh, create_epasswd_file)

        enable_ssl_for_kafkaservice = r"""
yml_file="/apps/eagle/estar/tpe/cfg/kafkaservice/kafka-service.yml"

block=$(cat <<'EOF'
eagle.enable.ssl: true
    eagle.kafka.instance.kafkaBrokerConfigs:
        ssl.client.auth: required
EOF
)

if grep -q "^eagle.enable.ssl:" "$yml_file"; then
    echo "eagle.enable.ssl Block already exists — skipping."
else
    echo "" >> "$yml_file"
    echo "$block" >> "$yml_file"
    echo "eagle.enable.ssl Block appended successfully."
fi
"""
        print('TASK : Enable SSL for kafkaservice...')
        execute_shell_script(ssh, enable_ssl_for_kafkaservice)

        add_params_db_conn = r"""
file="/apps/eagle/cfg/db_connection.ini"

if grep -q "^\[kafkaservice_key\]" "$file"; then
    echo "kafka Service Sections already exist — skipping."
else
    echo "" >> "$file"
    cat <<'EOF' >> "$file"
[kafkaservice_key]
DBType=
DBName=kafkaservice_key
EstarName=kafkaservice_key
Credfile=estar/tpe/dynamic/mc2/private/kafkaservice/epasswd

[kafkaservice_keystore]
DBType=
DBName=kafkaservice_keystore
EstarName=kafkaservice_keystore
Credfile=estar/tpe/dynamic/mc2/private/kafkaservice/epasswd

[kafkaservice_truststore]
DBType=
DBName=kafkaservice_truststore
EstarName=kafkaservice_truststore
Credfile=estar/tpe/dynamic/mc2/private/kafkaservice/epasswd
EOF
    echo "kafka Service Sections appended successfully."
fi
"""
        print('TASK : Adding new parameters to db_connection.ini file...')
        execute_shell_script(ssh, add_params_db_conn)

        xml_path = f"{home_dir}/cfg/system.xml"
        servers = [
            '<server type="extractservice" offset="220" />',
            '<server type="kafkaservice" offset="320" />',
            '<server type="eaglejmsbroker_ibmmq" ignorewsdb="0" />',
            '<server type="mc2services" offset="220" />',
            '<server type="mc2redisservice" />',
            '<server type="mc2kafkaservice" offset="320" />'
        ]
        print('TASK : Update servers section...')
        update_servers_section(ssh, xml_path, servers)

        print('Master TASK : Kafka Server installation completed.')

    if sys.argv[3] == 'CLIENT_SVC':
        print('Master TASK : Kafka Client installation started.')

        create_kafka_ssl_client = f'cd {home_dir}/estar/tpe/dynamic/mc2/private && mkdir -p kafka_ssl_client && chmod -R 777 kafka_ssl_client'
        print('TASK : Create kafka ssl client directory...')
        print('Executing command :', create_kafka_ssl_client)
        execute_shell_script(ssh, create_kafka_ssl_client)

        create_openssl_script = (
                    f'cd {home_dir}/estar/tpe/dynamic/mc2/private/kafka_ssl_client && rm -rf *.pem *.jks *.pkcs12 && ' +
                    f'openssl req -x509 -newkey rsa:4096 -extensions SAN -reqexts SAN -subj "/C=US/CN=*.{domain_name}" -config <(echo "[req]"; echo "distinguished_name=req"; echo "[SAN]"; echo "subjectAltName={dns_val}") -keyout keyfile.pem -out certfile.pem -days 365 -passout pass:{storekeypass} ')
        print('TASK : create open ssl key...')
        print('Executing command :', create_openssl_script)
        execute_shell_script(ssh, create_openssl_script)

        create_ssl_key = (f'cd {home_dir}/estar/tpe/dynamic/mc2/private/kafka_ssl_client && ' +
                          'cat keyfile.pem certfile.pem > keycert.pem && ' +
                          f'openssl pkcs12 -export -in keycert.pem -out client.keystore.pkcs12 -name kafkacli -noiter -nomaciter -passin pass:{storekeypass} -passout pass:{storekeypass} && ' +
                          f'keytool -import -v -trustcacerts -alias kafkaclient -file certfile.pem -keystore client.truststore.jks -storepass {storekeypass} -noprompt && ' +
                          f'keytool -v -importkeystore -srckeystore client.keystore.pkcs12 -srcstoretype PKCS12 -destkeystore client.keystore.jks -deststoretype JKS -deststorepass {storekeypass} -srcstorepass {storekeypass} -alias kafkacli -noprompt && ' +
                          f'keytool -import -v -trustcacerts -alias kafkaservice -file ../kafkaservice/kafka-server-cert.pem -keystore client.truststore.jks -deststorepass {storekeypass} -noprompt')
        print('TASK : create open ssl key for kafka ssl client...')
        print('Executing command :', create_ssl_key)
        execute_shell_script(ssh, create_ssl_key)

        copy_kafka_key = (
                    f'cp {home_dir}/estar/tpe/dynamic/mc2/private/kafkaservice/kafka-server-cert.pem ./cafile.pem && ' +
                    f'cd {home_dir}/estar/tpe/dynamic/mc2/private/kafkaservice && ' +
                    f'keytool -import -v -trustcacerts -alias kafkaclient -file {home_dir}/estar/tpe/dynamic/mc2/private/kafka_ssl_client/certfile.pem -keystore server.truststore.jks -storepass {storekeypass} -noprompt ')
        print('TASK : copy kafka ssl client key to server...')
        print('Executing command :', copy_kafka_key)

        create_epasswd_file_client = (
            f'cd {home_dir}/eaglemgr'
            f' && ./cmdmgr.bin credentials --type=aes --action=add --credtype=Oracle --name=kafkaservice_key --user=kafkaservice_key --pass={storekeypass} --file=../estar/tpe/dynamic/mc2/private/kafkaservice/epasswd'
            f' && ./cmdmgr.bin credentials --type=aes --action=add --credtype=Oracle --name=kafkaservice_keystore --user=kafkaservice_keystore --pass={storekeypass} --file=../estar/tpe/dynamic/mc2/private/kafkaservice/epasswd'
            f' && ./cmdmgr.bin credentials --type=aes --action=add --credtype=Oracle --name=kafkaservice_truststore --user=kafkaservice_truststore --pass={storekeypass} --file=../estar/tpe/dynamic/mc2/private/kafkaservice/epasswd'
            ' && ./cmdmgr.bin credentials --action=list --type=aes --file=../estar/tpe/dynamic/mc2/private/kafkaservice/epasswd'
        )
        print('TASK : Create epasswd file client...')
        print('Executing command :', create_epasswd_file_client)
        execute_shell_script(ssh, create_epasswd_file_client)

        add_params_db_conn = r"""
    file="/apps/eagle/cfg/db_connection.ini"

if grep -q "^\[mc2ejmkey\]" "$file"; then
    echo "kafka Service Sections already exist — skipping."
else
    echo "" >> "$file"
    cat <<EOF >> "$file"
[mc2ejmkey]
DBType=Oracle
DBName=mc2ejmkey
EstarName=mc2ejmkey
Credfile=estar/tpe/dynamic/mc2/private/kafka_ssl_client/epasswd

[mc2ejmkeystore]
DBType=Oracle
DBName=mc2ejmkeystore
EstarName=mc2ejmkeystore
Credfile=estar/tpe/dynamic/mc2/private/kafka_ssl_client/epasswd

[mc2ejmtruststore]
DBType=Oracle
DBName=mc2ejmtruststore
EstarName=mc2ejmtruststore
Credfile=estar/tpe/dynamic/mc2/private/kafka_ssl_client/epasswd

[mc2pykafka]
DBType=Oracle
DBName=mc2pykafka
EstarName=mc2pykafka
Credfile=estar/tpe/dynamic/mc2/private/kafka_ssl_client/epasswd
EOF
    echo "kafka Service Sections appended successfully."
fi
        """
        print('TASK : Add mc2 services epasswd file client...')
        #print('Executing command :', add_params_db_conn)
        execute_shell_script(ssh, add_params_db_conn)

        create_mc2_dir_dynamic = f'cd {home_dir}/estar/tpe/dynamic/mc2 && mkdir -p cfg && chmod -R 777 cfg '
        print('TASK : Add mc2 cfg dir inside dynamic...')
        print('Executing command :', create_mc2_dir_dynamic)
        execute_shell_script(ssh, create_mc2_dir_dynamic)

        enable_ssl_for_extractservice = r"""
yml_file="/apps/eagle/estar/tpe/dynamic/mc2/cfg/extractservice.yml"

block=$(cat <<'EOF'
eagle.kafka.camel.defaultCfg.connectionParameters.securityProtocol: SSL
---
spring:
profiles: extractservice-lb
application:
name: extractservice-lb
eagle.pyservice.environment:
SECURE_KAFKASERVICE: 1
EOF
)

if grep -q "^eagle.kafka.camel.defaultCfg.connectionParameters.securityProtocol: SSL" "$yml_file"; then
    echo "extractservice-lb Block already exists — skipping."
else
    echo "" >> "$yml_file"
    echo "$block" >> "$yml_file"
    echo "extractservice-lb Block appended successfully."
fi
"""
        print('TASK : Enable SSL for extractservice...')
        execute_shell_script(ssh, enable_ssl_for_extractservice)

        xml_path_client = f"{home_dir}/cfg/system.xml"
        clientservers = [
            '<server type="extractservice" offset="220" />',
            '<server type="kafkaservice" offset="320" />',
            '<server type="eaglejmsbroker_ibmmq" ignorewsdb="0" />',
            '<server type="mc2services" offset="220" />',
            '<server type="mc2redisservice" />',
            '<server type="mc2kafkaservice" offset="320" />'
        ]
        print('TASK : Update servers section...')
        update_servers_section(ssh, xml_path_client, clientservers)

        print('Master TASK : Kafka Client installation completed.')
    
#    print("Task done, now sleeping for 2 minutes...")
#    time.sleep(120)
    
#    print(f'TASK : Start eagle Services...')
#    cmd = f'cd {home_dir}/eaglemgr && ./start ALL'
#    print('Executing command :', cmd)
#    execute_shell_script(ssh, cmd)
    
#    print("Task done, now sleeping for 2 minutes...")
#    time.sleep(120)
    
#    print(f'TASK : Check status of eagle Services...')
#    cmd = f'cd {home_dir}/eaglemgr && ./status starweb'
#    print('Executing command :', cmd)
#    execute_shell_script(ssh, cmd)
    
    ssh.close()


if __name__ == "__main__":
    main()