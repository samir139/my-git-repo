import sys

from cryptography.fernet import Fernet
import os

# Load or create secret key
if not os.path.exists('secret.key'):
    key = Fernet.generate_key()
    with open('secret.key', 'wb') as key_file:
        key_file.write(key)
else:
    with open('secret.key', 'rb') as key_file:
        key = key_file.read()

fernet = Fernet(key)


# Check if region and username exist
def entry_exists(region, username):
    if not os.path.exists('secretfile.txt'):
        return False  # File doesn't exist, so entry can't exist
    with open('secretfile.txt', 'r') as file:
        for line in file:
            if not line.strip():
                continue
            parts = dict(item.split(':', 1) for item in line.strip().split(','))
            if parts.get('region') == region and parts.get('username') == username:
                return True
    return False


# Add entry if not present
def add_entry(region, username, password):
    if entry_exists(region, username):
        print('Entry for region ' + region + ' and username ' + username + ' already exists.')
        return
    encrypted_password = fernet.encrypt(password.encode()).decode()
    entry = 'region:' + region + ',username:' + username + ',password:' + encrypted_password + '\n'
    with open('secretfile.txt', 'a') as file:
        file.write(entry)
    print('Entry added for region ' + region + ' and username ' + username +'.')


# Retrieve and decrypt password
def get_password(region, username):
    if not os.path.exists('secretfile.txt'):
        return None
    with open('secretfile.txt', 'r') as file:
        for line in file:
            if not line.strip():
                continue
            parts = dict(item.split(':', 1) for item in line.strip().split(','))
            if parts.get('region') == region and parts.get('username') == username:
                encrypted_password = parts['password']
                decrypted_password = fernet.decrypt(encrypted_password.encode()).decode()
                return decrypted_password
    return None


cmd_type = sys.argv[1]

if cmd_type == 'WRITE':
    region_name = sys.argv[2]
    username = sys.argv[3]
    passwd = sys.argv[4]
    add_entry(region_name, username, passwd)

if cmd_type == 'READ':
    region_name = sys.argv[2]
    username = sys.argv[3]
    password = get_password(region_name, username)
    if password:
        print('Password for region ' + region_name + ' and username ' + username + ' : ' + password)
    else:
        print("No matching entry found.")
