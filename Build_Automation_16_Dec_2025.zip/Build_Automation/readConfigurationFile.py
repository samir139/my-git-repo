import sys, os
from configparser import ConfigParser

def readConfigFile(hostname):
    #hostname = sys.argv[1]
    for host in hostname.split(','):
        build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
        if os.path.exists(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file)):
            print(build_ini_file, 'file present.')
        else:
            print(build_ini_file, 'file missing.')
            sys.exit(2)

        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
    return parser