import hvac
import configparser

def read_secret_from_vault(config_file, env, secret_key):
    config = configparser.ConfigParser()
    config.read(config_file)
    vault_addr = config.get("VAULT", "address")
    token = config.get("VAULT", "token")
    mount_point = config.get("VAULT", "mount_point", fallback="infra")
    secret_path = config.get("VAULT", "secret_path") + '/' + env
    kv_version = config.getint("VAULT", "kv_version", fallback=2)
    try:
        client = hvac.Client(url=vault_addr, token=token)

        if not client.is_authenticated():
            raise Exception("Vault authentication failed.")

        if kv_version == 2:
            response = client.secrets.kv.v2.read_secret_version(
                mount_point=mount_point,
                path=secret_path,
                raise_on_deleted_version=True
            )
            secret_data = response.get("data", {}).get("data", {})
        else:
            response = client.secrets.kv.v1.read_secret(
                mount_point=mount_point,
                path=secret_path
            )
            secret_data = response.get("data", {})

        value = secret_data.get(secret_key)
        return value

    except Exception as e:
        print(f"Error reading secret: {e}")
        return None


#if __name__ == "__main__":
#    storekeypass = read_secret_from_vault("configurations/vault_config.ini", "r17-a00x-star", "storepass")
#    print("Fetched storepass:", storekeypass)
