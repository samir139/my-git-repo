import requests
import sys
import paramiko
import io, os
from dotenv import load_dotenv
load_dotenv()

def get_host_and_key(hostname):
    found = False
    secret_data = getSecretFromVault(url, vault_token)
    for key, value in secret_data.items():
        if key.startswith("app.") and key.endswith(".host") and value == hostname:
            prefix = key.rsplit('.', 1)[0]
            related_key = f"{prefix}.key"
            if related_key in secret_data:
                id_rsa_value = secret_data[related_key].replace("EOR", "\n")
                connection_execution(value, '22', 'eagle', id_rsa_value, 'cd /apps/eagle && ls -l')
            else:
                print(f"{related_key} not found in secrets.")
            found = True
            break

    if not found:
        print(f"No matching host value found: {hostname}")

def getSecretFromVault(url, vault_token):
    headers = {'X-Vault-Token': vault_token}
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        secret_data = response.json()['data']['data']
        #print(secret_data)
    else:
        print("Failed to fetch secret:", response.status_code)
    return secret_data

def connection_execution(host, port, username, private_key_string, command):
    print('Connecting to', host, '...')
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        key_file_obj = io.StringIO(private_key_string)
        private_key = paramiko.RSAKey.from_private_key(key_file_obj)
        ssh.connect(hostname=host, username=username, port =port, pkey=private_key)
        stdin, stdout, stderr = ssh.exec_command(command)
        for line in stdout:
            print(line.strip(), flush=True)
        print(stdout.read().decode(), flush=True)
        return ssh
    except Exception as e:
            print(e)

vault_url = 'https://vault.engops.az.eagleinvsys.com'
vault_token = os.environ.get('VAULT_TOKEN')
if not os.environ.get('VAULT_TOKEN'):
    raise EnvironmentError("VAULT_TOKEN environment variable is not set.")

mount_point = sys.argv[1]
secret_path = sys.argv[2]
vault_environment = sys.argv[3]
url = f'{vault_url}/v1/{mount_point}/data/{secret_path}/{vault_environment}'
print('Getting details from URL : ', url)

getSecretFromVault(url, vault_token)

linux_server = sys.argv[4]
get_host_and_key(linux_server)