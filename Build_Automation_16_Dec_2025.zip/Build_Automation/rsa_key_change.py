import sys, paramiko


def append_eor_and_flatten(file_path_1, file_path_2):
    with open(file_path_1, 'r') as file:
        lines = file.readlines()

    lines = [line.strip() for line in lines]
    processed_lines = [line + 'EOR' if i < len(lines) - 1 else line for i, line in enumerate(lines)]
    single_line_output = ''.join(processed_lines)

    with open(file_path_2, 'w') as file:
        file.write(single_line_output)

def remove_eor_and_new_line():
    hostname = 'r17-a003-le01.eagleaccess.com'
    port = '22'
    username = 'eagle'
    file_path = r'E:\Test\rsa_key_sl.txt'
    file_path_ml = r'E:\Test\rsa_key_ml.txt'

    old_string = 'EOR'
    new_string = '\r\n'

    with open(file_path, 'r') as file:
        file_contents = file.read()
    updated_contents = file_contents.replace(old_string, new_string)
    print(updated_contents)
    with open(file_path_ml, 'w') as file:
        file.write(updated_contents)

    with open(file_path_ml, 'r') as file:
        lines = file.readlines()
        non_blank_lines = [line for line in lines if line.strip()]

    with open(file_path_ml, 'w') as file:
        file.writelines(non_blank_lines)

    print(file_path_ml, "password file updated...")

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    private_key = paramiko.RSAKey.from_private_key_file(file_path_ml)
    ssh.connect(hostname=hostname, port=port, username=username, pkey=private_key)
    stdin, stdout, stderr = ssh.exec_command('cd /apps/eagle && ls -l')
    for line in stdout:
        print(line.strip(), flush=True)
        print(stdout.read().decode(), flush=True)

#orig_file = sys.argv[1]
#sl_file = sys.argv[2]
#output = append_eor_and_flatten(orig_file, sl_file)

remove_eor_and_new_line()
