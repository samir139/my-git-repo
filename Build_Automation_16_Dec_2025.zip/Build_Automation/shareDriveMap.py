import os, win32wnet, win32netcon

def mapDrive(drive, networkPath, user, password, force=0):
    print(networkPath)
    if (os.path.exists(drive)):
        print(drive, " Drive in use, trying to unmap...")
        if force:
            try:
                win32wnet.WNetCancelConnection2(drive, 1, 1)
                print(drive, "successfully unmapped...")
            except:
                print(drive, "Unmap failed, This might not be a network drive...")
                return -1
        else:
            print("Non-forcing call. Will not unmap...")
            return -1
    else:
        print(drive, " drive is free...")
    if (os.path.exists(networkPath)):
        print(networkPath, " is found...")
        print("Trying to map ", networkPath, " on to ", drive, " .....")
        try:
            win32wnet.WNetAddConnection2(win32netcon.RESOURCETYPE_DISK, drive, networkPath, None, user, password)
        except:
            print("Unexpected error...")
            return -1
        print("Mapping successful")
        return 1
    else:
        print("Network path unreachable...")
        return -1

def unmapDrive(drive, force=0):
    if (os.path.exists(drive)):
        print("drive in use, trying to unmap...")
        if force == 0:
            print("Executing un-forced call...")
        try:
            win32wnet.WNetCancelConnection2(drive, 1, force)
            print(drive, "successfully unmapped...")
            return 1
        except:
            print("Unmap failed, try again...")
            return -1
    else:
        print(drive, " Drive is already free...")
        return -1
