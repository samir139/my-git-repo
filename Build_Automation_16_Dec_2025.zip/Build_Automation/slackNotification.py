import requests, sys, time
import jiradetails
import cst_get_jira_details
import urllib3
import emailNotification

# Disable the insecure HTTPS warning
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def post_to_slack(webhook_url, channel, message):
    payload = {
        "channel": channel,
        "text": message
    }

    try:
        response = requests.post(webhook_url, json=payload, verify=False)
        response.raise_for_status()
        print("Message posted successfully!")
    except Exception as e:
        print("Error posting message:")
        emailNotification.send_mail("Unable to send slack notification, please send manually for " + message + " in " + channel)



l_msg = sys.argv[1]
env = sys.argv[2] if len(sys.argv) > 2 else None
if env == None:
    build_details, build_version, build_number, build_status = jiradetails.get_jira_details()
    message_to_post = 'The Eagle ' + build_version.replace(build_version[:7], '') + ' ' +  l_msg[:-5] + build_number
else:
    build_details, build_version, build_number, build_status, startx_path = cst_get_jira_details.get_jira_details(env)
    message_to_post = 'The Eagle ' + build_version.replace(build_version[:7], '') + ' for ' + l_msg[:-5] + build_number

slack_webhook_url = "https://hooks.slack.com/services/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"
slack_channel = "#sd_regression_upgrades"
print(message_to_post)
#post_to_slack(slack_webhook_url, slack_channel, message_to_post)
