import requests, sys, time
import jiradetails
import urllib3
import emailNotification

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def post_to_slack(webhook_url, channel, message, retries=3, backoff_factor=2):
    payload = {
        "channel": channel,
        "text": message
    }
    for attempt in range(retries):
        try:
            response = requests.post(webhook_url, json=payload, verify=False)
            response.raise_for_status()
            print("Message posted successfully!")
        except requests.exceptions.RequestException as e:
            print(f"[Attempt {attempt + 1}] Error posting message: {e}")
            emailNotification.send_mail('Unable to post message to Slack')
            if attempt < retries - 1:
                sleep_time = backoff_factor ** attempt
                print(f"Retrying in {sleep_time} seconds...")
                time.sleep(sleep_time)
            else:
                print("Max retries reached. Giving up.")
                raise

build_details, build_version, build_number, build_status = jiradetails.get_jira_details()

l_msg = sys.argv[1]
message_to_post = 'The Eagle ' + build_version.replace(build_version[:7], '') + ' ' +  l_msg[:-5] + build_number

slack_webhook_url = "https://hooks.slack.com/services/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"
slack_channel = "#sd_regression_upgrades"
print(message_to_post)
post_to_slack(slack_webhook_url, slack_channel, message_to_post)
