import os
import re
import sys
import shutil
import paramiko
import time
from datetime import datetime
from configparser import ConfigParser
from dotenv import load_dotenv
load_dotenv()

#from common.read_vault_config import VaultKeyFetcher

sys.stdout.reconfigure(encoding='utf-8', line_buffering=True)

class EagleCopyStage:
    def __init__(self, hostname):
        self.hostname = hostname
        self.startx_path = os.getenv('dailyBuild_path')
        self.build_version = os.getenv('build_version')
        self.short_hostname = hostname.split(".")[0]
        self.folders_to_copy = self.determine_copy_mode()
        self.use_sftp = "la" in self.short_hostname or "le" in self.short_hostname
        self.sftp = None
        self.transport = None
        #fetcher = VaultKeyFetcher(self.host)
        #self.private_key = fetcher.get_private_key()

    def determine_copy_mode(self):
        short_hostname = self.short_hostname.split(".")[0]
        print(f"Short hostname detected: {short_hostname}")

        if "ww" in short_hostname:
            print("Environment: WW → EAGLE_PATCH")
            return ["EAGLE_PATCH"]
        elif "wr" in short_hostname:
            print("Environment: WR → EAGLE_PATCH")
            return ["EAGLE_PATCH"]
        elif "wa" in short_hostname:
            print("Environment: WA → DATABASE, EAGLE_PATCH")
            return ["DATABASE", "EAGLE_PATCH"]
        elif "la" in short_hostname or "le" in short_hostname:
            print("Environment: LA/LE → Upload DATABASE, EAGLE_PATCH via SFTP")
            return ["DATABASE", "EAGLE_PATCH"]
        else:
            print("Default: DATABASE, EAGLE_PATCH")
            return ["DATABASE", "EAGLE_PATCH"]

    @staticmethod
    def count_files_in_dir(path):
        if not os.path.exists(path):
            return 0
        return sum(len(files) for _, _, files in os.walk(path))

    def copy_folder(self, src, dest):
        if not os.path.exists(src):
            print(f"Source folder not found: {src}", flush=True)
            return 0
        os.makedirs(dest, exist_ok=True)
        file_count = 0
        for root, _, files in os.walk(src):
            rel_path = os.path.relpath(root, src)
            dest_dir = os.path.join(dest, rel_path)
            os.makedirs(dest_dir, exist_ok=True)
            for f in files:
                shutil.copy2(os.path.join(root, f), os.path.join(dest_dir, f))
                file_count += 1
        return file_count

    def sftp_connect(self):
        """Establish SFTP connection."""
        build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        port = parser['REGION_DETAILS']['port']
        username = parser['REGION_DETAILS']['username']
        private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], host.split('.')[0])
        key = paramiko.RSAKey.from_private_key_file(private_key_path)
        self.transport = paramiko.Transport((host, 22))
        self.transport.connect(username=username, pkey=key)
        self.sftp = paramiko.SFTPClient.from_transport(self.transport)
        print(f"Connected to {host} via SFTP using private key", flush=True)

    def sftp_mkdirs(self, remote_path):
        dirs = remote_path.strip("/").split("/")
        path = ""
        for d in dirs:
            path += "/" + d
            try:
                self.sftp.stat(path)
            except FileNotFoundError:
                self.sftp.mkdir(path)

    def sftp_upload_folder(self, local_path, remote_path):
        if not os.path.exists(local_path):
            print(f"Local path not found: {local_path}", flush=True)
            return 0
        file_count = 0
        for root, _, files in os.walk(local_path):
            rel_path = os.path.relpath(root, local_path)
            remote_dir = os.path.join(remote_path, rel_path).replace("\\", "/")
            self.sftp_mkdirs(remote_dir)
            for f in files:
                local_file = os.path.join(root, f)
                remote_file = f"{remote_dir}/{f}"
                self.sftp.put(local_file, remote_file)
                file_count += 1
        return file_count

    def rename_folders_with_date(self, base_path):
        if not os.path.exists(base_path):
            print(f"\nPath not found: {base_path}")
            return

        date_suffix_pattern = re.compile(r"_\d{8}$")  # matches _YYYYMMDD at end

        for entry in os.listdir(base_path):
            full_path = os.path.join(base_path, entry)

            if not os.path.isdir(full_path):
                continue

            # Skip if already ends with _YYYYMMDD
            if date_suffix_pattern.search(entry):
                print(f"\nSkipping (already renamed): {entry}")
                continue

            # Get creation time and format date
            ctime = os.path.getctime(full_path)
            date_str = datetime.fromtimestamp(ctime).strftime("%Y%m%d")

            new_name = f"{entry}_{date_str}"
            new_path = os.path.join(base_path, new_name)

            # Skip if target already exists
            if os.path.exists(new_path):
                print(f"\nSkipping (target exists): {new_name}")
                continue

            try:
                os.rename(full_path, new_path)
                print(f"\nRenamed: {entry} → {new_name}")
            except Exception as e:
                print(f"\nFailed to rename {entry}: {e}")

    def process_windows_copy(self):
        src_root = f'{self.startx_path}{self.build_version}'
        dest_root = '\\\\' + self.hostname + '\\Eagle_Install\\Stage'

        print(f'\nProcessing rename of old stage folder in {dest_root}', flush=True)
        self.rename_folders_with_date(dest_root)

        print(f'\nProcessing binary copy from {src_root} to {dest_root}', flush=True)
        os.makedirs(dest_root, exist_ok=True)
        total_src_files, total_dest_files = 0, 0

        for folder_name in self.folders_to_copy:
            src_path = os.path.join(src_root, folder_name)
            dest_path = os.path.join(dest_root, self.build_version, folder_name)
            src_file_count = self.count_files_in_dir(src_path)
            total_src_files += src_file_count

            copied_count = self.copy_folder(src_path, dest_path)
            total_dest_files += copied_count
            print(f"Copied {copied_count}/{src_file_count} files → {folder_name}", flush=True)

        print(f"\nSource={total_src_files}, Copied={total_dest_files}", flush=True)

    script = r'''
    find /apps/eagle/software/stage -maxdepth 1 -type d -name "Eagle_V*" | while read dir; do
      base=$(basename "$dir")

      # Skip if already renamed with _YYYYMMDD_HHMMSS
      if [[ "$base" =~ _[0-9]{8}_[0-9]{6}$ ]]; then
        echo "Skipping (already renamed): $dir"
        continue
      fi

      # Get folder modification date + time
      cdate=$(date -r "$dir" +%Y%m%d_%H%M%S)
      newname=$(dirname "$dir")/"$base"_"$cdate"

      mv "$dir" "$newname"
      echo "Renamed: $dir → $newname"
    done
    '''

    def ssh_script_rename_dir(self):
        try:
            build_ini_file = host[0:host.find('-', host.find('-') + 1)] + '.ini'
            parser = ConfigParser()
            parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
            port = parser['REGION_DETAILS']['port']
            username = parser['REGION_DETAILS']['username']
            private_key_path = os.path.join(parser['REGION_DETAILS']['privatekey'], host.split('.')[0])
            print(f"Connecting to {host} via SFTP using private key", flush=True)
            key = paramiko.RSAKey.from_private_key_file(private_key_path)
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(self.hostname, username=username, pkey=key)
            stdin, stdout, stderr = ssh.exec_command(f"bash -c '{self.script}'")
            out = stdout.read().decode("utf-8", errors="ignore")
            err = stderr.read().decode("utf-8", errors="ignore")

            print("---- STDOUT ----")
            print(out)
            print("---- STDERR ----")
            print(err)

            ssh.close()

        except Exception as e:
            print(f"Error: {e}")

    def process_linux_upload(self):
        self.sftp_connect()

        src_root = f'{self.startx_path}{self.build_version}'
        dest_root = '/apps/eagle/software/stage'

        print(f'\nProcessing rename of old stage folder in {dest_root}', flush=True)
        self.ssh_script_rename_dir()

        print(f'\nProcessing binary copy from {src_root} to {dest_root}', flush=True)
        self.sftp_mkdirs(dest_root)
        total_src_files, total_dest_files = 0, 0

        for folder_name in self.folders_to_copy:
            src_path = os.path.join(src_root, folder_name)
            dest_path = os.path.join(dest_root, self.build_version, folder_name).replace("\\", "/")
            src_file_count = self.count_files_in_dir(src_path)
            total_src_files += src_file_count

            uploaded_count = self.sftp_upload_folder(src_path, dest_path)
            total_dest_files += uploaded_count
            print(f"Uploaded {uploaded_count}/{src_file_count} files → {folder_name}", flush=True)

        print(f"\nSource={total_src_files}, Uploaded={total_dest_files}", flush=True)

        self.sftp.close()
        self.transport.close()
        print("\nSFTP connection closed.", flush=True)

    def run(self):
        if self.use_sftp:
            self.process_linux_upload()
        else:
            self.process_windows_copy()
        print("\nAll operations completed successfully!", flush=True)


if __name__ == "__main__":
    host = sys.argv[1]
    uploadbinaries = EagleCopyStage(host)
    uploadbinaries.run()
