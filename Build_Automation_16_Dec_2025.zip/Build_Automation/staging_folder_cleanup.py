import os, sys,  winrm
from configparser import ConfigParser
from datetime import datetime

from dotenv import load_dotenv

load_dotenv()

def deleting_stage_folders(conn, stage_loc, hostname):
    print('Apply Eagle Patch')

    path_batch = os.path.join(stage_loc + "\delete_staging_files.bat")
    print(path_batch)
    try:
        start_time = datetime.now().time().strftime('%H:%M:%S')
        print('Started deleting stage folders', hostname, start_time)
        result = conn.run_cmd(path_batch)
        output = result.std_out.decode()
        print(output)
        end_time = datetime.now().time().strftime('%H:%M:%S')
        if result.status_code == 0:
            print('Completed deleting stage folders', hostname, end_time)
        else:
            print("failed to run batch File ")
        total_time = (datetime.strptime(end_time, '%H:%M:%S') - datetime.strptime(start_time, '%H:%M:%S'))
        print('Total time taken to apply Eagle Patch', hostname, str(total_time))
    except OSError as error:
        print('Batch File not found', hostname)


def main(argv):
    type = sys.argv[1]
    host = sys.argv[2]
    for hostname in host.split(','):
        build_ini_file = hostname + '.ini'
        print(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))
        parser = ConfigParser()
        parser.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'configurations', build_ini_file))

        if type == 'APP' or type == 'ALL':
            try:
                hostname =  parser['APP_TIER_DETAIL']['hostname']
                username = parser['APP_TIER_DETAIL']['username']
                password = parser['APP_TIER_DETAIL']['password']
                try:
                    app_conn = winrm.Session(hostname, auth=(username, password), transport='ntlm')
                    print('Connection Established to', host)
                except Exception as error:
                    print('Failed to Establish Connection to', host)
                stage_loc = os.path.join(parser['APP_TIER_DETAIL']['stagePath'])
                deleting_stage_folders(app_conn, stage_loc, hostname)
            except:
                print('Application tier is Linux Box')
        if type == 'RPT' or type == 'ALL':
            hostname =  parser['REPORT_TIER_DETAIL']['hostname']
            username = parser['REPORT_TIER_DETAIL']['username']
            password = parser['REPORT_TIER_DETAIL']['password']

            try:
                rpt_conn = winrm.Session(hostname, auth=(username, password), transport='ntlm')
                print('Connection Established to', host)
            except Exception as error:
                print('Failed to Establish Connection to', host)
            stage_loc = os.path.join(parser['REPORT_TIER_DETAIL']['stagePath'])
            deleting_stage_folders(rpt_conn, stage_loc, hostname)

        if type == 'WEB' or type == 'ALL':
            hostname = parser['WEB_TIER_DETAIL']['hostname']
            username = parser['WEB_TIER_DETAIL']['username']
            password = parser['WEB_TIER_DETAIL']['password']

            try:
                web_conn = winrm.Session(hostname, auth=(username, password), transport='ntlm')
                print('Connection Established to', host)
            except Exception as error:
                print('Failed to Establish Connection to', host)
            stage_loc = os.path.join(parser['WEB_TIER_DETAIL']['stagePath'])
            deleting_stage_folders(web_conn, stage_loc, hostname)


if __name__ == "__main__":
    main(sys.argv)
