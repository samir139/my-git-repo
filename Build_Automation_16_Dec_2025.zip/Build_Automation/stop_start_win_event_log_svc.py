import subprocess
import sys

stop_svc = ["EventLog", "MSMQ", "NetMsmqActivator", "NetTcpActivator", "AppVClient", "Wecsvc", "NlaSvc", "netprofm"]
start_svc = ["EventLog", "MSMQ", "NetMsmqActivator", "NetTcpActivator", "AppVClient", "Wecsvc", "NlaSvc", "netprofm"]

def run_cmd(cmd):
    try:
        subprocess.run(cmd, shell=True, check=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except subprocess.CalledProcessError as e:
        if e.returncode == 1062:
            print(f"[INFO] Service already stopped: {cmd}")
        elif e.returncode == 1056:
            print(f"[INFO] Service already started: {cmd}")
        else:
            print(f"[WARN] Command failed: {cmd} | Error {e.returncode}")

def stop_or_start_svc(service, svc_type):
    if svc_type == 'stop':
        print(f"Disabling {service} on {remote_host}...")
        run_cmd(f"sc \\\\{remote_host} config {service} start= disabled")
        print(f"Stopping {service} on {remote_host}...")
        run_cmd(f"sc \\\\{remote_host} stop {service} ")

    if svc_type == 'start':
        print(f"Enabling {service} on {remote_host}...")
        run_cmd(f'sc \\\\{remote_host} config {service} start= auto')
        print(f"Starting {service} on {remote_host}...")
        run_cmd(f"sc \\\\{remote_host} start {service} ")


if __name__ == "__main__":
    remote_host = sys.argv[1]
    for svc in stop_svc:
        if sys.argv[2] == 'STOP':
            stop_or_start_svc(svc, 'stop')
    for svc in start_svc:
        if sys.argv[2] == 'START':
            stop_or_start_svc(svc, 'start')
    print("All services processed.")
