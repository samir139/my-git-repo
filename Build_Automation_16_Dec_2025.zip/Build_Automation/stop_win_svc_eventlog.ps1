param([string]$server = "s171-p002-wa01.eagleinvsys.com")
$service = "EventLog"

# Get the service object
$svc = Get-Service -ComputerName $server -Name $service -ErrorAction SilentlyContinue

if ($null -eq $svc) {
    Write-Output "Service $service not found on $server"
}
elseif ($svc.Status -eq "Stopped") {
    Write-Output "Service $service is already stopped on $server"
}
else {
    Write-Output "Service $service is $($svc.Status) on $server. Checking dependent services..."

    # Get dependent services
    $dependents = $svc.DependentServices

    if ($dependents.Count -gt 0) {
        Write-Output "Dependent services found: $($dependents.Name -join ', ')"

        foreach ($dep in $dependents) {
            if ($dep.Status -ne "Stopped") {
                Write-Output "Stopping dependent service: $($dep.Name)"
                try {
                    Stop-Service -InputObject $dep -Force -ErrorAction Stop
                    Write-Output "Stopped $($dep.Name) successfully"
                } catch {
                    Write-Output "Failed to stop $($dep.Name) on $server. Error: $($_)"
                }
            }
        }
    }
    else {
        Write-Output "No dependent services found."
    }

    # Finally stop EventLog itself
    Write-Output "Attempting to stop $service..."
    try {
        Stop-Service -InputObject $svc -Force -ErrorAction Stop
        Write-Output "$service stopped successfully on $server"
    } catch {
        Write-Output "Failed to stop $service on $server. Error: $($_)"
    }
}
