import paramiko

#hostname = 'rdt-s028-le01.eagleinvsys.com'
hostname = 'o171-i003-la01.eagleinvsys.com'

port = 22
username = 'eagle'
file_path = 'E:/Temp/' + hostname.split('.')[0]
print('Host :', hostname)
print('id_rsa File :', file_path)

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
key = paramiko.RSAKey.from_private_key_file(file_path)
ssh.connect(hostname=hostname, port=port, username=username, pkey=key)
stdin, stdout, stderr = ssh.exec_command('cd /apps/eagle && ls -l')
for line in stdout:
    print(line.strip(), flush=True)
    print(stdout.read().decode(), flush=True)
