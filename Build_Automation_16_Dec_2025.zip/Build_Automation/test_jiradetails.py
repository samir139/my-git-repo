import requests
from requests.auth import HTTPBasicAuth

url = "https://eagleinvsys.atlassian.net/rest/api/3/issue/DBT-524"
auth = HTTPBasicAuth("farm@eagleinvsys.com", "ATATT3xFfGF0kCtJB-mLRET5RL96jDi-PRMrYbDAHityoVbOx1sf8-KEQRwQWGSpAQRcIdwh-ZBXyJwMaIs7XSWZwpCGBzkxXSdFzRGn9Q8I7L8P5PlwrhoCdZS03gYPFW7bM9QZdt5mNtTmhIOGuBhI5Ps7UTsSBFE5X6v_eq9N_oCd7wjLne4=D4BF2EE5")


headers = {"Accept": "application/json"}
response = requests.get(url, headers=headers, auth=auth)

print(response.status_code)
print(response.text)