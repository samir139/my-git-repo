
import sys, paramiko

try:
    hostname = 'r17-a001-le01.eagleaccess.com'
except IndexError:
    print('Enter Hostname as parameter...')
    sys.exit(2)

port = '22'
username = 'eagle'
file_path = r'E:\Temp\r17-a001-le01'

old_string = 'EOR'
new_string = '\r\n'

#with open(file_path, 'r') as file:
#    file_contents = file.read()
#updated_contents = file_contents.replace(old_string, new_string)

#with open(file_path, 'w') as file:
#    file.write(updated_contents)

#print(file_path, "password file updated...")

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
private_key = paramiko.RSAKey.from_private_key_file(file_path)
ssh.connect(hostname=hostname, port=port, username=username, pkey=private_key)
stdin, stdout, stderr = ssh.exec_command('cd /apps/eagle && ls -l')
for line in stdout:
    print(line.strip(), flush=True)
    print(stdout.read().decode(), flush=True)
