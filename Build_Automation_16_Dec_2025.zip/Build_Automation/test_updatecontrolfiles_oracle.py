import paramiko
from scp import SCPClient

HOST = "o171-i003-la01.eagleinvsys.com"
USER = "eagle"
SSH_KEY_PATH = r"E:\Rundeck\var\storage\content\keys\EIS-LinuxAccount\o171-i003-la01"

ROOT_PATH = "/apps/eagle/software/stage/Eagle_V2025R1.2"

# Values to update
SLICE_VALUE = "100,200"
DATABASE_INSTANCE = "o171i003"
EDM_SETUP_MODE = "UPGRADE"
PASSWORD_VALUE = "eagle"
APP_PARTITIONING = "Y"

EMAIL_LIST = [
    "marimuthu.mannathan@bny.com",
    "samir.ransingh@bny.com"
]

# Files to rename
RENAME_MAP = {
    f"{ROOT_PATH}/DATABASE/eagle_erd/oracle/sample_edm_input_control_file_schemas.txt":
        f"{ROOT_PATH}/DATABASE/eagle_erd/oracle/edm_input_control_file_schemas.txt",

    f"{ROOT_PATH}/DATABASE/eagle_erd/oracle/sample_edm_input_control_file_setup.txt":
        f"{ROOT_PATH}/DATABASE/eagle_erd/oracle/edm_input_control_file_setup.txt",

    f"{ROOT_PATH}/DATABASE/eagle_erd/oracle/sample_edm_slice_control_file.txt":
        f"{ROOT_PATH}/DATABASE/eagle_erd/oracle/edm_slice_control_file.txt",

    f"{ROOT_PATH}/DATABASE/packages/oracle/sample_packages_input_control_file.txt":
        f"{ROOT_PATH}/DATABASE/packages/oracle/packages_input_control_file.txt"
}


def create_ssh():
    key = paramiko.RSAKey.from_private_key_file(SSH_KEY_PATH)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        HOST,
        username=USER,
        pkey=key,
        look_for_keys=False,
        allow_agent=False
    )
    return client


def update_remote_control_file(ssh, filepath):

    print(f"Updating {filepath}")

    sftp = ssh.open_sftp()

    # Read file
    with sftp.file(filepath, "r") as f:
        lines = f.readlines()

    new_lines = []
    skip_email = False

    for line in lines:
        if line.startswith("EMAIL"):
            skip_email = True
            continue

        if skip_email and not line.startswith("EMAIL"):
            skip_email = False

        # Key updates
        if line.startswith("DATABASE_INSTANCE"):
            new_lines.append(f"DATABASE_INSTANCE|{DATABASE_INSTANCE}|\n")
            continue

        if "APPLICATION_PARTITIONING" in line:
            new_lines.append(f"APPLICATION_PARTITIONING|{APP_PARTITIONING}|\n")
            continue

        if line.startswith("COMMON_PASSWORD") or \
           line.startswith("PACE_MASTERDBO") or \
           line.startswith("ESTAR") or \
           line.startswith("SYS_USER_PASSWORD") or \
           line.startswith("SYS|"):
            parts = line.split("|")
            parts[1] = PASSWORD_VALUE
            new_lines.append("|".join(parts))
            continue

        # Slice file specific update
        if filepath.endswith("edm_slice_control_file.txt") and line.startswith("slice"):
            new_lines.append(f"slice|{SLICE_VALUE}|\n")
            continue

        # Setup file specific update
        if filepath.endswith("edm_input_control_file_setup.txt") and \
           line.startswith("EDM_SETUP_MODE"):
            new_lines.append(f"EDM_SETUP_MODE|{EDM_SETUP_MODE}|\n")
            continue

        new_lines.append(line)

    # Add EMAIL rows at bottom
    for email in EMAIL_LIST:
        new_lines.append(f"EMAIL|{email}|\n")

    # Write file back
    with sftp.file(filepath, "w") as f:
        f.writelines(new_lines)

    sftp.close()
    print(f" Updated: {filepath}\n")


def main():
    ssh = create_ssh()
    print(" Connected to Linux host :", HOST)

    # Rename files
    for old, new in RENAME_MAP.items():
        cmd = f"cp -r {old} {new}"
        ssh.exec_command(cmd)
        print(f"Renamed:\n  {old}\n to {new}")

    print("\n Rename operations completed.\n")

    # Update each control file after rename
    for _, file_path in RENAME_MAP.items():
        update_remote_control_file(ssh, file_path)

    print("\n All remote file updates completed successfully.")

    ssh.close()


if __name__ == "__main__":
    main()