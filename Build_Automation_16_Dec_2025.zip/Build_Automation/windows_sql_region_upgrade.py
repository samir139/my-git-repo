import sys, re, os, configparser, smtplib, wmi, win32netcon, win32wnet, shutil, subprocess
from datetime import datetime, timezone
from pathlib import Path
from jira import JIRA
from email.message import EmailMessage
from win32netcon import RESOURCETYPE_DISK as DISK
from multiprocessing.pool import ThreadPool
from multiprocessing import Process
from subprocess import Popen
from rich.console import Console
from rich.table import Table
console = Console()
global build_id, build_version, build_status
build_number = ''

class MultithreadedCopier:
    def __init__(self, max_threads):
        self.pool = ThreadPool(max_threads)

    def copy(self, source, dest):
        self.pool.apply_async(shutil.copy2, args=(source, dest))

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.pool.close()
        self.pool.join()

def get_jira_details(build_id, jira_server, jira_uid, jira_token):
    global build_number
    jiraOptions = {'server': jira_server}
    jira = JIRA(options=jiraOptions,
                basic_auth=(jira_uid,
                        jira_token))
    build_version = str('Eagle_V' + jira.issue(build_id).fields.summary.replace(" ", ""))
    build_status = str(jira.issue(build_id).fields.status)
    a=int(0)
    for i in jira.comments(build_id):
         if int(i.id)>a:
             a = int(i.id)

    content = jira.comment(build_id,a).body
    count = len(jira.comments(build_id))
    for i in range(count,0,-1):
        content = jira.comment(build_id,jira.comments(build_id)[i-1]).body
        if re.findall("Build:",content,re.MULTILINE):
            for line in content.splitlines():
               if "Build" in line:
                   build_number = line
                   break
            break

    if build_status == 'Deployed To QA':
        print('Build Version is     : ' + build_version)
        print('Build Status is      : ' + build_status)
        print('Build will be initiated Automatically.')
    else:
        build_number = ''
        print('Build Version is     : ' + build_version)
        print('Build Status is      : ' + build_status)
        print('Build not yet ready for applying in regression regions as it is still in ' + build_status + ' state, please wait until its status changed to Deployed To QA.')


def send_email(FromID, ToID, Subject, message, smtpserver):
    try:
        msg = EmailMessage()
        msg["From"] = FromID
        msg["Subject"] = Subject
        msg["To"] = ToID
        msg.set_content(message)
        s = smtplib.SMTP(smtpserver)
        s.send_message(msg)
        print("Successfully sent email")
    except smtplib.SMTPException:
        print("Error: unable to send email")

def createStageDir(stagingPath):
    try:
        if not os.path.exists(stagingPath):
            os.makedirs(stagingPath, 0o777)
            print('Staging Directory ' + stagingPath + ' Created Successfully')
        else:
            shutil.rmtree(stagingPath)
            os.makedirs(stagingPath, 0o777)
            print('Staging Directory ' + stagingPath + ' Created Successfully')
    except OSError as error:
        print(error)

def rename_directory(oldStagePath, updStagePath):
    os.rename(oldStagePath, updStagePath)

def stop_services(conn, ip, svc):
    tableStopSvc = Table(show_header=True)
    tableStopSvc.add_column('Service Name')
    tableStopSvc.add_column('Tier Name')
    tableStopSvc.add_column('Status')
    for svc_name in svc:
        try:
            conn.Win32_Service(Name=svc_name)[0].StopService()
            tableStopSvc.add_row(svc_name, ip, 'Stopped Successfully')
        except OSError as error:
            tableStopSvc.add_row(svc_name, ip, 'Failed to Stop Successfully')
    console.print(tableStopSvc)

def start_services(conn, ip, svc):
    tableStartSvc = Table(show_header=True)
    tableStartSvc.add_column('Service Name')
    tableStartSvc.add_column('Tier Name')
    tableStartSvc.add_column('Status')
    for svc_name in svc:
        try:
            conn.Win32_Service(Name=svc_name)[0].StartService()
            tableStartSvc.add_row(svc_name, ip, 'Started Successfully')
        except OSError as error:
            tableStartSvc.add_row(svc_name, ip, 'Failed to Start Successfully')
    console.print(tableStartSvc)

def mapDrive(drive, networkPath, user, password, force=0):
    print(networkPath)
    if (os.path.exists(drive)):
        print(drive, " Drive in use, trying to unmap...")
        if force:
            try:
                win32wnet.WNetCancelConnection2(drive, 1, 1)
                print(drive, "successfully unmapped...")
            except:
                print(drive, "Unmap failed, This might not be a network drive...")
                return -1
        else:
            print("Non-forcing call. Will not unmap...")
            return -1
    else:
        print(drive, " drive is free...")
    if (os.path.exists(networkPath)):
        print(networkPath, " is found...")
        print("Trying to map ", networkPath, " on to ", drive, " .....")
        try:
            win32wnet.WNetAddConnection2(DISK, drive, networkPath, None, user, password)
        except OSError as error:
            print(error)
            print("Unexpected error...")
            return -1
        print("Mapping successful")
        return 1
    else:
        print("Network path unreachable...")
        return -1

def unmapDrive(drive, force=0):
    if (os.path.exists(drive)):
        print("drive in use, trying to unmap...")
        if force == 0:
            print("Executing un-forced call...")
        try:
            win32wnet.WNetCancelConnection2(drive, 1, force)
            print(drive, "successfully unmapped...")
            return 1
        except:
            print("Unmap failed, try again...")
            return -1
    else:
        print(drive, " Drive is already free...")
        return -1


def check_disk_space(host):
    BytesPerGB = 1024 * 1024 * 1024
    (total, used, free) = shutil.disk_usage(host)
    tablechkdiskspace = Table(show_header=True)
    tablechkdiskspace.add_column('Host Name')
    tablechkdiskspace.add_column('Total Space')
    tablechkdiskspace.add_column('Used Space')
    tablechkdiskspace.add_column('Free Space')
    tablechkdiskspace.add_row(host, str(round(float(total)/BytesPerGB)),
                                    str(round(float(used)/BytesPerGB)),
                                    str(round(float(free)/BytesPerGB)))
    if round(float(free)/BytesPerGB) > 10:
        print('Disk Space Available in : ' + host)
    else:
        print('Disk Space not Available in : ' + host)
    console.print(tablechkdiskspace)


def replace_string(filename, from_string, to_string):
    f = open(filename,'r')
    filedata = f.read()
    f.close()
    newdata = filedata.replace(from_string, to_string)
    f = open(filename,'w')
    f.write(newdata)
    f.close()


def check_patching_status(patch_loc, hostname, patch_type):
    list_of_files = os.listdir(patch_loc)
    for each_file in list_of_files:
        if patch_type == 'EAGLEPATCH':
            if each_file.startswith('patchinstall_'):
                each_file = os.path.join(patch_loc, each_file)
                with open(each_file, 'r') as file:
                    content = file.read()
                    if 'Patch installation SUCCEEDED' in content:
                        print('Eagle Patch Installed Successfully for : ' + hostname + ', Log file is : ' + each_file)
                    else:
                        print('Eagle Patch Installation Failed for : ' + hostname + ', Log file is : ' + each_file, '. Please re-apply the EAGLEPATCH manually.')
        if patch_type == 'WiX':
            if each_file.startswith('NxGClient') and each_file.endswith('.log'):
                if len(each_file) > 14:
                    each_file = os.path.join(patch_loc, each_file)
                    with open(each_file, 'r') as file:
                        content = file.read()
                        if 'Configuration completed successfully' in content:
                            print('Eagle NXG/WiX Installed Successfully for : ' + hostname + ', Log file is : ' + each_file)
                        else:
                            print('Eagle Patch Installation Failed for : ' + hostname + ', Log file is : ' + each_file, '. Please re-apply the EAGLE WiX Installer manually.')


def Apply_EaglePatch(conn, patch_loc, hostname, StaticConfig_path, INSTDIR_EMShell_path):
    table7 = Table(show_header=True, show_lines=False)
    table7.add_column('Apply Eagle Patch')
    print('Applying EAGLEPATCH in', hostname, '. Please wait...')
    path_ini = os.path.join(patch_loc + '\eaglepatch.ini')
    path_exe = os.path.join(patch_loc + '\eaglepatch.exe')
    if os.path.isfile(path_ini):
        try:
            start_time = datetime.now().time().strftime('%H:%M:%S')
            replace_string(path_ini,"SilentMode=0","SilentMode=1")
            replace_string(path_ini,"Delta=1","Delta=0")
            replace_string(path_ini,'EnaleWix=0', 'EnaleWix=1')
            replace_string(path_ini,"~/eagle/eaglemgr/config/eaglepatch.ini",StaticConfig_path)
            replace_string(path_ini,"~/eagle/",INSTDIR_EMShell_path)
            #process = subprocess.Popen(path_exe, shell=False,
            #                           stdout=subprocess.PIPE,
            #                           stderr=subprocess.PIPE,
            #                           universal_newlines=True)
            #rc = process.wait()
            #out,err=process.communicate()
            startup = conn.Win32_ProcessStartup.new(ShowWindow=1)
            process_id, result = conn.Win32_Process.Create(CommandLine=path_exe, ProcessStartupInformation=startup)
            watcher = conn.watch_for(
                    notification_type="Deletion",
                    wmi_class="Win32_Process",
                    delay_secs=1,
                    ProcessId=process_id
                )
            watcher()
            end_time = datetime.now().time().strftime('%H:%M:%S')
            total_time=(datetime.strptime(end_time,'%H:%M:%S') - datetime.strptime(start_time,'%H:%M:%S'))
            table7.add_row('Started applying Eagle Patch', hostname, start_time)
            table7.add_row('Completed applying Eagle Patch', hostname, end_time)
            table7.add_row('Total time taken to apply Eagle Patch', hostname, str(total_time))
        except OSError as error:
            table7.add_row('Failed to apply Eagle Patch', hostname)
    else:
        table7.add_row('Failed to apply Eagle Patch', hostname)
    check_patching_status(patch_loc, hostname, 'EAGLEPATCH')
    console.print(table7)


def Apply_EagleUI_WiX(conn, patch_loc, hostname, DEPLOY_URL, APP_NAME, INSTALLFOLDER):
    table9 = Table(show_header=True, show_lines=False)
    table9.add_column('Apply Eagle WiX UI')
    print('Started applying Eagle WiX UI in ', hostname)
    EagleUI_ini = os.path.join(patch_loc + '\Modules\EagleUI\setup.ini')
    EagleUI_exe = os.path.join(patch_loc + '\Modules\EagleUI\Setup.exe')
    if os.path.isfile(EagleUI_ini):
        try:
            start_time = datetime.now().time().strftime('%H:%M:%S')
            replace_string(EagleUI_ini,'UI_Mode = 1', 'UI_Mode = 0')
            #replace_string(EagleUI_ini,'http://eaglesite/tpe/modules/eshell/', DEPLOY_URL)
            #replace_string(EagleUI_ini,'(eaglesite)',APP_NAME)
            #replace_string(EagleUI_ini,'C:\\Program Files\\Eagle Investment Systems\\estar\\tpe\\modules\\eshell\\', INSTALLFOLDER)
            #process = subprocess.Popen(EagleUI_exe, shell=False,
            #                           stdout=subprocess.PIPE,
            #                           stderr=subprocess.PIPE,
            #                           universal_newlines=True)
            #rc = process.wait()
            #out,err=process.communicate()
            startup = conn.Win32_ProcessStartup.new(ShowWindow=1)
            process_id, result = conn.Win32_Process.Create(CommandLine=EagleUI_exe, ProcessStartupInformation=startup)
            watcher = conn.watch_for(
                notification_type="Deletion",
                wmi_class="Win32_Process",
                delay_secs=1,
                ProcessId=process_id
            )
            watcher()
            end_time = datetime.now().time().strftime('%H:%M:%S')
            total_time=(datetime.strptime(end_time,'%H:%M:%S') - datetime.strptime(start_time,'%H:%M:%S'))
            table9.add_row('Started applying Eagle WiX UI', hostname, start_time)
            table9.add_row('Completed applying Eagle WiX UI', hostname, end_time)
            table9.add_row('Total time taken to apply Eagle WiX UI', hostname, str(total_time))
        except OSError as error:
            table9.add_row('Failed to apply Eagle WiX UI', hostname)
    else:
        table9.add_row('Failed to apply Eagle WiX UI', hostname)
    check_patching_status(os.path.join(patch_loc + '\Modules\EagleUI'), hostname, 'WiX')
    console.print(table9)


def main(argv):
    now = datetime.now()
    try:
        environment = sys.argv[1]
        build_type  = sys.argv[2]
    except IndexError:
        print('No Environment Variable passed for applying build. Please provide the Environment Name.')
        sys.exit(2)

    try:
        config_filename = 'RunDeck_config_file_' + environment + '.ini'
        path = Path(config_filename)
        if path.is_file():
            print(f'The Configuration file {config_filename} is present.')
        else:
            print(f'The Configuration file {config_filename} missing please verify and re-apply the build')
    except OSError as error:
        print(f'The Configuration file {config_filename} missing please verify and re-apply the build')
        sys.exit(2)

    try:
        config = configparser.ConfigParser()
        config.read(config_filename)
    except IndexError:
        print('Unable to read the config file.')
        sys.exit(2)

    try:
        get_jira_details(config.get('Staging_Details','build_id'),
                         config.get('Staging_Details','jira_server'),
                         config.get('Staging_Details','jira_uid'),
                         config.get('Staging_Details','jira_token'))

        table = Table(show_header=True)
        table.add_column("Region")
        table.add_column("Build Number")
        table.add_column("Build Applied Date")
        table.add_row(sys.argv[1], build_number, str(now)[:19])
        console.print(table)
    except OSError as error:
        print(f'Unable to fetch the details form JIRA Board.')
        sys.exit(2)

    build_date = 'Eagle_V' + config.get('Staging_Details', 'Version')

    app_svc = config.get("APP_TIER_DETAIL"      ,"SERVICES").split (",")
    rpt_svc = config.get("REPORT_TIER_DETAIL"   ,"SERVICES").split (",")
    web_svc = config.get("WEB_TIER_DETAIL"      ,"SERVICES").split (",")

    # Define Staging Directories
    print('Defining Staging Directories in all servers')
    root_stage          = config.get("Staging_Details","home_stagingPath") + config.get("Staging_Details","Version")
    edm_path            = 'DATABASE\eagle_erd_' + config.get("Staging_Details","Version") + '\\' + config.get("Staging_Details","Type")
    pkg_path            = 'DATABASE\packages_' + config.get("Staging_Details","Version") + '\\' + config.get("Staging_Details","Type")
    root_stage_edm      = os.path.join(root_stage, edm_path)
    root_stage_pkg      = os.path.join((root_stage), pkg_path)
    root_stage_patch    = os.path.join(root_stage, 'EAGLE_PATCH')
    app_edm_loc         = os.path.join(config.get("APP_TIER_DETAIL","STAGE_LOC"), build_date, edm_path)
    app_pkg_loc         = os.path.join(config.get("APP_TIER_DETAIL","STAGE_LOC"), build_date, pkg_path)
    app_patch_loc       = os.path.join(config.get("APP_TIER_DETAIL","STAGE_LOC"), build_date, 'EAGLE_PATCH')
    rpt_patch_loc       = os.path.join(config.get("REPORT_TIER_DETAIL","STAGE_LOC"), build_date, 'EAGLE_PATCH')
    web_patch_loc       = os.path.join(config.get("WEB_TIER_DETAIL","STAGE_LOC"), build_date, 'EAGLE_PATCH')
    table3 = Table(show_header=True, show_lines=False)
    table3.add_column('Stage Directory Name')
    table3.add_column('Stage Location')
    table3.add_row('Root Stage Path',root_stage)
    #table3.add_row('Dailybuild EDM',root_stage_edm)
    #table3.add_row('Dailybuild Package',root_stage_pkg)
    table3.add_row('Dailybuild Eagle Patch',root_stage_patch)
    #table3.add_row('App Tier EDM',app_edm_loc)
    #table3.add_row('App Tier Package',app_pkg_loc)
    table3.add_row('App Tier Eagle Patch',app_patch_loc)
    table3.add_row('Report Tier Eagle Patch',rpt_patch_loc)
    table3.add_row('Web Tier Eagle Patch',web_patch_loc)
    console.print(table3)

    subject_down_email               = 'Eagle V' + config.get('Staging_Details', 'Version') + ' ' + \
                                                   config.get('Settings', 'Region') + ' ' + \
                                                   config.get('Settings', 'Server') + ' ' + \
                                                   config.get('DB_TIER_DETAIL', 'DB_Name') + ' ' + \
                                                   ' is going down for applying the latest build'
    subject_up_email                 = 'Eagle V' + config.get('Staging_Details', 'Version') + ' ' + \
                                                   config.get('Settings', 'Region') + ' ' + \
                                                   config.get('Settings', 'Server') + ' ' + \
                                                   config.get('DB_TIER_DETAIL', 'DB_Name') + ' ' + \
                                                   ' is back online after applying the latest build'
    subject_edm_complete_email       = 'Applying edm complete for ' + \
                                       'Eagle V' + config.get('Staging_Details', 'Version') + ' ' + \
                                                   config.get('Settings', 'Region') + ' ' + \
                                                   config.get('Settings', 'Server') + ' ' + \
                                                   config.get('DB_TIER_DETAIL', 'DB_Name')
    subject_package_complete_email   = 'Applying package complete for ' + \
                                       'Eagle V' + config.get('Staging_Details', 'Version') + ' ' + \
                                                   config.get('Settings', 'Region') + ' ' + \
                                                   config.get('Settings', 'Server') + ' ' + \
                                                   config.get('DB_TIER_DETAIL', 'DB_Name')
    subject_Patch_complete_email     = 'Applying eagle patch complete for ' + \
                                       'Eagle V' + config.get('Staging_Details', 'Version') + ' ' + \
                                                   config.get('Settings', 'Region') + ' ' + \
                                                   config.get('Settings', 'Server') + ' ' + \
                                                   config.get('DB_TIER_DETAIL', 'DB_Name')
    down_message_body = ("""
    Hi All,
    
    The region is going down for applying the latest build.
    
    """ + config.get('Staging_Details', 'home_stagingPath') + config.get('Staging_Details', 'Version') + """
    
    """ + build_number + """
    
    Components:
    EDM
    PACKAGES
    EAGLE_PATCH (all tiers)
    NxG
    PORTAL
 
    Thanks,
    Regression Operation Team
    """)

    up_message_body = ("""
    Hi All,
    
    The region is back online after applying the latest build.
    
    """ + config.get('Staging_Details', 'home_stagingPath') + config.get('Staging_Details', 'Version') + """
    
    """ + build_number + """
    
    Components:
    EDM
    PACKAGES
    EAGLE_PATCH (all tiers)
    NxG
    PORTAL
 
    Thanks,
    Regression Operation Team
    """)

    print('Connecting to App, Report & Web Tier Servers')
    table1 = Table(show_header=True, show_lines=False)
    table1.add_column('Tier')
    table1.add_column('Status')

    if build_type == 'APP' or build_type == 'ALL':
        try:
            app_conn = wmi.WMI(config.get("APP_TIER_DETAIL","HOSTNAME"), user=config.get("APP_TIER_DETAIL","USERNAME"), password=config.get("APP_TIER_DETAIL","PASSWORD"))
            table1.add_row(config.get("APP_TIER_DETAIL","HOSTNAME"), 'Connected')
        except Exception as error:
            table1.add_row(config.get("APP_TIER_DETAIL","HOSTNAME"), 'Failed to Establish Connection')
    if build_type == 'RPT' or build_type == 'ALL':
        try:
            rpt_conn = wmi.WMI(config.get("REPORT_TIER_DETAIL","HOSTNAME"), user=config.get("REPORT_TIER_DETAIL","USERNAME"), password=config.get("REPORT_TIER_DETAIL","PASSWORD"))
            table1.add_row(config.get("REPORT_TIER_DETAIL","HOSTNAME"), 'Connected')
        except Exception as error:
            table1.add_row(config.get("REPORT_TIER_DETAIL","HOSTNAME"), 'Failed to Establish Connection')
    if build_type == 'WEB' or build_type == 'ALL':
        try:
            web_conn = wmi.WMI(config.get("WEB_TIER_DETAIL","HOSTNAME"), user=config.get("WEB_TIER_DETAIL","USERNAME"), password=config.get("WEB_TIER_DETAIL","PASSWORD"))
            table1.add_row(config.get("WEB_TIER_DETAIL","HOSTNAME"), 'Connected')
        except Exception as error:
            table1.add_row(config.get("WEB_TIER_DETAIL","HOSTNAME"), 'Failed to Establish Connection')

    if build_type == 'APP':
        try:
            mapDrive(config.get("ShareDrive_Details", "win_app_share_drive"),
                     config.get("ShareDrive_Details", "win_app_share_path"),
                     config.get("APP_TIER_DETAIL","USERNAME"),
                     config.get("APP_TIER_DETAIL","PASSWORD"),
                     force=0)
            table1.add_row(config.get("APP_TIER_DETAIL","HOSTNAME"), 'Share Drive Created Successfully')
        except Exception as error:
            table1.add_row(config.get("APP_TIER_DETAIL","HOSTNAME"), 'Failed to Create Share Drive')
            print('Failed to create the share drive for Application Tier.')
            exit(2)

    console.print(table1)

    send_email(config.get('NOTIFICATION', 'From'), config.get('NOTIFICATION', 'To'), subject_down_email,
               down_message_body, config.get('NOTIFICATION', 'SMTPServer'))

    build_start_time = datetime.now().time().strftime('%H:%M:%S')

    if config.get('Settings','CopyBinaries') == '1':
        print('Creating Staging Directory. Please wait...')
        start_time = datetime.now().time().strftime('%H:%M:%S')
        if build_type == 'APP' or build_type == 'ALL':
            check_disk_space(config.get('APP_TIER_DETAIL','STAGE_LOC'))
            createStageDir(os.path.join(config.get("APP_TIER_DETAIL","STAGE_LOC"), build_date))
        if build_type == 'RPT' or build_type == 'ALL':
            check_disk_space(config.get('REPORT_TIER_DETAIL','STAGE_LOC'))
            createStageDir(os.path.join(config.get("REPORT_TIER_DETAIL","STAGE_LOC"), build_date))
        if build_type == 'WEB' or build_type == 'ALL':
            check_disk_space(config.get('WEB_TIER_DETAIL','STAGE_LOC'))
            createStageDir(os.path.join(config.get("WEB_TIER_DETAIL","STAGE_LOC"), build_date))
        print('File Copy started for ' + build_type + ' Tiers. Please wait...')
        with MultithreadedCopier(max_threads=500) as copier:
            if build_type == 'APP' or build_type == 'ALL':
                #shutil.copytree(root_stage_edm, app_edm_loc, copy_function=copier.copy)
                #shutil.copytree(root_stage_pkg, app_pkg_loc, copy_function=copier.copy)
                shutil.copytree(root_stage_patch, app_patch_loc, copy_function=copier.copy)
            if build_type == 'RPT' or build_type == 'ALL':
                shutil.copytree(root_stage_patch, rpt_patch_loc, copy_function=copier.copy)
            if build_type == 'WEB' or build_type == 'ALL':
                shutil.copytree(root_stage_patch, web_patch_loc, copy_function=copier.copy)
        print("Rename of the modules/Portal directory inside EAGLE_PATCH for App/Rpt/Web Tiers")
        if build_type == 'APP' or build_type == 'ALL':
                rename_directory(os.path.join(app_patch_loc, 'Modules\\Portal'),
                                 os.path.join(app_patch_loc, 'Modules\\_Portal'))
        if build_type == 'RPT' or build_type == 'ALL':
            rename_directory(os.path.join(rpt_patch_loc, 'Modules\\Portal'),
                             os.path.join(rpt_patch_loc, 'Modules\\_Portal'))
        if build_type == 'WEB' or build_type == 'ALL':
            if config.get('Settings','Region') != 'PERF':
                rename_directory(os.path.join(web_patch_loc, 'Modules\\Portal'),
                                 os.path.join(web_patch_loc, 'Modules\\_Portal'))
        end_time = datetime.now().time().strftime('%H:%M:%S')
        total_time=(datetime.strptime(end_time,'%H:%M:%S') - datetime.strptime(start_time,'%H:%M:%S'))
        table4 = Table(show_header=True, show_lines=False)
        table4.add_column('File Copy Status')
        table4.add_row('Started at', start_time)
        table4.add_row('Completed at', end_time)
        table4.add_row('Total time taken for File Copy', str(total_time))
        console.print(table4)
    else:
        print('Please copy the binaries manually.')

    if config.get('Settings','StopServices') == '1':
        print('Stopping Eagle Services. Please wait...')
        start_time = datetime.now().time().strftime('%H:%M:%S')
        if build_type == 'APP' or build_type == 'ALL':
            stop_app_services = Process(target=stop_services(app_conn, config.get("APP_TIER_DETAIL","HOSTNAME"), app_svc))
            stop_app_services.start()
            stop_app_services.join()
        if build_type == 'RPT' or build_type == 'ALL':
            stop_rpt_services = Process(target=stop_services(rpt_conn, config.get("REPORT_TIER_DETAIL","HOSTNAME"), rpt_svc))
            stop_rpt_services.start()
            stop_rpt_services.join()
        if build_type == 'WEB' or build_type == 'ALL':
            stop_web_services = Process(target=stop_services(web_conn, config.get("WEB_TIER_DETAIL","HOSTNAME"), web_svc))
            stop_web_services.start()
            stop_web_services.join()
        end_time = datetime.now().time().strftime('%H:%M:%S')
        total_time=(datetime.strptime(end_time,'%H:%M:%S') - datetime.strptime(start_time,'%H:%M:%S'))
        table5 = Table(show_header=True, show_lines=False)
        table5.add_column('Stopping Eagle Services')
        table5.add_row('Started at', start_time)
        table5.add_row('Completed at', end_time)
        table5.add_row('Total time taken for Stopping Eagle Services', str(total_time))
        console.print(table5)
    else:
        print('Stopping Service is set as manual in config file.')

    if build_type == 'APP' or build_type == 'ALL':
        apply_app_eaglePatch = Process(target=Apply_EaglePatch(app_conn, app_patch_loc, config.get("APP_TIER_DETAIL","HOSTNAME"),
                                                               config.get('REPORT_TIER_DETAIL','StaticConfig'),
                                                               config.get('REPORT_TIER_DETAIL','INSTDIR_EMShell')))
        apply_app_eaglePatch.start()
        apply_app_eaglePatch.join()
    if build_type == 'RPT' or build_type == 'ALL':
        apply_rpt_eaglePatch = Process(target=Apply_EaglePatch(rpt_conn, rpt_patch_loc, config.get("REPORT_TIER_DETAIL","HOSTNAME"),
                                                               config.get('REPORT_TIER_DETAIL','StaticConfig'),
                                                               config.get('REPORT_TIER_DETAIL','INSTDIR_EMShell')))
        apply_rpt_eaglePatch.start()
        apply_rpt_eaglePatch.join()
    if build_type == 'WEB' or build_type == 'ALL':
        apply_web_eaglePatch = Process(target=Apply_EaglePatch(web_conn, web_patch_loc, config.get("WEB_TIER_DETAIL","HOSTNAME"),
                                                               config.get('WEB_TIER_DETAIL','StaticConfig'),
                                                               config.get('WEB_TIER_DETAIL','INSTDIR_EMShell')))
        apply_web_eaglePatch.start()
        apply_web_eaglePatch.join()

    if build_type == 'WEB' or build_type == 'ALL':
        apply_wix_eaglePatch = Process(target=Apply_EagleUI_WiX(web_conn, web_patch_loc,
                                                                config.get("WEB_TIER_DETAIL","HOSTNAME"),
                                                                config.get("WEB_TIER_DETAIL","DEPLOY_URL"),
                                                                config.get("WEB_TIER_DETAIL","APP_NAME"),
                                                                config.get("WEB_TIER_DETAIL","INSTALLFOLDER")))
        apply_wix_eaglePatch.start()
        apply_wix_eaglePatch.join()

    print('Starting Eagle Services')
    start_time = datetime.now().time().strftime('%H:%M:%S')
    if build_type == 'WEB' or build_type == 'ALL':
        start_web_services = Process(target=start_services(web_conn, config.get("WEB_TIER_DETAIL","HOSTNAME"), web_svc))
        start_web_services.start()
        start_web_services.join()
    if build_type == 'RPT' or build_type == 'ALL':
        start_rpt_services = Process(target=start_services(rpt_conn, config.get("REPORT_TIER_DETAIL","HOSTNAME"), rpt_svc))
        start_rpt_services.start()
        start_rpt_services.join()
    if build_type == 'APP' or build_type == 'ALL':
        start_app_services = Process(target=start_services(app_conn, config.get("APP_TIER_DETAIL","HOSTNAME"), app_svc))
        start_app_services.start()
        start_app_services.join()
    end_time = datetime.now().time().strftime('%H:%M:%S')
    total_time=(datetime.strptime(end_time,'%H:%M:%S') - datetime.strptime(start_time,'%H:%M:%S'))
    table8 = Table(show_header=True, show_lines=False)
    table8.add_column('Starting Eagle Services')
    table8.add_row('Started at', start_time)
    table8.add_row('Completed at', end_time)
    table8.add_row('Total time taken for Starting Eagle Services', str(total_time))
    console.print(table8)

    if build_type == 'APP':
        os.chdir('C:')
        unmapDrive(config.get("ShareDrive_Details", "win_app_share_drive"))

    #oldStagePathApp = os.path.join(config.get("APP_TIER_DETAIL","STAGE_LOC"), "\\", build_date)
    #oldStagePathRpt = os.path.join(config.get("REPORT_TIER_DETAIL","STAGE_LOC"), "\\", build_date)
    #oldStagePathWeb = os.path.join(config.get("WEB_TIER_DETAIL","STAGE_LOC"), "\\", build_date)

    #updStagePathApp = os.path.join(oldStagePathApp + "_" + str(datetime.now(timezone.utc).strftime('%m-%d-%Y')))
    #updStagePathRpt = os.path.join(oldStagePathRpt + "_" + str(datetime.now(timezone.utc).strftime('%m-%d-%Y')))
    #updStagePathWeb = os.path.join(oldStagePathWeb + "_" + str(datetime.now(timezone.utc).strftime('%m-%d-%Y')))

    #os.close(2)
    #os.rename(oldStagePathApp, updStagePathApp)
    #os.rename(oldStagePathRpt, updStagePathRpt)
    #os.rename(oldStagePathWeb, updStagePathWeb)

    build_end_time = datetime.now().time().strftime('%H:%M:%S')
    total_build_time=(datetime.strptime(build_end_time,'%H:%M:%S') - datetime.strptime(build_start_time,'%H:%M:%S'))
    print('Build Started at :' + build_start_time)
    print('Build Completed at : ' + build_end_time)
    print('total time taken to apply the build : ' + str(total_build_time))

    send_email(config.get('NOTIFICATION', 'From'), config.get('NOTIFICATION', 'To'), subject_up_email,
               up_message_body, config.get('NOTIFICATION', 'SMTPServer'))


if __name__ == "__main__":
   main(sys.argv)
